/** @file TetMesh.hpp
  * @bried Mesh composed of tetrahedra
  */

#include "CS207/Util.hpp"
#include "CS207/Point.hpp"

#include <algorithm>
#include <vector> 
#include <set> 
#include <map>
#include <cassert>

/** @class Mesh
  * @brief  A template for 3d tetrahedral meshes
  * 
  * Users can add nodes and tetrahedra, retrieve nodes, edges, triangles and tetrahedra.
  */

using std::cout;

template <typename N, typename E, typename TRI, typename TET>
class TetMesh {
 public:

  // PUBLIC TYPE DEFINITIONS

  typedef TetMesh  tet_mesh_type;

  class Node;

  typedef Node node_type;

  typedef N node_data_type;

  class Edge; 

  typedef Edge edge_type;

  typedef E edge_data_type;

  class Triangle;

  typedef Triangle triangle_type;

  typedef TRI triangle_data_type;

  class Tetrahedron;

  typedef Tetrahedron tet_type;

  typedef TET tet_data_type;

  typedef unsigned size_type;

  class node_iterator;

  class edge_iterator;

  class triangle_iterator;

  class tet_iterator;

  class node_edge_iterator; // Over edges adj to nodes

  class node_tri_iterator; // Over triangles adj to nodes

  class node_tet_iterator; // Over tetrahedra adjacent to nodes

  class tri_tri_iterator; // Over triangles adjacent to given one

  class tri_tet_iterator; // Over tetrahedra adjacent to given triangle

  class tet_tet_iterator; // Over tetrahedra adjacent to given one

  /** Data structures associated with element of the mesh. */

  struct Nodeinfo {
   /** Default constructor. */
   Nodeinfo()
    : coord(), data(), adj_nodes(), adj_tri(), adj_tet() {
    }

   /** Parameterized constructor. */
   Nodeinfo( const Point& inp_coord, const node_data_type& inp_data = node_data_type() )
    : coord(inp_coord), data(inp_data), adj_nodes(), adj_tri(), adj_tet() {
    }

   /** Data members.*/
   Point coord;
   node_data_type data;
   std::map<size_type,size_type > adj_nodes; /*< Map indexed by adj node idx, 
							 contains edge idx. */
   std::set<size_type> adj_tri; /*< Holds indices of triangles containing this node. */
   std::set<size_type> adj_tet; /*< Holds indices of tetrahedra containing this node. */
  };

  struct Edgeinfo {
   /** Default constructor. */
   Edgeinfo() 
    : node1(), node2(), data(), init_length(), adj_tri(), adj_tet() {
    }

   /** Parameterized constructor. */
   Edgeinfo( const size_type& inp_n1, const size_type& inp_n2,
     const edge_data_type& inp_data = edge_data_type() )
    :node1(inp_n1), node2(inp_n2), data(inp_data), adj_tri(), adj_tet() {
    }

   /** Data members. */
   size_type node1;
   size_type node2;
   edge_data_type data;
   double init_length; /*< Length of the edge at construction moment. */
   std::map<size_type,size_type> adj_tri; /*< Holds indices of triangles containing 
						       this edge as key, and index of edge in 
						       that triangle as map element. */		
   std::map<size_type,size_type> adj_tet; /*< Holds indices of tetrahedra containing 
						       this edge as key, and index of edge in 
						       that tetrahedron as map element. */
  };

  struct Triinfo {
   /** Parameterized constructor. */
   Triinfo( const triangle_data_type& inp_data = triangle_data_type() ) 
    : nodes(3), edges(3), data(inp_data), init_area(), adj_tri(), adj_tet() {
    }

   /** Data members. */
   std::vector<size_type> nodes; /*< Indices of nodes; size == 3 at all times. */
   std::vector<size_type> edges; /*< Indices of edges; size == 3 at all times. */
   /** RI: 
     for any i in [0,2] node with index nodes[i] is opposite to the edge with index edges[i]
     */
   triangle_data_type data;
   double init_area;
   std::set<size_type> adj_tri; /*< Indices of triangles sharing an edge with this one. */
   std::map<size_type,size_type> adj_tet; /*< Map indexed by indices of adjacent tets 
						       and having the index of the triangle in 
						       that tet ( 0 to 3 ) as elements;
						       RI - size == 1 or 2 */
  };

  struct Tetinfo {
   /** Parameterized constructor. */
   Tetinfo( const tet_data_type& inp_data = tet_data_type() )
    : nodes(4), edges(6), triangles(4), init_volume(), data(inp_data), adj_tet() {
    }
   /** Data members. */
   std::vector<size_type> nodes; /*< Indices of nodes; size == 4. */
   std::vector<size_type> edges; /*< Indices of edges; size == 6. */
   std::vector<size_type> triangles; /*< Indices of triangles - faces; size == 4. */
   /** RI: 
     * for any i in [0,3] node with index nodes[i] is opposite to the triangle with index
     * triangles[i]. 
     */
   double init_volume;
   tet_data_type data;
   std::set<size_type> adj_tet; /*< Indices of adjacent tetrahedra; at most 4 elements. */
  };

  /** Construct an empty mesh. */
  TetMesh()
   : nodes_(), edges_(), triangles_(), tetrahedra_() {
   }

  // NODES

  class Node : private totally_ordered<Node> {
   public:
    /** Default constructor. */
    Node() 
     : tmesh_(0), idx_(0) {
     }

    /** Return the node's position. */
    Point position() const {
     return (tmesh_->nodes_[idx_].coord);
    }

    /** Set the node's position. */
    void set_position( const Point& p ) {
     tmesh_->nodes_[idx_].coord = p;
    }

    /** Return the node's index. */
    size_type index() const {
     return idx_; 
    }

    /** Return the associated data - const method. */
    const node_data_type& data() const {
     return (tmesh_->nodes_[idx_].data);
    }

    /** Return the associated data - non-const method. */
    node_data_type& data() {
     return (tmesh_->nodes_[idx_].data);
    }

    /** Return the degree of given node - number of adjacent nodes */
    size_type degree() const {
     return (tmesh_->nodes_[idx_].adj_nodes.size());
    }

    /** Return the number of triangles which contain this node. */
    size_type num_triangles() const {
     return (tmesh_->nodes_[idx_].adj_tri.size());
    }

    /** Return the number of tetrahedra which contain this node. */
    size_type num_tetrahedra() const {
     return (tmesh_->nodes_[idx_].adj_tet.size());
    }

    /** Comparison methods. */
    bool operator==(const Node& n) const  {
     return ( (tmesh_ == n.tmesh_) && (idx_==n.idx_) );
    }

    bool operator<(const Node& n) const {
     assert( tmesh_ == n.tmesh_ );
     return( idx_ < n.idx_ );
    }

    /** Iterators. */

    node_edge_iterator edge_begin() {
     return node_edge_iterator( tmesh_, idx_, tmesh_->nodes_[idx_].adj_nodes.begin() );
    }

    node_edge_iterator edge_end() {
     return node_edge_iterator( tmesh_, idx_, tmesh_->nodes_[idx_].adj_nodes.end() );
    }

    node_tri_iterator tri_begin() {
     return node_tri_iterator( tmesh_, idx_, tmesh_->nodes_[idx_].adj_tri.begin() );
    }

    node_tri_iterator tri_end() {
     return node_tri_iterator( tmesh_, idx_, tmesh_->nodes_[idx_].adj_tri.end() );
    }

    node_tet_iterator tet_begin() {
     return node_tet_iterator( tmesh_, idx_, tmesh_->nodes_[idx_].adj_tet.begin() );
    }

    node_tet_iterator tet_end() {
     return node_tet_iterator( tmesh_, idx_, tmesh_->nodes_[idx_].adj_tet.end() );
    }

   private:
    /** Parameterized constructor. */
    Node( const tet_mesh_type* inp_tmesh, const size_type& inp_idx ) 
     : tmesh_(const_cast<tet_mesh_type*>(inp_tmesh)), idx_(inp_idx) {
     }

    friend class TetMesh;
    /** Data members. */
    tet_mesh_type* tmesh_;
    size_type idx_;
  };

  /** Return the number of nodes in the mesh. */
  size_type num_nodes() const {
   return nodes_.size();
  }

  /** Add a node to the mesh. */
  Node add_node( const Point& inp_pos, const node_data_type inp_data = node_data_type() ) {
   size_type new_idx = nodes_.size();
   nodes_.push_back(Nodeinfo(inp_pos,inp_data));
   return Node( this, new_idx );
  }

  /** Determine if the node belongs to the mesh. */
  bool has_node( const Node& n ) const {
   return ( (this == n.tmesh_) && (n.idx_ < nodes_.size() ) );
  }

  /** Return the node with index @a i. */
  Node node( size_type i ) const {
   return Node(this, i); 
  }

  // EDGES - can be added only as a part of tetrahedron
  class Edge : private totally_ordered<Edge> {
   public: 
    /** Default constructor. */
    Edge() 
     : tmesh_(0), node1_(), node2_(), idx_() {
     }

    /** Return the first node of this edge. */
    Node node1() const {
     return Node( tmesh_, node1_ );
    }

    /** Return the second node of this edge. */
    Node node2() const {
     return Node( tmesh_, node2_ );
    }

    /** Return the index of this mesh. */
    size_type index() const {
     return idx_;
    }

    /** Return the edge's data. */
    edge_data_type& data() {
     return ( tmesh_->edges_[idx_].data );
    }

    /** Return the edge's data - const method. */
    const edge_data_type& data() const {
     return ( tmesh_->edges_[idx_].data );
    }

    /** Return the initial length of the edge. */
    double init_length() const {
     return ( tmesh_->edges_[idx_].init_length );
    }

    /** Return the current length of the edge. */
    double length() const {
     return norm( tmesh_->nodes_[node1_].coord - tmesh_->nodes_[node2_].coord );
    }

    /** Return the number of triangles containing this edge. */
    size_type num_triangles() const {
     return ( tmesh_->edges_[idx_].adj_tri.size() );
    }

    /** Return the number of the tetrahedra having this edge. */
    size_type num_tetrahedra() const {
     return ( tmesh_->edges_[idx_].adj_tet.size() );
    }

    /** Comparison methods. */
    bool operator==(Edge& e) const {
     return( (tmesh_ == e.tmesh_) && (idx_==e.idx_) );
    }

    bool operator<(Edge& e) const {
     assert( tmesh_ == e.tmesh_ );
     return( idx_ < e.idx_ );
    }

   private:
    /** Private constructor - using index only. */
    Edge( const tet_mesh_type * inp_tmesh, size_type inp_idx )
     : tmesh_(const_cast<tet_mesh_type*>(inp_tmesh)), idx_(inp_idx) {
      node1_ = tmesh_->edges_[idx_].node1;
      node2_ = tmesh_->edges_[idx_].node2;
     }

    /** Private constructor - using 2 node indices, for node's incident iterator. */
    Edge( const tet_mesh_type * inp_tmesh, size_type inp_n1, size_type inp_n2 )
     : tmesh_(const_cast<tet_mesh_type*>(inp_tmesh)), node1_(inp_n1), node2_(inp_n2) {
      idx_ = (tmesh_->nodes_[node1_].adj_nodes)[node2_];
     }

    friend class TetMesh;
    /** Data members. */
    tet_mesh_type* tmesh_; /*< Pointer to the owner mesh. */
    size_type node1_;
    size_type node2_; /*< Indices of nodes; can be in different order compared to Edgeinfo vector in the TetMesh. Implemented this way to make possible dereferencing adjacent edge iterators with node1() being the calling node, and node2() being the adjacent node. */
    size_type idx_; /*< Index of this edge in the edges_ vector of the owner mesh. */
  };

  /** Return the number of edges in this graph. */
  size_type num_edges() const {
   return edges_.size();
  }

  /** Return the edge with index i. */
  Edge edge( size_type i ) const {
   return Edge( this, i );
  }

  /** Test if 2 nodes with indices i, j are connected by an edge. */
  bool has_edge( size_type i, size_type j ) const {
   return ( nodes_[i].adj_nodes.find(j) != nodes_[i].adj_nodes.end() );
  }


  // TRIANGLES - can be added only as a part of a tetrahedron
  class Triangle : private totally_ordered<Triangle> {
   public:
    /** Default constructor. */
    Triangle() 
     : tmesh_(), idx_() {
     }

    /** Return the triangle's data. */
    triangle_data_type& data() {
     return ( tmesh_->triangles_[idx_].data );
    }

    /** Return the triangle's data - const method. */
    const triangle_data_type& data() const {
     return ( tmesh_->triangles_[idx_].data );
    }

    /** Return the index of this triangle. */
    size_type index() const { 
     return idx_;
    }

    /** Return one of the triangle's nodes.
      * @param[in] i Integer number in range [0,2]
      */
    Node node(size_type i) const {
     return Node( tmesh_, tmesh_->triangles_[idx_].nodes[i] );
    }

    /** Return one of the triangle's edges.
      * @param[in] i Integer number in range [0,2]
      * @result Edge opposite to node(i) of that triangle
      */
    Edge edge(size_type i) const {
     return Edge( tmesh_, tmesh_->triangles_[idx_].edges[i] );
    }

    /** Compute the current triangle's area. */
    double area() const {
     return ( 0.5 * norm( cross( 
       ( tmesh_->nodes_[ tmesh_->triangles_[idx_].nodes[0] ].coord 
       - tmesh_->nodes_[ tmesh_->triangles_[idx_].nodes[2] ].coord ),  
       ( tmesh_->nodes_[ tmesh_->triangles_[idx_].nodes[0] ].coord 
       - tmesh_->nodes_[ tmesh_->triangles_[idx_].nodes[1] ].coord ) ) ) );
    } 

    /** Return the initial area the triangle had during construction. */
    double init_area() const {
     return ( tmesh_->triangles_[idx_].init_area );
    }

    /** Return the number of triangles adjacent to given one. */
    size_type num_triangles() const {
     return ( tmesh_->triangles_[idx_].adj_tri.size() );
    }

    /** Return the number of tetrahedra containing this triangle; has to be 2 at most. */
    size_type degree() const {
     return ( tmesh_->triangles_[idx_].adj_tet.size() );
    }

    /** Return the number of tetrahedra containing this triangle; has to be 2 at most. */
    size_type num_tetrahedra() const {
     return ( tmesh_->triangles_[idx_].adj_tet.size() );
    }

    /** Return the normal to this triangle pointing outside of tetrahedron with input idx.
      * @param[in] i Index of a tetrahedron containing this triangle.
      */
    Point normal( size_type inp_idx ) const {
     // Assert that the tetrahedron with inp_idx has this triangle
     auto it = tmesh_->triangles_[idx_].adj_tet.find(inp_idx);
     assert ( it != tmesh_->triangles_[idx_].adj_tet.end() );
     // Now fetch the indices of the nodes comprising this triangle
     auto nodes_idx = tmesh_->triangles_[idx_].nodes;
     for (auto it1 = nodes_idx.begin(); it1 != nodes_idx.end(); ++it1) {
     }
     // Set up a vector for normal helper function;
     std::vector<Point> pts(4);
     // First 3 elements span the plane to which normal is constructed
     for ( size_type j = 0; j < 3; ++j ) {
      pts[j] = tmesh_->nodes_[nodes_idx[j]].coord;
     }
     // 4th element points sets a reference for normal direction
     // Fetch the index of the node which is opposite to the triangle under consideration
     // in the tetrahedron with index==inp_idx. For that we use RI: node with "internal index" 
     // (i.e., the position in vector tetrahedra_[].nodes) i is opposite to the triangle
     // with "internal index" i; so we can figure out the node once we know the "internal index"
     // of the triangle, which can be found in the adj_tet map of this triangle
     size_type int_idx = (*it).second;
     // Get the index of the opposite node in the input tet
     size_type opp_node = tmesh_->tetrahedra_[inp_idx].nodes[int_idx];
     pts[3] = tmesh_->nodes_[opp_node].coord;
     // Compute the normal
     Point tnormal = tmesh_->normal( pts );
     return tnormal;
    }

    /** Comparison methods. */
    bool operator==(Triangle& t) const {
     return( (tmesh_ == t.tmesh_) && (idx_==t.idx_) );
    }

    bool operator<(Triangle& t) const {
     assert( tmesh_ == t.tmesh_ );
     return( idx_ < t.idx_ );
    }

    /** Iterators. */
    tri_tri_iterator tri_begin() const {
     return tri_tri_iterator( tmesh_, tmesh_->triangles_[idx_].adj_tri.begin() );
    }

    tri_tri_iterator tri_end() const {
     return tri_tri_iterator( tmesh_, tmesh_->triangles_[idx_].adj_tri.end() );
    }
  
    tri_tet_iterator tet_begin() const {
     return tri_tet_iterator( tmesh_, tmesh_->triangles_[idx_].adj_tet.begin() );
    }

    tri_tet_iterator tet_end() const {
     return tri_tet_iterator( tmesh_, tmesh_->triangles_[idx_].adj_tet.end() );
    }
  
   private:
    /** Parameterized constructor. */
    Triangle( const tet_mesh_type* inp_tmesh, size_type inp_idx )
     : tmesh_(const_cast<tet_mesh_type*>(inp_tmesh)), idx_(inp_idx) {
     }

    friend class TetMesh;
    /** Data members. */
    tet_mesh_type* tmesh_;
    size_type idx_;
  };

  /** Return the number of triangles in the mesh. */
  size_type num_triangles() const {
   return triangles_.size();
  }

  /** Return a triangle by its index. */
  Triangle triangle( size_type i ) const {
   return Triangle(this, i);
  }

  /** Check if a triangle between nodes which indices are given in the array exists.
    * @param[in] inp_idx Array with 3 indices of nodes in this mesh, not equal pair-wise
    * @param[out] return_idx reference to store the index of existing triangle, if any.
    * @return True if triangle exists; return_idx has its index then.
    */
  bool has_triangle( std::array<size_type,3> inp_idx, size_type& return_idx ) {
   // Use std::set intersection to figure out the common indices of triangles in 
   // input nodes
   std::set<size_type> common_tri_idx;
   std::set<size_type> init_tri_idx = nodes_[inp_idx[0]].adj_tri;
   for ( size_type i = 1; i < 3; ++i ) {
    // Take set intersections
    set_intersection(init_tri_idx.begin(),init_tri_idx.end(),
      nodes_[inp_idx[i]].adj_tri.begin(),nodes_[inp_idx[i]].adj_tri.end(),
      std::inserter(common_tri_idx,common_tri_idx.begin() ) );
    if (common_tri_idx.size() > 0 ) {
     // Reassign the common triangles to init_tri_idx
     init_tri_idx = common_tri_idx;
     // Clear the common_nodes before taking the next intersection
     // if it's not the last iteration
     if ( i < 2 ) {
      common_tri_idx.clear();
     }
    }
    else {
     return false;
    }
   }
   // If code got to this point, there has to be a common triangle, index of which 
   // is the only element in common_tri_idx
   assert( common_tri_idx.size() == 1 );
   // Assign the index of common triangle to the second input argument
   return_idx = *( common_tri_idx.begin() );
   return true;
  }
  // TETRAHEDRA

  class Tetrahedron : private totally_ordered<Tetrahedron> {
   public:
    /** Default constructor. */
    Tetrahedron() 
     : tmesh_(), idx_() {
     }

    /** Return tetrahedron's index. */
    size_type index() const {
     return idx_;
    }

    /** Return tetrahedron's data. */
    tet_data_type& data() {
     return tmesh_->tetrahedra_[idx_].data; 
    }

    /** Return tetrahedron's data - const method. */
    const tet_data_type& data() const {
     return tmesh_->tetrahedra_[idx_].data; 
    }

    /** Return one of tetrahedron's nodes.
      * @param[in] i Integer in range [0,3]
      */
    Node node( size_type i ) const {
     return Node( tmesh_, tmesh_->tetrahedra_[idx_].nodes[i] );
    }

    /** Return one of the tetrahedron's edges.
      * @param[in] i Integer in range [0,5]
      */
    Edge edge( size_type i ) const {
     return Edge( tmesh_, tmesh_->tetrahedra_[idx_].edges[i] );
    }

    /** Return one of the tetrahedron's faces. 
      * @param[in] i Integer in range [0,3].
      * @return Face opposing to node(i) of this tet.
      */
    Triangle triangle( size_type i ) const {
     return Triangle( tmesh_, tmesh_->tetrahedra_[idx_].triangles[i] );
    }
 
    /** Return outer normal vector to this tetrahedron's triangle(i).
      * @param[in] i Integer in range [0,3].
      */
    Point normal( size_type i ) const {
     // Compute on the fly, to avoid updating with every node positions change
     // Fetch the global idx of the face in triangles_ vector.
     size_type face_idx = tmesh_->tetrahedra_[idx_].triangles[i];
     // Fetch the global indices of the nodes in that triangle
     auto nodes_idx = tmesh_->triangles_[face_idx].nodes;
     // Set up the vector to hold 3 points in plane and 4th point to which normal has to 
     // point in opposite direction
     std::vector<Point> pts(4);
     for ( size_type j = 0; j < 3; ++j ) {
      pts[j] = tmesh_->nodes_[nodes_idx[j]].coord;
     }
     // Put the 4th point, which if the opposite node of tetrahedron
     pts[3] = tmesh_->nodes_[tmesh_->tetrahedra_[idx_].nodes[i]].coord;
     // Compute the normal using helper method
     Point tnormal = tmesh_->normal( pts );
     return tnormal;
    }
      
    /** Return the volume which tetrahedron had upon construction. */
    double init_volume() const {
     return (tmesh_->tetrahedra_[idx_].init_volume);
    }
 
    /** Compute the volume which the tetrahedron has currently. */
    double volume() const {
     // Fetch the indices of the nodes of this tetrahedron
     auto nodes_idx = tmesh_->tetrahedra_[idx_].nodes;
     // Compute the volume using the formula from final project prompt
     return ( abs( 
       inner_prod( 
        (tmesh_->nodes_[nodes_idx[1]].coord - tmesh_->nodes_[nodes_idx[0]].coord),
        cross(
 	(tmesh_->nodes_[nodes_idx[2]].coord - tmesh_->nodes_[nodes_idx[0]].coord), 
 	(tmesh_->nodes_[nodes_idx[3]].coord - tmesh_->nodes_[nodes_idx[0]].coord) ) ) ) / 6.0 );
    }

    /** Return the number of adjacent tetrahedra. */
    size_type num_tetrahedra() const {
     return (tmesh_->tetrahedra[idx_].adj_tet.size());
    }

    /** Comparison methods. */
    bool operator==(Tetrahedron& t) const {
     return( (tmesh_ == t.tmesh_) && (idx_==t.idx_) );
    }

    bool operator<(Tetrahedron& t) const {
     assert( tmesh_ == t.tmesh_ );
     return( idx_ < t.idx_ );
    }

    /** Iterators. */
    tet_tet_iterator tet_begin() const {
     return tet_tet_iterator( tmesh_, tmesh_->tetrahedra_[idx_].adj_tet.begin() );
    }

    tet_tet_iterator tet_end() const {
     return tet_tet_iterator( tmesh_, tmesh_->tetrahedra_[idx_].adj_tet.end() );
    }

   private:
    /** Parameterized constructor. */
    Tetrahedron( const tet_mesh_type* inp_tmesh, size_type inp_idx )
     : tmesh_(const_cast<tet_mesh_type*>(inp_tmesh)), idx_(inp_idx) {
     }
  
    friend class TetMesh;
    /** Data members. */
    tet_mesh_type * tmesh_;
    size_type idx_;
  };

  /** Return the number of tetrahedra in the mesh. */
  size_type num_tetrahedra() const {
   return tetrahedra_.size();
  }

  /** Return a tet by its index. */
  Tetrahedron tetrahedron( size_type i ) const {
   return Tetrahedron( this, i );
  }

  /** Check if a tetrahedron between nodes with indices given in the input array exists
    * @param[in] inp_idx Array with 4 indices of nodes in this mesh, not equal pair-wise
    * @param[out] return_idx reference to store the index of existing tetrahedron, if any.
    * @return True if tetrahedron exists; return_idx has its index then.
    */
  bool has_tetrahedron( std::array<size_type,4>& inp_idx, size_type& return_idx ) {
   // Use std::set intersection to figure out the common indices of tetrahedra in 
   // input nodes
   std::set<size_type> common_tet_idx;
   std::set<size_type> init_tet_idx = nodes_[inp_idx[0]].adj_tet;
   for ( size_type i = 1; i < 4; ++i ) {
    // Take set intersections
    set_intersection(init_tet_idx.begin(),init_tet_idx.end(),
      nodes_[inp_idx[i]].adj_tet.begin(),nodes_[inp_idx[i]].adj_tet.end(),
      std::inserter(common_tet_idx,common_tet_idx.begin() ) );
    if (common_tet_idx.size() > 0 ) {
     // Output the common tets;
     for (auto it = common_tet_idx.begin(); it != common_tet_idx.end(); ++it ) {
     }
     // Reassign the common tetrahedra to init_tet_idx
     init_tet_idx = common_tet_idx;
     // Clear the common_nodes before taking the next intersection
     // and if it's not the last iteration
     if ( i < 3 ) {
      common_tet_idx.clear();
     }
    }
    else {
     return false;
    }
   }
   // If code got to this point, there has to be a common tetrahedron, index of which 
   // is the only element in common_tet_idx
   assert( common_tet_idx.size() == 1 );
   // Assign the index of common tetangle to the second input argument
   return_idx = *( common_tet_idx.begin() );
   return true;
  }


  /** Add a tetrahedron containing the nodes given in the input.
    * @param[in] inp_idx Array with 4 indices of nodes in this mesh, not equal pair-wise
    */
  Tetrahedron add_tetrahedron( std::array<size_type,4>& inp_idx ) {
   size_type tet_idx = tetrahedra_.size();
   // Check if the tetrahedron we wish to insert exists already 
   if ( has_tetrahedron( inp_idx, tet_idx ) ) {
    return Tetrahedron( this, tet_idx );
   }

   // Set up a container for indices of existing triangles
   std::set<size_type> ex_tris;
   // First, we need to uphold the RI for triangles - no one of them can have degree (i.e., 
   // number of adjacent tets) > 2. 
   for ( size_type i = 0; i < 4; ++i ) {
    // Set up a variable to hold the triangle index
    size_type tidx = triangles_.size();
    // Check if the triangles exist
    // Call the "local indices" in the inp_idx
    auto local_idx = idx_tet(i);
    std::array<size_type,3> global_idx;
    // Convert them to "global indices"
    for (size_type k = 0; k < 3; ++k) {
     global_idx[k] = inp_idx[local_idx[k]];
    }

    if ( has_triangle( global_idx, tidx ) ) {
     ex_tris.insert(tidx);
     // The triangle exists and it's index is in tidx; check it's degree
     assert ( triangle(tidx).degree() < 2 );
    }
   }
   // If the tetrahedron to be added shares an edge with any of the existing ones,
   // we need to check that the tetrahedra do not overlap spatially; use helper func for that.

   // Figure out, if for any pair of input nodes there exists an edge btw them
   for ( size_type i = 0; i < 6; ++i ) {
    // Get "local" indices of nodes in inp_idx array
    auto local_nidx = edge2nodes(i);
    // Set up global indices for the nodes of interest
    std::pair<size_type,size_type> global_nidx;
    global_nidx.first = inp_idx[local_nidx.first];
    global_nidx.second = inp_idx[local_nidx.second];
    // Request their positions
    // Check if there is an edge btw those nodes
    if ( has_edge( global_nidx.first, global_nidx.second ) ) {
     // Figure out the edge index
     size_type eidx = nodes_[global_nidx.first].adj_nodes[global_nidx.second];
     // We need to check to which tetrahedra does this edge belong
     for ( auto it = edges_[eidx].adj_tet.begin();
       it != edges_[eidx].adj_tet.end(); ++it ) {
      size_type tidx = (*it).first; // Index of the tetrahedron
      size_type int_idx = (*it).second; // "internal index" of the edge in that tet
      // Figure out which nodes are opposite to the edge in that tet
      // "internal indices" first
      auto local_nidx = edge2opp_nodes(int_idx);
      // then, "global" indices
      std::pair<size_type,size_type> ex_global_nidx;
      ex_global_nidx.first = tetrahedra_[tidx].nodes[local_nidx.first];
      ex_global_nidx.second = tetrahedra_[tidx].nodes[local_nidx.second];
      //  << " oppose it in that tet\n";
      // Now figure out the global indices of the nodes opposing the edge in the input
      local_nidx = edge2opp_nodes(i);
      std::pair<size_type,size_type> new_global_nidx;
      new_global_nidx.first = inp_idx[local_nidx.first];
      new_global_nidx.second = inp_idx[local_nidx.second];

      // Put together a vector of 6 points for helper tet_overlap:
      // 1st, 2nd - edge nodes' coord; 3rd, 4th - coord of nodes opposite to in in existing tet;
      // 4th, 5th - coord of nodes opposite to it in to-be-added tet.
      std::vector<Point> node_coords(6);
      node_coords[0] = nodes_[global_nidx.first].coord;
      node_coords[1] = nodes_[global_nidx.second].coord;
      node_coords[2] = nodes_[ex_global_nidx.first].coord;
      node_coords[3] = nodes_[ex_global_nidx.second].coord;
      node_coords[4] = nodes_[new_global_nidx.first].coord;
      node_coords[5] = nodes_[new_global_nidx.second].coord;
      if ( tet_overlap( node_coords ) == true ) {
       cout << "Overlap btw existing tet " << tidx << " with nodes at:";
       for ( size_type j = 0; j < 4; ++j ) {
	cout << "\n\t" << tetrahedra_[tidx].nodes[j] << "\t" 
	 << nodes_[tetrahedra_[tidx].nodes[j]].coord;
       }
        cout << "\n\nand new tet btw nodes at: ";
       for (size_type j = 0; j < 4; ++j ) {
	 cout << "\n\t" << inp_idx[j] << "\t" << nodes_[inp_idx[j]].coord;
       }
        cout << "\n\nOverlapping edge with index " << eidx << " btw nodes " << global_nidx.first 
	 << " and " << global_nidx.second << "\n\n\n";
       return Tetrahedron();
      }
     }
    }
   }

   // Now, after passing all checks, we can add edges
   // Add a new entry to the tetrahedra_ vector
   tetrahedra_.push_back(Tetinfo());

   for ( size_type i = 0; i < 6; ++i ) {
    // Get "local" indices of nodes in the inp_idx array
    auto local_nidx = edge2nodes(i);
    // Set up global indices for the nodes of interest
    std::pair<size_type,size_type> global_nidx;
    global_nidx.first = inp_idx[local_nidx.first];
    global_nidx.second = inp_idx[local_nidx.second];
    auto e = add_edge( global_nidx.first, global_nidx.second );
    // Continue with adding the edge's data to the tet, and 
    // new tet's data to the edges
    tetrahedra_[tet_idx].edges[i] = e.idx_;
    edges_[e.idx_].adj_tet[tet_idx] = i;
   }

   // Add the indices of existing tetrahedra to the adj_tet of existing one, and vice versa
   for ( auto it = ex_tris.begin(); it != ex_tris.end(); ++it ) {
    // At this point there should be 1 element in each map
    // Put the info about existing tetrahedra into new one
    tetrahedra_[tet_idx].adj_tet.insert( (*triangles_[*it].adj_tet.begin() ).first );
    // And about new one into existing
    tetrahedra_[(*triangles_[*it].adj_tet.begin()).first].adj_tet.insert(tet_idx);
   }

   // Insert the nodes and triangles-faces
   for ( size_type i = 0; i < 4; ++i ) {
    // Add node to tet's data
    tetrahedra_[tet_idx].nodes[i] = inp_idx[i];
    // Add tet to node's data
    nodes_[inp_idx[i]].adj_tet.insert(tet_idx);
    // Add a triangle - figure out the global indices of nodes to comprise a triangle
    std::array<size_type,3> internal_inp_idx = idx_tet(i);
    std::array<size_type,3> global_inp_idx;
    for ( size_type j = 0; j < 3; ++j ) {
     global_inp_idx[j] = inp_idx[internal_inp_idx[j]];
    }
    // Add a triangle made of those nodes - that function takes care of adding tri's data to
    // edges, nodes and other triangles.
    auto t = add_triangle(global_inp_idx);
    // Add the tet's data to the triangle
    triangles_[t.idx_].adj_tet[tet_idx] = i;
    // Add triangle's data to the tetrahedron
    tetrahedra_[tet_idx].triangles[i] = t.idx_;
   }

   // Finally, compute the initial volume of the tetrahedron
   tetrahedra_[tet_idx].init_volume =  inner_prod( 
       (nodes_[inp_idx[1]].coord - nodes_[inp_idx[0]].coord),
       cross(
       (nodes_[inp_idx[2]].coord - nodes_[inp_idx[0]].coord), 
       (nodes_[inp_idx[3]].coord - nodes_[inp_idx[0]].coord) ) ) / 6.0 ;
   if (tetrahedra_[tet_idx].init_volume < 0.0) { tetrahedra_[tet_idx].init_volume *= -1.0; }
   if ( tetrahedra_[tet_idx].init_volume < -1.0*eps ) {
    cout << "Attention: tet w/index " << tet_idx << "\nbtw nodes:\n";
    for (size_type j = 0; j < 4; ++j ) {
     cout << "Index " << inp_idx[j] << " at " << nodes_[inp_idx[j]].coord << "\n";
    }
    cout << "Has volume " << tetrahedra_[tet_idx].init_volume << "\n\n";
   }
   return Tetrahedron( this, tet_idx );
  }


  /** @class TetMesh::node_iterator
   * @brief Iterator class for nodes. A forward iterator. */
  class node_iterator : private totally_ordered<node_iterator> {
   public:
    // These type definitions help us use STL's iterator_traits.
    /** Element type. */
    typedef Node value_type;
    /** Type of pointers to elements. */
    typedef Node* pointer;
    /** Type of references to elements. */
    typedef Node& reference;
    /** Iterator category. */
    typedef std::input_iterator_tag iterator_category;
    /** Difference between iterators */
    typedef std::ptrdiff_t difference_type;

    /** Construct an invalid node_iterator. */
    node_iterator()
     : tmesh_(0), curr_idx_() {
    }

    /** Dereferencing operator. */
    Node operator*() const {
     return Node(tmesh_, curr_idx_);
    }
    /** Incrementation operator. */
    node_iterator& operator++() {
     ++curr_idx_;
     return (*this);
    }
    /** Comparison. */
    bool operator==(const node_iterator& rhs) const {
     return( (tmesh_ == rhs.tmesh_) && (curr_idx_ == rhs.curr_idx_) );
    }

   private:
    friend class TetMesh;
    /** Data members. */
    tet_mesh_type* tmesh_;
    size_type  curr_idx_;
    /** Private constructor.
      * @param[in] inp_mesh Pointer to a mesh of interest
      * @param[in] inp_idx  Number of nodes iterated over
      * @pre @a inp_mesh is a pointer to a valid mesh
      *      0 <= @a curr_idx_ < (*tmesh_).num_nodes()
      */
    node_iterator(const tet_mesh_type* inp_mesh, const size_type inp_idx)
      : tmesh_(const_cast<tet_mesh_type*>(inp_mesh)), curr_idx_(inp_idx) {
     }
  };

  /** node_iterator node_begin() const. */
  node_iterator node_begin() const {
   return node_iterator(this, 0);
  }
  // node_iterator node_end() const
  node_iterator node_end() const {
   return node_iterator(this, num_nodes());
  }

  /** @class TetMesh::edge_iterator
   * @brief Iterator class for edges. A forward iterator. */
  class edge_iterator : private totally_ordered<edge_iterator> {
   public:
    // These type definitions help us use STL's iterator_traits.
    /** Element type. */
    typedef Edge value_type;
    /** Type of pointers to elements. */
    typedef Edge* pointer;
    /** Type of references to elements. */
    typedef Edge& reference;
    /** Iterator category. */
    typedef std::input_iterator_tag iterator_category;
    /** Difference between iterators */
    typedef std::ptrdiff_t difference_type;

    /** Construct an invalid edge_iterator. */
    edge_iterator()
    : tmesh_(0), curr_idx_(0) {
    }

    /** Edge operator*() const */
    Edge operator*() const {
     return Edge( tmesh_, curr_idx_ );
    }
    /** Incrementation operator. */
    edge_iterator& operator++() {
        curr_idx_++;
        return (*this);
    }
    /** Comparison. */
    bool operator==(const edge_iterator& rhs) const {
     return( (tmesh_ == rhs.tmesh_) && (curr_idx_ == rhs.curr_idx_) );
    }

   private:
    friend class TetMesh;
    /** Data members. */
    tet_mesh_type* tmesh_;
    size_type  curr_idx_;
    /** Private constructor.
      * @param[in] inp_mesh Pointer to a mesh of interest
      * @param[in] inp_idx  Number of nodes iterated over
      * @pre @a inp_mesh is a pointer to a valid mesh
      *      0 <= @a curr_idx_ <= (*tmesh_).num_nodes()
      */
    edge_iterator(const tet_mesh_type* inp_mesh, const size_type inp_idx)
      : tmesh_(const_cast<tet_mesh_type*>(inp_mesh)), curr_idx_(inp_idx) {
     }
  };


  /** edge_iterator edge_begin() const. */
  edge_iterator edge_begin() const {
   return edge_iterator(this, 0);
  }
  // edge_iterator edge_end() const
  edge_iterator edge_end() const {
   return edge_iterator(this, num_edges());
  }


  /** @class TetMesh::triangle_iterator
   * @brief Iterator class for triangles. A forward iterator. */
  class triangle_iterator : private totally_ordered<triangle_iterator> {
   public:
    // These type definitions help us use STL's iterator_traits.
    /** Element type. */
    typedef Triangle value_type;
    /** Type of pointers to elements. */
    typedef Triangle* pointer;
    /** Type of references to elements. */
    typedef Triangle& reference;
    /** Iterator category. */
    typedef std::input_iterator_tag iterator_category;
    /** Difference between iterators */
    typedef std::ptrdiff_t difference_type;

    /** Construct an invalid triangle_iterator. */
    triangle_iterator()
    : tmesh_(0), curr_idx_(0) {
    }

    /** Triangle operator*() const */
    Triangle operator*() const {
     return Triangle( tmesh_, curr_idx_ );
    }
    /** Incrementation operator. */
    triangle_iterator& operator++() {
        curr_idx_++;
        return (*this);
    }
    /** Comparison. */
    bool operator==(const triangle_iterator& rhs) const {
     return( (tmesh_ == rhs.tmesh_) && (curr_idx_ == rhs.curr_idx_) );
    }

   private:
    friend class TetMesh;
    /** Data members. */
    tet_mesh_type* tmesh_;
    size_type  curr_idx_;
    /** Private constructor.
      * @param[in] inp_mesh Pointer to a mesh of interest
      * @param[in] inp_idx  Number of nodes iterated over
      * @pre @a inp_mesh is a pointer to a valid mesh
      *      0 <= @a curr_idx_ <= (*tmesh_).num_nodes()
      */
    triangle_iterator(const tet_mesh_type* inp_mesh, const size_type inp_idx)
      : tmesh_(const_cast<tet_mesh_type*>(inp_mesh)), curr_idx_(inp_idx) {
     }
  };


  /** triangle_iterator triangle_begin() const. */
  triangle_iterator triangle_begin() const {
   return triangle_iterator(this, 0);
  }
  // triangle_iterator triangle_end() const
  triangle_iterator triangle_end() const {
   return triangle_iterator(this, num_triangles());
  }



  /** @class TetMesh::tetrahedron_iterator
   * @brief Iterator class for tetrahedrons. A forward iterator. */
  class tetrahedron_iterator : private totally_ordered<tetrahedron_iterator> {
   public:
    // These type definitions help us use STL's iterator_traits.
    /** Element type. */
    typedef Tetrahedron value_type;
    /** Type of pointers to elements. */
    typedef Tetrahedron* pointer;
    /** Type of references to elements. */
    typedef Tetrahedron& reference;
    /** Iterator category. */
    typedef std::input_iterator_tag iterator_category;
    /** Difference between iterators */
    typedef std::ptrdiff_t difference_type;

    /** Construct an invalid tetrahedron_iterator. */
    tetrahedron_iterator()
    : tmesh_(0), curr_idx_(0) {
    }

    /** Tetrahedron operator*() const */
    Tetrahedron operator*() const {
     return Tetrahedron( tmesh_, curr_idx_ );
    }
    /** Incrementation operator. */
    tetrahedron_iterator& operator++() {
        curr_idx_++;
        return (*this);
    }
    /** Comparison. */
    bool operator==(const tetrahedron_iterator& rhs) const {
     return( (tmesh_ == rhs.tmesh_) && (curr_idx_ == rhs.curr_idx_) );
    }

   private:
    friend class TetMesh;
    /** Data members. */
    tet_mesh_type* tmesh_;
    size_type  curr_idx_;
    /** Private constructor.
      * @param[in] inp_mesh Pointer to a mesh of interest
      * @param[in] inp_idx  Number of nodes iterated over
      * @pre @a inp_mesh is a pointer to a valid mesh
      *      0 <= @a curr_idx_ <= (*tmesh_).num_nodes()
      */
    tetrahedron_iterator(const tet_mesh_type* inp_mesh, const size_type inp_idx)
      : tmesh_(const_cast<tet_mesh_type*>(inp_mesh)), curr_idx_(inp_idx) {
     }
  };


  /** tetrahedron_iterator tetrahedron_begin() const. */
  tetrahedron_iterator tetrahedron_begin() const {
   return tetrahedron_iterator(this, 0);
  }
  // tetrahedron_iterator tetrahedron_end() const
  tetrahedron_iterator tetrahedron_end() const {
   return tetrahedron_iterator(this, num_tetrahedra());
  }



  /** @class TetMesh::Node::node_edge_iterator
   * @brief Iterator class for edges adjacent to nodes. A forward iterator. */
  class node_edge_iterator : private totally_ordered<node_edge_iterator> {
   public:
    // These type definitions help us use STL's iterator_traits.
    /** Element type. */
    typedef Edge value_type;
    /** Type of pointers to elements. */
    typedef Edge* pointer;
    /** Type of references to elements. */
    typedef Edge& reference;
    /** Iterator category. */
    typedef std::input_iterator_tag iterator_category;
    /** Difference between iterators */
    typedef std::ptrdiff_t difference_type;

    /** Construct an invalid edge_iterator. */
    node_edge_iterator()
    : tmesh_(0), node_idx_(0), it_() {
    }

    /** Edge operator*() const */
    Edge operator*() const {
     return Edge( tmesh_, node_idx_, (*it_).first );
    }
    /** Incrementation operator. */
    node_edge_iterator& operator++() {
        ++it_;
        return (*this);
    }
    /** Comparison. */
    bool operator==(const node_edge_iterator& rhs) const {
     return( (tmesh_ == rhs.tmesh_) && (node_idx_ == rhs.node_idx_) 
      && (it_ == rhs.it_) );
    }

   private:
    friend class TetMesh;
    /** Data members. */
    tet_mesh_type* tmesh_;
    size_type  node_idx_;
    // First element of map members is adj node id, second - adj edge id
    typename std::map<size_type,size_type>::iterator it_;
    /** Private constructor.
      * @param[in] inp_mesh Pointer to a mesh of interest
      * @param[in] inp_idx  Idx of host node
      * @param[in] inp_it Iterator into host node's map of adj nodes
      */
    node_edge_iterator(const tet_mesh_type* inp_mesh, const size_type inp_idx, 
      typename std::map<size_type,size_type>::iterator inp_it)
      : tmesh_(const_cast<tet_mesh_type*>(inp_mesh)), node_idx_(inp_idx), it_(inp_it) {
     }
  };


  /** @class TetMesh::Node::node_tri_iterator
   * @brief Iterator class for tris adjacent to nodes. A forward iterator. */
  class node_tri_iterator : private totally_ordered<node_tri_iterator> {
   public:
    // These type definitions help us use STL's iterator_traits.
    /** Element type. */
    typedef Triangle value_type;
    /** Type of pointers to elements. */
    typedef Triangle* pointer;
    /** Type of references to elements. */
    typedef Triangle& reference;
    /** Iterator category. */
    typedef std::input_iterator_tag iterator_category;
    /** Difference between iterators */
    typedef std::ptrdiff_t difference_type;

    /** Construct an invalid tri_iterator. */
    node_tri_iterator()
    : tmesh_(0), node_idx_(0), it_() {
    }

    /** Triangle operator*() const */
    Triangle operator*() const {
     return Triangle( tmesh_, (*it_) );
    }
    /** Incrementation operator. */
    node_tri_iterator& operator++() {
        ++it_;
        return (*this);
    }
    /** Comparison. */
    bool operator==(const node_tri_iterator& rhs) const {
     return( (tmesh_ == rhs.tmesh_) && (node_idx_ == rhs.node_idx_) 
      && (it_ == rhs.it_) );
    }

   private:
    friend class TetMesh;
    /** Data members. */
    tet_mesh_type* tmesh_;
    size_type  node_idx_;
    typename std::set<size_type>::iterator it_;
    /** Private constructor.
      * @param[in] inp_mesh Pointer to a mesh of interest
      * @param[in] inp_idx  Idx of host node
      * @param[in] inp_it Iterator into host node's adj_tri set
      */
    node_tri_iterator(const tet_mesh_type* inp_mesh, const size_type inp_idx, 
      typename std::set<size_type>::iterator inp_it)
      : tmesh_(const_cast<tet_mesh_type*>(inp_mesh)), node_idx_(inp_idx), it_(inp_it) {
     }
  };



  /** @class TetMesh::Node::node_tet_iterator
   * @brief Iterator class for tets adjacent to nodes. A forward iterator. */
  class node_tet_iterator : private totally_ordered<node_tet_iterator> {
   public:
    // These type definitions help us use STL's iterator_traits.
    /** Element type. */
    typedef Tetrahedron value_type;
    /** Type of pointers to elements. */
    typedef Tetrahedron* pointer;
    /** Type of references to elements. */
    typedef Tetrahedron& reference;
    /** Iterator category. */
    typedef std::input_iterator_tag iterator_category;
    /** Difference between iterators */
    typedef std::ptrdiff_t difference_type;

    /** Construct an invalid tet_iterator. */
    node_tet_iterator()
    : tmesh_(0), node_idx_(0), it_() {
    }

    /** Tetrahedron operator*() const */
    Tetrahedron operator*() const {
     return Tetrahedron( tmesh_, (*it_) );
    }
    /** Incrementation operator. */
    node_tet_iterator& operator++() {
        ++it_;
        return (*this);
    }
    /** Comparison. */
    bool operator==(const node_tet_iterator& rhs) const {
     return( (tmesh_ == rhs.tmesh_) && (node_idx_ == rhs.node_idx_) 
      && (it_ == rhs.it_) );
    }

   private:
    friend class TetMesh;
    /** Data members. */
    tet_mesh_type* tmesh_;
    size_type  node_idx_;
    typename std::set<size_type>::iterator it_;
    /** Private constructor.
      * @param[in] inp_mesh Pointer to a mesh of interest
      * @param[in] inp_idx  Idx of host node
      * @param[in] inp_it Iterator into host node's adj_tet set
      */
    node_tet_iterator(const tet_mesh_type* inp_mesh, const size_type inp_idx, 
      typename std::set<size_type>::iterator inp_it)
      : tmesh_(const_cast<tet_mesh_type*>(inp_mesh)), node_idx_(inp_idx), it_(inp_it) {
     }
  };


  /** @class TetMesh::Triangle::tri_tri_iterator
   * @brief Iterator class for triangles adjacent to given triangle. A forward iterator. */
  class tri_tri_iterator : private totally_ordered<tri_tri_iterator> {
   public:
    // These type definitions help us use STL's iterator_traits.
    /** Element type. */
    typedef Triangle value_type;
    /** Type of pointers to elements. */
    typedef Triangle* pointer;
    /** Type of references to elements. */
    typedef Triangle& reference;
    /** Iterator category. */
    typedef std::input_iterator_tag iterator_category;
    /** Difference between iterators */
    typedef std::ptrdiff_t difference_type;

    /** Construct an invalid tet_iterator. */
    tri_tri_iterator()
    : tmesh_(0), it_() {
    }

    /** Triangle operator*() const */
    Triangle operator*() const {
     return Triangle( tmesh_, (*it_) );
    }
    /** Incrementation operator. */
    tri_tri_iterator& operator++() {
        ++it_;
        return (*this);
    }
    /** Comparison. */
    bool operator==(const tri_tri_iterator& rhs) const {
     return( (tmesh_ == rhs.tmesh_)  
      && (it_ == rhs.it_) );
    }

   private:
    friend class TetMesh;
    /** Data members. */
    tet_mesh_type* tmesh_;
    typename std::set<size_type>::iterator it_;
    /** Private constructor.
      * @param[in] inp_mesh Pointer to a mesh of interest
      * @param[in] inp_it Iterator into host triangle's adj_tri set
      */
    tri_tri_iterator(const tet_mesh_type* inp_mesh, 
      typename std::set<size_type>::iterator inp_it)
      : tmesh_(const_cast<tet_mesh_type*>(inp_mesh)), it_(inp_it) {
     }
  };


  /** @class TetMesh::Triangle::tri_tet_iterator
   * @brief Iterator class for tetrahedra adjacent to given triangle. A forward iterator. */
  class tri_tet_iterator : private totally_ordered<tri_tet_iterator> {
   public:
    // These type definitions help us use STL's iterator_traits.
    /** Element type. */
    typedef Tetrahedron value_type;
    /** Type of pointers to elements. */
    typedef Tetrahedron* pointer;
    /** Type of references to elements. */
    typedef Tetrahedron& reference;
    /** Iterator category. */
    typedef std::input_iterator_tag iterator_category;
    /** Difference between iterators */
    typedef std::ptrdiff_t difference_type;

    /** Construct an invalid tet_iterator. */
    tri_tet_iterator()
    : tmesh_(0), it_() {
    }

    /** Tetrahedron operator*() const */
    Tetrahedron operator*() const {
     return Tetrahedron( tmesh_, (*it_).first );
    }
    /** Incrementation operator. */
    tri_tet_iterator& operator++() {
        ++it_;
        return (*this);
    }
    /** Comparison. */
    bool operator==(const tri_tet_iterator& rhs) const {
     return( (tmesh_ == rhs.tmesh_)  
      && (it_ == rhs.it_) );
    }

   private:
    friend class TetMesh;
    /** Data members. */
    tet_mesh_type* tmesh_;
    typename std::map<size_type,size_type>::iterator it_;
    /** Private constructor.
      * @param[in] inp_mesh Pointer to a mesh of interest
      * @param[in] inp_it Iterator into host triangle's adj_tet map
      */
    tri_tet_iterator(const tet_mesh_type* inp_mesh, 
      typename std::map<size_type,size_type>::iterator inp_it)
      : tmesh_(const_cast<tet_mesh_type*>(inp_mesh)), it_(inp_it) {
     }
  };


  /** @class TetMesh::Tetrahedron::tet_tet_iterator
   * @brief Iterator class for tetrahedra adjacent to given triangle. A forward iterator. */
  class tet_tet_iterator : private totally_ordered<tet_tet_iterator> {
   public:
    // These type definitions help us use STL's iterator_traits.
    /** Element type. */
    typedef Tetrahedron value_type;
    /** Type of pointers to elements. */
    typedef Tetrahedron* pointer;
    /** Type of references to elements. */
    typedef Tetrahedron& reference;
    /** Iterator category. */
    typedef std::input_iterator_tag iterator_category;
    /** Difference between iterators */
    typedef std::ptrdiff_t difference_type;

    /** Construct an invalid tet_iterator. */
    tet_tet_iterator()
    : tmesh_(0), it_() {
    }

    /** Tetrahedron operator*() const */
    Tetrahedron operator*() const {
     return Tetrahedron( tmesh_, (*it_) );
    }
    /** Incrementation operator. */
    tet_tet_iterator& operator++() {
        ++it_;
        return (*this);
    }
    /** Comparison. */
    bool operator==(const tet_tet_iterator& rhs) const {
     return( (tmesh_ == rhs.tmesh_)  
      && (it_ == rhs.it_) );
    }

   private:
    friend class TetMesh;
    /** Data members. */
    tet_mesh_type* tmesh_;
    typename std::set<size_type>::iterator it_;
    /** Private constructor.
      * @param[in] inp_mesh Pointer to a mesh of interest
      * @param[in] inp_it Iterator into host tetrahedron's adj_tet set
      */
    tet_tet_iterator(const tet_mesh_type* inp_mesh, 
      typename std::set<size_type>::iterator inp_it)
      : tmesh_(const_cast<tet_mesh_type*>(inp_mesh)), it_(inp_it) {
     }
  };

 private:
  /** TetMesh data members - vectors of data structures corresponding to objects by index. */
  std::vector<Nodeinfo> nodes_;
  std::vector<Edgeinfo> edges_;
  std::vector<Triinfo> triangles_;
  std::vector<Tetinfo> tetrahedra_;

  /** Private methods. */

  /** Add adge between nodes with indices i and j. */
  Edge add_edge( size_type i, size_type j ) {
   // Check for self-edge insertion
   if ( i == j ) {
    return Edge();
   }
   // Sort the input indices
   size_type min_idx = std::min( i, j );
   size_type max_idx = std::max( i, j );
   // Index of the edge under construction
   size_type eidx = edges_.size();

   auto insert_result = nodes_[max_idx].adj_nodes.insert(std::make_pair(min_idx,eidx));

   if ( insert_result.second ) {
    // True means a unique edge is added - update the other node's data
    nodes_[min_idx].adj_nodes.insert(std::make_pair(max_idx, eidx));
    edges_.push_back(Edgeinfo(min_idx,max_idx)); 
    // Also write the initial length of the new edge into edges_ vector
    edges_[eidx].init_length = norm( nodes_[max_idx].coord - nodes_[min_idx].coord );
    if ( edges_[eidx].init_length < -1.0*eps ) {
     cout << "ATTENTION: edge w/index " << eidx << "\nbtw nodes:\n" 
      << "Index " << min_idx << " at " << nodes_[min_idx].coord << "\n" 
      << "Index " << max_idx << " at " << nodes_[max_idx].coord << "\n";
     cout << "Has length " << edges_[eidx].init_length << "\n\n";
    }
   }
   
   else { // Fetch the existing edge index 
    eidx = (insert_result.first)->second;
   }
   return Edge( this, eidx );
  }

  /** Add a triangle to the mesh. 
    * @param[in] inp_idx Array with 3 indices of nodes in this mesh, not equal pair-wise.
    */
  Triangle add_triangle( std::array<size_type,3>& inp_idx ) {
   size_type tidx = triangles_.size();
   // Check if a triangle already exists
   if ( has_triangle( inp_idx, tidx ) ) { // True means it exists, return it
    return Triangle( this, tidx );
   }
   else { // Insert the triangle:
    // Add another entry to the triangles_ vector
    triangles_.push_back(Triinfo());
    for ( size_type i = 0; i < 3; ++i ) {
     // Update the nodes' info by inserting this triangle idx into nodes_[].adj_tri set
     nodes_[inp_idx[i]].adj_tri.insert(tidx);
     // Put the index of that node into triangle info
     triangles_[tidx].nodes[i] = inp_idx[i];
     // Create edges between the nodes, upholding RI: node(i) opposes edge(i)
     auto e = add_edge( inp_idx[idx_pair(i).first], inp_idx[idx_pair(i).second] ); 
     // Put the index of the edge into triangle's info
     triangles_[tidx].edges[i] = e.idx_;
     // Update the list of adjacent triangles
     for ( auto it = edges_[e.idx_].adj_tri.begin(); it != edges_[e.idx_].adj_tri.end(); ++it ) {
      //Insert the indices of adj triangles into the set of this one
      triangles_[tidx].adj_tri.insert( (*it).first );
      //Insert the indices of this triangle into sets of adjacent ones
      triangles_[(*it).first].adj_tri.insert(tidx);
     }
     // Update edges info by inserting this triangle's id into their edges_[]adj_tri set.
     edges_[e.idx_].adj_tri[tidx] = i;
    }
    //Compute the initial area
    triangles_[tidx].init_area = 0.5 * norm( cross( 
       ( node(inp_idx[0]).position() - node(inp_idx[2]).position() ),
       ( node(inp_idx[0]).position() - node(inp_idx[1]).position() ) ) );
   }
   if ( triangles_[tidx].init_area < -1.0*eps ) {
    cout << "ATTENTION: triangle w/index " << tidx << "\nbtw nodes:\n";
    for (size_type j = 0; j < 3; ++j ) {
     cout << "Index " << inp_idx[j] << " at " << nodes_[inp_idx[j]].coord << "\n";
    }
    cout << "has area of " << triangles_[tidx].init_area;
   }
   // End of add_triangle
   return Triangle(this,tidx);
  }
 
  /** Helper methods. */

  /** Returns a normal to the plane spanned by first 3 input points, and pointing 
    * away from 4th input point.
    * @param[in] inp_pts Vector containing 4 Points
    */
  Point normal( std::vector<Point>& inp_pts ) const {
   assert(inp_pts.size() == 4);
   Point tnormal = cross(
     ( inp_pts[0] - inp_pts[1] ),
     ( inp_pts[0] - inp_pts[2] ) );

   // Make sure that the normal points away from the last Point in the input
   Point ref = inp_pts[3] - inp_pts[0];
   if( inner_prod( tnormal, ref ) > 0.0 ) {
    tnormal = -1.0 * tnormal / norm(tnormal);
   }
   else {
    tnormal = tnormal / norm(tnormal);
   }
   return tnormal;
  }

  /** Figure out if the tetrahedron formed by points 1,2,3,4 and 1,2,5,6 overlap spatially.
    * @param[in] pts References to Points between which the tetrahedra are added
    * @pre pts.size() == 6
    */
  bool tet_overlap (const std::vector<Point>& pts) const {
   // First, compute the normal to triangle made of pts[0,1,2] pointing away from pts[3],
   // then, the normal to triangle pts[0,1,3] pointing away from pts[2] - those will 
   // be the outward normals to triangles of existing tet containing edge btw pts[0,1]
   // Then we'll check if pts[4,5] lie inside the dihedral angle spanned by those triangles
   std::vector<Point> temp_pts(4);
   temp_pts[0] = pts[0];
   temp_pts[1] = pts[1];
   temp_pts[2] = pts[2];
   temp_pts[3] = pts[3];
   Point n1 = normal(temp_pts);
   temp_pts.pop_back();
   temp_pts.pop_back();
   temp_pts.push_back(pts[3]);
   temp_pts.push_back(pts[2]);
   Point n2 = normal(temp_pts);
   // Set up vectors pointing from pts[0] to pts[4,5]
   Point ref1 = pts[4] - pts[0];
   Point ref2 = pts[5] - pts[0];
   // Aux bools
   bool tag1 = false; // for pts[4]
   bool tag2 = false; // for pts[5]
   // Check if pts[4,5] coincide with pts[2,3]
   if ( pts[4] == pts[2] ) {
    tag1 = true;
    // Then the ref2 vector HAS to point in the same direction as outer normal to 
    // triangle pts[0,1,2]
    if ( inner_prod( n1, ref2 ) < eps ) {
     return true;
    }
   }
   if ( pts[4] == pts[3] ) {
    tag1 = true;
    // Then the ref2 vector HAS to point in the same direction as outer normal to 
    // triangle pts[0,1,3]
    if ( inner_prod( n2, ref2 ) < eps ) {
     return true;
    }
   }
   if (tag1 == false ) { 
    // Then the pts[4] does not coincide with anything, check if ref1 is within the dihedral 
    // angle spanned by triangles of pts[0,1,2] and pts[0,1,3]
    if ( ( inner_prod( n1, ref1 ) < eps ) && ( inner_prod( n2, ref1 ) < eps ) ) {
     return true;
    }
   }
   if ( pts[5] == pts[2] ) {
    tag2 = true;
    // Then the ref1 vector HAS to point in the same direction as outer normal to 
    // triangle pts[0,1,2]
    if ( inner_prod( n1, ref1 ) < eps ) {
     return true;
    }
   }
   if ( pts[5] == pts[3] ) {
    tag2 = true;
    // Then the ref1 vector HAS to point in the same direction as outer normal to 
    // triangle pts[0,1,3]
    if ( inner_prod( n2, ref1 ) < eps ) {
     return true;
    }
   }
   if ( tag2 == false ) {
    // Then pts[5] does not coincide with anything, ref2 vector has to be outside of dihedral
    // angle spanned by triangles of pts[0,1,2] and pts[0,1,3]
    if ( ( inner_prod( n1, ref2 ) < eps ) && ( inner_prod( n2, ref2 ) < eps ) ) {
     return true;
    }
   }

   // Now carry out the same procedure, only check if pts[2,3] are within dihedral angle 
   // spanned by triangles pts[0,1,4] and pts[0,1,5]

   temp_pts.pop_back();
   temp_pts.pop_back();
   temp_pts.push_back(pts[4]);
   temp_pts.push_back(pts[5]);
   n1 = normal(temp_pts);
   temp_pts.pop_back();
   temp_pts.pop_back();
   temp_pts.push_back(pts[5]);
   temp_pts.push_back(pts[4]);
   n2 = normal(temp_pts);
   // Set up vectors pointing from pts[0] to pts[4,5]
   ref1 = pts[2] - pts[0];
   ref2 = pts[3] - pts[0];
   // Aux bools
   tag1 = false; // for pts[2]
   tag2 = false; // for pts[3]
   // Check if pts[2,3] coincide with pts[4,5]
   if ( pts[2] == pts[4] ) {
    tag1 = true;
    // Then the ref2 vector HAS to point in the same direction as outer normal to 
    // triangle pts[0,1,4]
    if ( inner_prod( n1, ref2 ) < eps ) {
     return true;
    }
   }
   if ( pts[2] == pts[5] ) {
    tag1 = true;
    // Then the ref2 vector HAS to point in the same direction as outer normal to 
    // triangle pts[0,1,5]
    if ( inner_prod( n2, ref2 ) < eps ) {
     return true;
    }
   }
   if (tag1 == false ) { 
    // Then the pts[2] does not coincide with anything, check if ref1 is within the dihedral 
    // angle spanned by triangles of pts[0,1,4] and pts[0,1,5]
    if ( ( inner_prod( n1, ref1 ) < eps ) && ( inner_prod( n2, ref1 ) < eps ) ) {
     return true;
    }
   }
   if ( pts[3] == pts[4] ) {
    tag2 = true;
    // Then the ref1 vector HAS to point in the same direction as outer normal to 
    // triangle pts[0,1,4]
    if ( inner_prod( n1, ref1 ) < eps ) {
     return true;
    }
   }
   if ( pts[3] == pts[5] ) {
    tag2 = true;
    // Then the ref1 vector HAS to point in the same direction as outer normal to 
    // triangle pts[0,1,5]
    if ( inner_prod( n2, ref1 ) < eps ) {
     return true;
    }
   }
   if ( tag2 == false ) {
    // Then pts[3] does not coincide with anything, ref2 vector has to be outside of dihedral
    // angle spanned by triangles of pts[0,1,4] and pts[0,1,5]
    if ( ( inner_prod( n1, ref2 ) < eps ) && ( inner_prod( n2, ref2 ) < eps ) ) {
     return true;
    }
   }
   // If all checks do not detect overlap, return false
   return false;
  }

  /** Helper function to map the "internal index" of the edge within the tetrahedron containing 
    it (in range[0,5]) to the pairs of numbers in range [0,3]  such that:
    1 - this edge CONTAINS to the nodes with output "internal indices" 
    2 - this edge shares only 1 node with each of faces with output "internal indices"
    */
  std::pair<size_type,size_type> edge2nodes( size_type inp_idx ) const {
   std::pair<size_type,size_type> result;
   switch (inp_idx) {
    case 0:
     result =  std::make_pair(2,3);
     break;
    case 1:
     result =  std::make_pair(1,3);
     break;
    case 2:
     result =  std::make_pair(1,2);
     break;
    case 3:
     result =  std::make_pair(0,3);
     break;
    case 4:
     result =  std::make_pair(0,2);
     break;
    case 5:
     result =  std::make_pair(0,1);
     break;
    default:
     cout << "Error in edge2nodes for internal index " << inp_idx << std::endl;
   }
   return result;
  }

  /** Helper function for add_tetrahedron, maps integers [0,3] to arrays of all integers 
    in range [0,3], except the input one. E.g., 0 -> {1,2,3}, 1 -> {0,2,3}... */
  std::array<size_type,3> idx_tet( size_type inp ) const {
   std::array<size_type,3> result;
   switch (inp) {
    case 0:
     result[0] = 1;
     result[1] = 2;
     result[2] = 3;
     break;
    case 1:
     result[0] = 0;
     result[1] = 2;
     result[2] = 3;
     break;
    case 2:
     result[0] = 0;
     result[1] = 1;
     result[2] = 3;
     break;
    case 3:
     result[0] = 0;
     result[1] = 1;
     result[2] = 2;
     break;
    default:
     cout << "Error in idx_tet for input " << inp << std::endl;
   }
   return result;
  }  

  /** Helper function to map the "internal index" of the edge within the tetrahedron containing 
    it (in range[0,5]) to the pairs of numbers in range [0,3]  such that:
    1 - this edge is OPPOSITE to the nodes with output "internal indices"
    2 - this edge is at intersection of faces with output "internal indices"
    */
  std::pair<size_type,size_type> edge2opp_nodes( size_type inp_idx ) const {
   std::pair<size_type,size_type> result;
   switch (inp_idx) {
    case 0:
     result =  std::make_pair(0,1);
     break;
    case 1:
     result =  std::make_pair(0,2);
     break;
    case 2:
     result =  std::make_pair(0,3);
     break;
    case 3:
     result =  std::make_pair(1,2);
     break;
    case 4:
     result =  std::make_pair(1,3);
     break;
    case 5:
     result =  std::make_pair(2,3);
     break;
    default:
     cout << "Error in edge2opp_nodes for internal index " << inp_idx << std::endl;
   }
   return result;
  }

  /** Helper function for add_triangle - returns
    * std::pair(1,2) for 0,
    * std::pair(0,2) for 1,
    * std::pair(0,1) for 2.
    */
  std::pair<size_type,size_type> idx_pair( size_type i ) {
   switch (i) {
    case 0:
     return std::make_pair(1,2);
    case 1: 
     return std::make_pair(0,2);
    case 2:
     return std::make_pair(0,1);
   }
   cout << "Error in idx_pair!\n\n";
   return std::make_pair(0,0);
  }

  static constexpr double eps = -0.000000001;
};
