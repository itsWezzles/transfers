Bill Lotter and Wesley Chen
CS207 Final Project README

Summary:
   We worked on extending the Mesh design to allow for additional forces on the surface on the mesh.  The majority of the work was down in our own extension - looking to make it both modular and versatile when it came to adding forces - demonstrating with a provided test main program - shallow_water.cpp.  When integrating, we wanted smoother animations that could be done with collaborations of SDLViewer extensions.  We demonstrate a variety of surface forces, including a boat that moves in circles, at a rate that can be adjusted by keypress.  Our final project folder also includes a tetrahedral mesh which acts as a mass spring in a similar way to HW2 with combined force functors and constraints.  We also sought to implement a wind force into the tetrahedral mesh - similar to the other forces which could have its magnitude and direction controlled through keyboard input.

Our public prompt 3 extension repository can be cloned at:
   git@code.seas.harvard.edu:billlotterwesleychen-cs207/hw4.git

Our final project repository (this repo of this README file) can be cloned at:
   git@code.seas.harvard.edu:wesleychen-cs207/wesleychen-cs207.git

New Original Files:
   QVar.hpp - header for the struct that we use for our shallow_water triangle
   shallow_water.cpp (of our mesh extension public release repo) - only with surface forces, no integration/collaboration
   shallow_water.cpp (of finalProject repo) - final project version with full integration/collaboration
   shallow_water_forces_and_sources - header file containing the additions to the Mesh class of HW4 that adds in the bathymetry and the floating boat forces calculations and functions

New Collaborative Files:
   libs/SDLViewer.hpp - new SDL to allow smooth imaging of triangles
   tet_mesh.hpp - the tetrahedral mesh class 
   tet_propagator.cpp - a main program that demonstrates the mass-spring tetrahedral
   data/cow.nodes and data/cow.tets - nodes + tets file in the shape of a cow - from collaborators

Usage of Example Mains:

   Note: for shallow-water, press up and down to increase the angular speed of boat

   ./shallow_water data/pond3.nodes data/pond3.tris 3: Surface visualization starting from still pond, with external forces
   ./shallow_water data/pond3.nodes data/pond3.tris 2: Surface visualization with dam break

   Note: for tet_propagator, use up and down (and see console output) to increase magnitude of wind
   press z and x to raise/lower the z dimension of wind, and a and s to raise/lwoer the y dimension of wind

   ./tet_propagtor data/tiny.nodes data/tiny.tets: to see wire frame of single tetrahedron
   ./tet_propagator data/medium.nodes data/medium.tets: to see mass spring on the medium data set

General Mesh Design (from HW4):
   2 Private Member Graphs
   One containing all the physical nodes and edges to be displayed by the SDL
   One treating every triangle as a node and the adjacent triangles as nodes connected by edges
   Wrapper classes help give desired access vs private values especially for node and edge values and iterators

Final Project Extension Code Details (Prompt 3)
   Please refer to the code for carefully documented design notes/specifications/conditions- see list of New Original Files

Original Provided Features:
   See code for more detailed explanations
   Bathymetry "floor" for shallow water simulations
   Bomb force - a sharp depression followed by balancing out
   Boat going in circles force - a boat moving around in a central circle
   Brownian motion boat - as description
   Various initial states (3 from HW4 + 1 still pond, best to see the other forces"

Post-Collaboration Features:
   Surface SDL visualizations
   Interactivity with angular speed controleld by up, down key press
   Tetrahedral mass spring with wind, controlled by up, down, z, x, a, s key presses

Collaborators:

Xinyi Guo and Philip Mocz (Prompt 5):
   Xinyi and Philip created a new SDLViewer.hpp file which added some additional functions which we call on to add to the Viewer.  Their code is extremely well documented with a very organized tutorial/example code.

   We were able to call on add_triangle much like add_nodes and add_edges, including with color and position functors.  This was our main interface with their header.  We had to change a convention in indexing - for some reason they required nodes of a triangle being indexed from 1 to 3, while our Mesh class had indexed starting from 0.  After this fix, we were able to use their SDLViewer to replace the default one.

   To integrate their viewer, we used a color functor assigned to each node - scaled between 0 and 1 and colored to represent the water column height value per node.  The collaborated SDL file would take this node-based color functor and assign colors to the triangles smoothly based on the nodes in a process very similar to assigning nodes a given color with the standard STL.

   The SDLViewerNew.cpp is also set up to take in certain listeners for further interactivity - which is by the nature of the new SDLViewer already incorporated.   Many of the forces in shallow_water run itself after initialization.  However, we incorporated a boat force that goes in circles at a variable angular speed controllable by up and down key presses.

   We use their listener template to create our own listener for interactivity for the tetrahedral mass-spring.  This is done using their interface but of our own detection of keypress and function.  Functions were written for up and down key presses in shallow_water and up, down, z, x, a, s in tet_propagator.


Ellie Zhang and Daniel Newman (Prompt 1):
   As spoken about below, (see Dmitry and Salvatore's collaboration below) we wished to take the wind force to implement some interaction with our shallow-water but upon looking at their code, realized that prompt 1's setup was a mass-spring style - similar to HW2, which had a wind force just as another force like gravity which is already built in to their structure.  There was no analogous wind force to apply to the shallow-water setup.  Wind, in our case, would say, move a "boat" which would just be redefining our boat force done which can be done in our extension's portion.  Thus, we applied the wind force to the tetrahedral mesh which as a mass-spring system, was more suitable for an analogous transition.


Dmitry Vinichenko and Salvatore Rinchiera (Prompt 2):
   The second prompt of a tetrahedral mesh was interesting and had been our second choice in projects so we wanted to establish a collaboration.  We were able to clone their code see how they designed their mesh.  A couple optimization changes in the class were made for constant time operations similar to those in our Mesh Class.  However, since the tetrahedral mesh was a totally separate class and not an extension on the current Mesh (the tetrahedral functions more like mass-spring) we have included those files as separate files in our "folder" of mesh-like extensions - perhaps better called like "physics pack".

   We took the tetrahedral and added similar integrated components like color with add_triangles  of Xinyi an Philip (which didn't visualize well and was removed since the tetrahedral mesh is 3D and the coloring was not transparent) and a wind force from Ellie and Daniel interactively controlled by a listener.

   The main controls, which are best seen through the tiny.nodes/tiny.tets, are the following (all of which are console logged): up and down to control wind magnitude, z and x to increase/decrease the z component of the wind velocity and a and s to increase/decrease the y component of the wind velocity.


Bo Han and Kevin Schmidt (Prompt 1):
   The inflatable mesh-spring design was intended to be incorporated - specifically we wanted the apply some wind forces to our shallow water pond.  Code was shared, however, was their full final project repository which already had all of their integrations and was difficult to isolate their work.  Even when we tried to pick apart a specific portion (the wind force), we found that they had not implemented a wind force and stuck solely to the inflatable mesh.  We recognized that the inflatable mesh portion would not make much physical sense to integrate with our shallow water forces since they are governed by 2 different sets of equations: the shallow water equations on a "flat mesh" vs the mass-spring equations on a 3D closed volume.  Thus this collaboration was set up but not incorporated.
