
#include "CS207/Util.hpp"
#include "CS207/SDLViewerNew.hpp"
#include "CS207/Color.hpp"
#include "CS207/Point.hpp"
#include <fstream>
#include <initializer_list>

#include "TetMesh.hpp"
using namespace std;

/* Adjust these values for more or less damping effect */
double g_dashpot_damping_constant = .75;
double g_volume_penalty_constant = .75;

// Gravity in meters/sec^2
static constexpr double grav = 9.81;

typedef double mass_type;
typedef int stif_type;
typedef double dist_type;

/** Structure for holding node mass and velocity. */
struct Nodedata_mv {

 /** Default constructor. */
 Nodedata_mv()
  : m(), v() {
  }

 /** Parameterized constructor.
   * @param[in] inp_mass Mass to be assigned to the node
   * @param[in] inp_velocity Velocity to be assigned
   */
 Nodedata_mv( const mass_type inp_mass, const Point inp_velocity)
  : m(inp_mass), v(inp_velocity) {
  }

 /** Data members. */
 mass_type m; /*< Mass */
 Point v; /*< Velocity */
};

struct Edgedata_k {

 /** Default constructor. */
 Edgedata_k()
  : k() {
  }

 /** Data members. */
 stif_type k; /*< Stiffness constant. */
};

typedef TetMesh<Nodedata_mv,Edgedata_k,int,int> MeshType;
typedef MeshType::Node Node;
typedef MeshType::Edge Edge;

/** Change a Mesh's nodes according to a step of the symplectic Euler
 *    method with the given node force.
 * @param[in,out] m Mesh
 * @param[in] t The current time (useful for time-dependent forces)
 * @param[in] dt The time step
 * @param[in] force Function object defining the force per node
 * @param[in] constr Constraint object operating on a mesh
 * @pre G::node_data_type has @a v - velocity (Point) and @a m - mass
 * @return the next time step (usually @a t + @a dt)
 *
 * @a force is called as @a force(n, @a t), where n is a node of the mesh
 * and @a t is the current time parameter. @a force must return a Point
 * representing the node's force at time @a t.
 */
template <typename M, typename F, typename C>
double symp_euler_step_constr(M& m, double t, double dt, F force, C constr) {
 //Iterate over nodes first time to update the coordinates
 for (auto ni = m.node_begin(); ni != m.node_end(); ++ni) {
  //HW2 #3 - exceptions for the corners of the cloth
   (*ni).set_position( (*ni).position() + (*ni).data().v * dt );
 }

 // Apply constraint
 constr(m,t);

 //Now update the velocities
 for (auto ni = m.node_begin(); ni != m.node_end(); ++ni) {
  (*ni).data().v += force( (*ni), t ) * dt / (*ni).data().m ;
 }

 return t + dt;
}

struct NullConstr {

 /** Default-z constructor. */
 NullConstr( ){ }

 /** Functor for resetting the positions and velocities of the mesh nodes
   violating constraint node().position().z < con_z
   */
 void operator() (MeshType& inp_mesh, double t = 0) {
     (void) inp_mesh;
     (void) t;
 }
};


/* Same as before but with no constraints */
template <typename M, typename F>
double symp_euler_step(M& m, double t, double dt, F force) {

 return symp_euler_step_constr(m, t, dt, force, NullConstr());
}

struct PlaneConstr {
 /** Data members. */
 double con_z;

 /** Default-z constructor. */
 PlaneConstr( )
  : con_z(-0.75) {
  }

 /** Parameterized constructor. */
 PlaneConstr(const double inp_z )
  : con_z(inp_z) {
  }

 /** Functor for resetting the positions and velocities of the mesh nodes
   violating constraint node().position().z < con_z
   */
 void operator() (MeshType& inp_mesh, double t = 0) {
  (void) t;
  auto end = inp_mesh.node_end();
  for( auto it = inp_mesh.node_begin(); it != end; ++it) {
   if ( (*it).position().z < con_z ) {
    //Reset position
    Point new_pos( (*it).position().x, (*it).position().y, con_z);
    (*it).set_position(new_pos);
    //Reset velocity, z-component
    (*it).data().v.z = 0;
   }
  }
 }
};

template <typename NODE>
struct Force {
  /* All force functors inherit this force and must implement the operator */
  virtual Point operator()(NODE n, double t) = 0;
};

// interaction factor for wind force
double wind_const = 0.009;

Point normal_val = Point (0,0,10);

// wind velocity constant
Point wind_velocity_const = Point(0.0, 0.0, 1.0);

template<typename NODE>
struct WindForce : Force<NODE> {
 private:
   Point wind_velocity_;  
 public:
   // public constructor: given wind velocity
   WindForce(const Point& wind_velocity) : wind_velocity_(wind_velocity) {};
   // public constructor: use the default wind velocity
   WindForce() : wind_velocity_(wind_velocity_const) {}

  Point operator()(NODE n, double t) {
    (void) t;
    Point node_velocity = n.data().v;
    Point node_normal = normal_val;
    Point windforce = wind_const * dot(wind_velocity_ - node_velocity, node_normal) * node_normal;

    return windforce;
  }
};

template <typename NODE>
struct GravityForce : Force<NODE> {
  /** Return the gravity force applying to @a n at time @a t.
   */
  Point operator()(NODE n, double t) {
   (void) t;
   //Set up the direction of free fall acceleration
   Point g(0,0,-1*grav);
   //Use that to compute m*g
   Point grav_force = n.data().m * g;
   //Add to the resulting force
   return grav_force;
  }
};

template <typename NODE>
struct DashpotForce : Force<NODE> {
  /** Return the dashpot force applying to @a n at time @a t. */

 /** Data members. */
 double c; /*< Damping coefficient */

 /** Default constructor. */
 DashpotForce()
  : c(1) {
  }

 /** Parameterized constructor. */
 DashpotForce(const double inp_c)
  : c(inp_c) {
  }

  Point operator()(NODE n, double t) {
   (void) t;

   Point dashpot_force(0,0,0);
   for( auto ii = n.edge_begin(); ii != n.edge_end(); ++ii ) {

    Node ni = (*ii).node1();
    Node nj = (*ii).node2();

    Point xi = ni.position();
    Point xj = nj.position();

    Point vi = ni.data().v;
    Point vj = nj.data().v;


    double spring_constant = ((*ii).data().k);
    dist_type length = (*ii).length();
    dist_type rest_length = (*ii).init_length();

    // Math is on assignmnet
    dashpot_force -= ((spring_constant * ((length) - rest_length)) + (c * ((dot((vi - vj), (xi - xj))) / length))) * ((xi - xj) / length);

   }
   return dashpot_force;
 }
};

template <typename NODE>
struct VolumePenaltyForce : Force<NODE> {
 /* Force acts in opposite direction of changing tetrahedral volume */

 /** Data members. */
 double k; /*< Penalty coefficient */

 /** Default constructor. */
 VolumePenaltyForce()
  : k(1) {
  }

 /** Parameterized constructor. */
 VolumePenaltyForce(const double inp_k)
  : k(inp_k) {
  }

  /** Apply volume penalty force. */
  Point operator()(NODE n, double t) {
   (void) t;

   Point volume_penalty(0,0,0);
   Point pos = n.position();

   for( auto ii = n.tet_begin(); ii != n.tet_end(); ++ii ) {

    Node n0 = (*ii).node(0);
    Node n1 = (*ii).node(1);
    Node n2 = (*ii).node(2);
    Node n3 = (*ii).node(3);

    Point x0 = n0.position();
    Point x1 = n1.position();
    Point x2 = n2.position();
    Point x3 = n3.position();

    mass_type m0 = n0.data().m;
    mass_type m1 = n1.data().m;
    mass_type m2 = n2.data().m;
    mass_type m3 = n3.data().m;

    Point barycenter = (m0*x0 + m1*x1 + m2*x2 + m3*x3) / (m0 + m1 + m2 + m3);

    // Math is on assignmnet
    volume_penalty -= (k * ((*ii).volume() - (*ii).init_volume())) * ((pos - barycenter) / norm(pos-barycenter));
   }
   return volume_penalty;
 }
};


template <typename F, typename NODE>
class CombinedForce {
  /* Implements multiple force acting on mesh */

  public:

  /* Constructor which takes initializer list of forces */
  CombinedForce( std::initializer_list<F *> force_list ) {
    for( F *elem : force_list ) {
      _forces.push_back(elem);
    }
  }

  Point operator()(NODE n, double t) {
    Point sum_forces = Point(0,0,0);
    // Call each force operator and add them together
    for(auto it = _forces.begin(); it != _forces.end(); ++it) {
        sum_forces += (*(*it))(n, t);
    }

    return sum_forces;
  }

  private:
  std::vector<F *> _forces;
};

// sample SDL listener
struct my_listener : public CS207::SDL_Listener {
  void handle(SDL_Event e) {   // we are forced to implement this function
    switch (e.type) {
      case SDL_KEYDOWN: {
        // Keyboard 'c' to center
        if (e.key.keysym.sym == SDLK_UP) {
          wind_const *= 1.1;
          cout << "New Wind Mag: " << wind_const << std::endl;
        }
        if (e.key.keysym.sym == SDLK_DOWN) {
          wind_const *= 0.9;
          cout << "New Wind Mag: " << wind_const << std::endl;
        }
        if (e.key.keysym.sym == SDLK_z) {
          normal_val.z += 1;
          cout << "New Wind Vel: " << normal_val.x << " " << normal_val.y << " " << normal_val.z << std::endl;
        }
        if (e.key.keysym.sym == SDLK_x) {
          normal_val.z -= 1;
          cout << "New Wind Vel: " << normal_val.x << " " << normal_val.y << " " << normal_val.z << std::endl;
        }
        if (e.key.keysym.sym == SDLK_a) {
          normal_val.y += 1;
          cout << "New Wind Vel: " << normal_val.x << " " << normal_val.y << " " << normal_val.z << std::endl;
        }
        if (e.key.keysym.sym == SDLK_s) {
          normal_val.y -= 1;
          cout << "New Wind Vel: " << normal_val.x << " " << normal_val.y << " " << normal_val.z << std::endl;
        }
      } break;
    }
  }
  
  // constructor
  my_listener(CS207::SDLViewer& viewer, MeshType& mesh) : viewer_(viewer), mesh_(mesh) {};
  private:
   CS207::SDLViewer& viewer_;
   MeshType& mesh_;
};

int main(int argc, char* argv[])
{
  // Check arguments
  if (argc < 3) {
    std::cerr << "Usage: ./tet_propagator NODES_FILE TETS_FILE\n";
    exit(1);
  }

  MeshType mesh;
  // HW4B: Need node_type before this can be used!
  std::vector<typename MeshType::node_type> mesh_node;

  // Read all Points and add them to the Mesh
  std::ifstream nodes_file(argv[1]);
  Point p;
  while (CS207::getline_parsed(nodes_file, p)) {
    // HW4B: Need to implement add_node before this can be used!
    mesh_node.push_back(mesh.add_node(p));
  }

  // Read all mesh triangles and add them to the Mesh
  std::ifstream tets_file(argv[2]);
  std::array<unsigned,4> t;
  while (CS207::getline_parsed(tets_file, t)) {
    // HW4B: Need to implement add_triangle before this can be used!
   mesh.add_tetrahedron(t);
  }

  // Print out the stats
  std::cout << "Total:\n" << mesh.num_nodes() << " nodes\n"
            << mesh.num_edges() << " edges\n"
            << mesh.num_triangles() << " triangles\n"
	    << mesh.num_tetrahedra() << " tetrahedra\n" << std::endl;


  CS207::SDLViewer viewer;
  auto node_map = viewer.empty_node_map(mesh);
  viewer.launch();

  viewer.add_nodes(mesh.node_begin(), mesh.node_end(), node_map);

  // viewer.add_triangles(mesh.triangle_begin(), mesh.triangle_end(), node_map);
  viewer.add_edges(mesh.edge_begin(), mesh.edge_end(), node_map);

  viewer.center_view();

  // add listener
  my_listener* l = new my_listener(viewer,mesh); 
  viewer.add_listener(l);

  // Initializing the data in nodes
  for ( auto ni = mesh.node_begin(); ni != mesh.node_end(); ++ni ) {
   (*ni).data().m = 1.0/mesh.num_nodes();
   (*ni).data().v = Point(0.,0.,0.);
  }

  // Initializing data in the edges
  for ( auto ei = mesh.edge_begin(); ei != mesh.edge_end(); ++ei ) {
   //Set up the same force constant
   (*ei).data().k = 100;
  }

  // Begin the mass-spring simulation
  double dt = 0.000001;
  double t_start = 0;
  double t_end = 5.0;

  CombinedForce <Force<Node>, Node>combined_force(
          { new GravityForce<Node>(),
            new DashpotForce<Node>(g_dashpot_damping_constant),
            new VolumePenaltyForce<Node>(g_volume_penalty_constant),
            new WindForce<Node>()
          });

  for (double t = t_start; t < t_end; t += dt) {

    symp_euler_step_constr( mesh, t, dt, combined_force, PlaneConstr());

    // Update viewer with nodes' new positions
    viewer.add_nodes(mesh.node_begin(), mesh.node_end(), node_map);
    viewer.set_label(t);
  }

  return 0;
}
