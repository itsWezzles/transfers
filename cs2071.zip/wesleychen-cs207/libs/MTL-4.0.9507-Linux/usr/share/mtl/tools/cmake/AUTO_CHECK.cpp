
int main()
{
    auto x= 8.3 - 7u;

    return 0;
}
