#include <math.h>
#include "Point.hpp"
#include "CS207/Util.hpp"
#include "QVar.hpp"

static constexpr double grav_const = 9.80665;

double boat_angular = 2 * M_PI;

/* Determines if @a p1 @a p2 are on the same side of the plane split by the line through @a a and @a b
 * @pre: p1, p2, a, b are all coplanar
 */
bool on_same_side(Point p1, Point p2, Point a, Point b){
	Point cp1 = cross(b-a, p1-a);
	Point cp2 = cross(b-a, p2-a);
	if ( dot(cp1, cp2) >= 0){
		return true;
	}else{
		return false;
	}
};

/* Determines if @a p is in the triangle defined by the points @a a, @a b, @a c
 * @pre: p, a, b, c are all coplanar
 */
bool point_in_triangle(Point p, Point a, Point b, Point c){
	if ( on_same_side(p,a,b,c) && on_same_side(p,b,a,c) && on_same_side(p,c,a,b)){
		return true;
	}else{
		return false;
	}
};

/* A functor that returns a zero force for all triangles at all times. */
struct DefaultForce{
	template <typename TRIANGLE>
	double operator()(TRIANGLE& tri, double t){
		(void) tri;
		(void) t;
		return 0.0;
	}
};

/* Force functor that simulates a bomb going off. 
 * The force of the bomb only acts at one time step and at one tesselation of space.
 */
struct BombForce{
	double detonate_time;  // time the bomb will explode
	Point location;  // location where the bomb will explode
	double pressure; // pressure exerted by the bomb

	typedef double ret_type;  // return type of the functor

  private:
	bool has_exploded;
	double actual_detonate_time;

  public:

  	/* Constructor.  
  	 * @param[in] location_ location where the bomb will go off.  
  	 * @param[in] det_time_ time the bomb will detonate
  	 * @param[in] pressure_ pressure exerted by the bomb
  	 * @pre: location_.z == 0 
  	 * @pre: det_time >= 0
  	 */ 
	BombForce(double det_time_ = 0.5, Point location_ = Point(0,0,0), double pressure_ = 50.0) : detonate_time(det_time_), location(location_), pressure(pressure_) {
		has_exploded = false;
	};

	/* @pre:  TRIANGLE must have member functions area() and node(i) for i=0,1,2;  node(i).position() must return a Point */ 
	template <typename TRIANGLE>
	ret_type operator()(TRIANGLE& tri, double t){
		if (t<detonate_time){
			return 0.0;
		}
		
		if (!has_exploded){
			actual_detonate_time = t;
			has_exploded = true;
		}
		if ( t == actual_detonate_time){
			if (point_in_triangle(location, tri.node(0).position(), tri.node(1).position(), tri.node(2).position())){
				return pressure*tri.area();
			}
			else{
				return 0.0;
			}
		}
		else{
			return 0.0;
		}
	}
};

/* Force functor representing a boat exhibiting uniform circular motion. "Boat" exerts pressure at one tesselation in space. */
struct BoatGoingInCirclesForce{
	Point center;
	double radius;
	double pressure;
	double starting_angle;

	typedef double ret_type;   // return type of the functor

  private:	
	double last_update_t;
	Point current_position;

	void update_position(double t){
		current_position = center + Point(radius*cos(starting_angle+boat_angular*t), radius*sin(starting_angle+boat_angular*t), 0);
	}
  
  public:

  	/* Constructor.
  	 * @param[in] center_ center around which the boat is traveling
  	 * @param[in] start_time time at which the boat is placed on surface and starts traveling.
  	 * @param[in] starting_angle_ angle (in radians) with respect to x-axis that the boat starts
  	 * @pre:  center_.z == 0
  	 * @pre:  start_time > 0
  	 */
	BoatGoingInCirclesForce(Point center_ = Point(0,0,0), double radius_ = 0.5, double pressure_ = 10.0, double start_time = 0.0, double starting_angle_ = 0.0){
		center = center_;	
		radius = radius_;
		pressure = pressure_;
		last_update_t = start_time;
		starting_angle = starting_angle_;
	};

	/* @pre:  TRIANGLE must have member functions area() and node(i) for i=0,1,2;  node(i).position() must return a Point */ 
	template <typename Triangle>
	ret_type operator() (Triangle& tri, double t){

		if (t < last_update_t){
			return 0.0;
		}
		else if (t > last_update_t){
			update_position(t);
			last_update_t = t;
		};

		if (point_in_triangle(current_position, tri.node(0).position(), tri.node(1).position(), tri.node(2).position())){
			return pressure*tri.area();
		}
		else{
			return 0.0;
		}
	}
};

/* Force functor representing a boat exhibiting Brownian motion whose (x,y) coordinate is constrained to a specified rectangular region. 
   "Boat" exerts pressure at one tesselation in space. */
struct DiffusingBoatForce{
	double min_x;
	double max_x;
	double min_y;
	double max_y;
	double diffuse_rate;
	double pressure;

	typedef double ret_type;   // return type of the functor

  private:
	Point current_position;
	double last_update_t;
	std::default_random_engine generator;
	double dr;
	Point proposed_position;

	bool point_in_domain(Point& p){
		return (p.x >= min_x && p.x <= max_x && p.y >= min_y && p.y <= max_y);
	};

	/* Updates position of boat by choosing a change in position that follows a distribution of a Gaussian centered at current position */
	void update_position (double dt){
		std::normal_distribution<double> dist (0.0, diffuse_rate*sqrt(dt));
		Point proposed_position;
		double angle;
		double dr;
		do {
			angle = M_PI * (double)std::rand() / RAND_MAX;
			dr = dist(generator);
			proposed_position = current_position + Point(cos(angle)*dr, sin(angle)*dr, 0.0);
		}
		while( !point_in_domain(proposed_position));
		current_position = proposed_position;
	};

  public:	

  	/* Constructor.
  	 * @param[in] min_x_, max_x_, min_y_, max_y_ define box in which boat is allowed to diffuse
  	 * @param[in] start_time time at which the boat is placed on surface and starts traveling.
  	 * @param[in] starting_position_ position where the boat starts
  	 * @param[in] diffuse_rate_  rate at which the boat diffuses
  	 * @pre:  start_position_.z == 0 and start_position_ is in box defined by min_x_, max_x_, min_y_, max_y_
  	 * @pre:  start_time > 0
  	 */
	DiffusingBoatForce(double min_x_ = 0.0, double max_x_ = 1.0, double min_y_ = 0.0, double max_y_ = 0.0, Point start_position_ = Point(0,0,0), double diffuse_rate_ = 0.1, double start_time = 0.0, double pressure_ = 20.0) {
		min_x = min_x_;
		max_x = max_x_;
		min_y = min_y_;
		max_y = max_y_;
		diffuse_rate = diffuse_rate_;
		current_position = start_position_;
		last_update_t = start_time;
		pressure = pressure_;
	}

	/* @pre:  TRIANGLE must have member functions area() and node(i) for i=0,1,2;  node(i).position() must return a Point */ 
	template <typename Triangle>
	ret_type operator() (Triangle& tri, double t){

		if (t < last_update_t){
			return 0.0;
		}
		else if (t > last_update_t){
			update_position(t - last_update_t);
			last_update_t = t;
		};

		if (point_in_triangle(current_position, tri.node(0).position(), tri.node(1).position(), tri.node(2).position())){
			return pressure*tri.area();
		}
		else{
			return 0.0;
		};
	};
};


/* A functor representing the combining of two functors 
 * @pre:  F1, F2 are functors with a trait called ret_type which is the same for both functors */
template <typename F1, typename F2>
struct ComboFunct{
  F1 funct1_;
  F2 funct2_;
  ComboFunct(const F1& funct1, const F2& funct2) : funct1_(funct1), funct2_(funct2) {};

  template <typename TRIANGLE>
  typename F2::ret_type operator()(const TRIANGLE& tri, double t){
    return funct1_(tri,t) + funct2_(tri,t);
  }
};

/* Combines two functors 
 * @pre:  F1, F2 are functors with a trait called ret_type which is the same for both functors */
template <typename F1, typename F2>
ComboFunct<F1,F2> make_combined_functor(F1 f1, F2 f2) {
  return ComboFunct<F1,F2>(f1, f2);
};

/* Combines three functors
 * @pre:  F1, F2, F3 are functors with a trait called ret_type which is the same for all three functors */
template <typename F1, typename F2, typename F3>
ComboFunct<ComboFunct<F1,F2>,F3> make_combined_functor(F1 f1, F2 f2, F3 f3) {
  ComboFunct<F1,F2> f12(f1,f2); 
  return ComboFunct<ComboFunct<F1,F2>,F3>(f12, f3);
};


/* A source term for shallow water equations that incorporates bathymetry.  
 * BFXN b is a functor representing the height of the floor that the water flows over.  It has an operator() that takes as input a Point and a double and returns a double */
template <typename BFXN>
struct BathymetrySource{
	BFXN b;

	typedef QVar ret_type;    // return type of the functor

  private:
  	double x_min, x_max, y_min, y_max;
  	double dbdx, dbdy;

  public:

	BathymetrySource(BFXN& b_) : b(b_) {}

	/* @pre:  TRIANGLE must have member functions node(i) for i=0,1,2 and value().  value().h must be a double*/ 
	template <typename TRIANGLE>
	ret_type operator() (const TRIANGLE& tri, double t){
		x_min = std::min(tri.node(0).position().x, std::min(tri.node(1).position().x, tri.node(2).position().x));
		x_max = std::max(tri.node(0).position().x, std::max(tri.node(1).position().x, tri.node(2).position().x));
		y_min = std::min(tri.node(0).position().y, std::min(tri.node(1).position().y, tri.node(2).position().y));
		y_max = std::max(tri.node(0).position().y, std::max(tri.node(1).position().y, tri.node(2).position().y));
		dbdx = (b(Point(x_max, (y_min + y_max)/2.0, 0), t) - b(Point(x_min, (y_min + y_max)/2.0, 0), t) )/ (x_max - x_min);
		dbdy = (b(Point((x_min + x_max)/2.0, y_max, 0), t) - b(Point((x_min + x_max)/2.0, y_min, 0), t) )/ (y_max - y_min); 
		return QVar(0, -grav_const*tri.value().h*dbdx, -grav_const*tri.value().h*dbdy);
	}
};

/* A functor that simulates the height of a surface that is described by a 1D power law.  
 * The surface rotates around an origin in time with a speed described by @a angular_speed.
 * height(x,y) = k*(d^exponent)  where d is the component of (x,y) that is parallel to the gradient of the surface.
 * To be used as a "BFXN" for a BathymetrySource */
struct RotatingCurvedFloor{
	double k;   // height ~ k*(d^exponent) 
	double initial_angle;
	double angular_speed;
	double exponent;
	Point origin;

	typedef double ret_type;   // return type of the functor

  private:
  	Point uhat;
  	double last_update_t;

  public:

  	/* Constructor.
  	 * @param[in] k_ multiplicative constant in power law
  	 * @param[in] initial_angle_ starting angle in radians with respect to x-axis of the gradient of the surface
  	 * @param[in] angular_speed_ speed of rotation in radians/time 
  	 * @param[in] exponent_ power of the power law
  	 */
	RotatingCurvedFloor(double k_ = 0.0001, double initial_angle_ = 0.0, double angular_speed_ = 2*M_PI, double exponent_ = 3, Point origin_ = Point(0,0,0)) : k(k_), initial_angle(initial_angle_), angular_speed(angular_speed_), exponent(exponent_), origin(origin_) {
		uhat = Point(cos(initial_angle), sin(initial_angle), 0);
		last_update_t = 0.0;
	}

	ret_type operator() (const Point& p, double t){
		if (t != last_update_t){
			uhat = Point(cos(initial_angle + angular_speed*t), sin(initial_angle + angular_speed*t), 0);
			last_update_t = t;
		}
		return k*pow(dot(uhat, p-origin),exponent);
	}
};

/* Functor to be used in shallow water equations that represents a localized source corresponding to a "fountain" (@a rate > 0) or a "sink" (@a rate < 0).
 * The location of the fountain/sink can be specified as well as the rate.  The rate corresponds to change in height of the water everytime the operator() is called
 * for the TRIANGLE in which the fountain/sink is located.
 */
struct FountainOrSink{
	Point location;
	double rate;   

	typedef QVar ret_type;   // return type of the functor

	FountainOrSink(Point location_ = Point(0,0,0), double rate_ = 0.1) : location(location_), rate(rate_) {}

	/* @pre: Height of water column of triangle in which the fountain/sink is located can have a change in height of @a rate.  (e.g. for negative rates, the height won't drop below 0) */
	template <typename TRIANGLE>
	ret_type operator() (const TRIANGLE& tri, double t){
		(void) t;
		if (point_in_triangle(location, tri.node(0).position(), tri.node(1).position(), tri.node(2).position())){
			return QVar(rate,0,0);
		}
		else{
			return QVar(0,0,0);
		}

	}
};
