/**
 * @file shallow_water.cpp
 * Implementation of a shallow water system using Mesh
 *
 * @brief Reads in two files specified on the command line.
 * First file: 3D point list (one per line) defined by three doubles
 * Second file: Triangles (one per line) defined by 3 indices into the point list
 */

#include "CS207/SDLViewerNew.hpp"
#include "CS207/Util.hpp"
#include "CS207/Color.hpp"
#include "CS207/Point.hpp"
#include <fstream>
#include <math.h>
#include "shallow_water_forces_and_sources.hpp"
#include "Mesh.hpp"
#include "QVar.hpp"

// Standard gravity (average gravity at Earth's surface) in meters/sec^2
static constexpr double grav = 9.80665;

static constexpr double rho = 1.0;

// functor for comparing node heights
struct NodeHeightComparator {
  NodeHeightComparator() {};
  template <typename NODE>
  bool operator() (const NODE& n1, const NODE& n2) {
    return n1.value().h > n2.value().h;
  }
};

// functor for comparing edge length
struct EdgeLengthComparator {
  EdgeLengthComparator() {};
  template <typename EDGE>
  bool operator()(const EDGE& e1, const EDGE& e2){
    return e1.length() < e2.length();
  }
};

// H(x) from the spec equations, 1 if negative, else 0
double heaviside(const double& x){
  if (x < 0.0) {
    return 1.0;
  }
  else {
    return 0.0;
  }
}


/*
*/
struct TanhNodeColor{
  double scale_factor;
  double offset;

  TanhNodeColor(double scale_factor_ = 5.0, double offset_ = 1.0 ) : scale_factor(scale_factor_), offset(offset_) {}

  template <typename NODE>
  CS207::Color operator()(const NODE& n) const { 
    return CS207::Color::make_heat( 0.5+0.5*tanh(scale_factor * (n.value().h - offset)) );
  }
};



/** Function object for calculating shallow-water flux.
 *          |e
 *   T_k    |---> n = (nx,ny)   T_m
 *   QBar_k |                   QBar_m
 *          |
 * @param[in] nx, ny Defines the 2D outward normal vector n = (@a nx, @a ny)
 *            from triangle T_k to triangle T_m. The length of n is equal to the
 *            the length of the edge, |n| = |e|.
 * @param[in] dt The time step taken by the simulation. Used to compute the
 *               Lax-Wendroff dissipation term.
 * @param[in] qk The values of the conserved variables on the left of the edge.
 * @param[in] qm The values of the conserved variables on the right of the edge.
 * @return The flux of the conserved values across the edge e
 */
struct EdgeFluxCalculator {
  template <typename FORCE, typename TRIANGLE>
  QVar operator()(double nx, double ny, double dt,
                  const QVar& qk, const QVar& qm, double t, FORCE& force, const TRIANGLE& trik, const TRIANGLE& trim) {
    double e_length = sqrt(nx*nx + ny*ny);
    nx /= e_length;
    ny /= e_length;

    // The velocities normal to the edge
    double wm = (qm.hu*nx + qm.hv*ny) / qm.h;
    double wk = (qk.hu*nx + qk.hv*ny) / qk.h;

    // Lax-Wendroff local dissipation coefficient
    double vm = sqrt(grav*qm.h) + sqrt(qm.hu*qm.hu + qm.hv*qm.hv) / qm.h;
    double vk = sqrt(grav*qk.h) + sqrt(qk.hu*qk.hu + qk.hv*qk.hv) / qk.h;
    double a  = dt * std::max(vm*vm, vk*vk);

    // Helper values
    double scale = 0.5 * e_length;
    double gh2   = 0.5 * grav * (qm.h*qm.h + qk.h*qk.h) + (force(trik, t)*qk.h/(rho*trik.area()) + force(trim,t)*qm.h/(rho*trim.area()));

    // Simple flux with dissipation for stability
    return QVar(scale * (wm*qm.h  + wk*qk.h)           - a * (qm.h  - qk.h),
                scale * (wm*qm.hu + wk*qk.hu + gh2*nx) - a * (qm.hu - qk.hu),
                scale * (wm*qm.hv + wk*qk.hv + gh2*ny) - a * (qm.hv - qk.hv));
  }
};

/** Node position function object for use in the SDLViewer. */
struct NodePosition {
  template <typename NODE>
  Point operator()(const NODE& n) {
    //assert(n.position().z == 0); // assuming all nodes are on x-y plane
    return n.position() + Point(0,0,n.value().h); // set z-cord to the calculated value for viewing
  }
};

/** Node position function object for use in the SDLViewer. */
struct NodeColor {
  template <typename NODE>
  Point operator()(const NODE& n) {
    //assert(n.position().z == 0); // assuming all nodes are on x-y plane
    return n.position() + Point(0,0,n.value().h); // set z-cord to the calculated value for viewing
  }
};

// create our Mesh with proper template parameters
typedef Mesh<QVar,unsigned,QVar> MeshType;

/** Integrate a hyperbolic conservation law defined over the mesh m
 * with flux functor f by dt in time.
 */
template <typename MESH, typename FLUX, typename FORCE, typename SOURCE>
double hyperbolic_step(MESH& m, FLUX& f, double t, double dt, FORCE& force, SOURCE& source) {

  // Step the finite volume model in time by dt.
  std::vector<QVar> dQ (m.num_triangles(), QVar(0,0,0));
  QVar Qm;
  typename MESH::Triangle trim;

  
  // for all triangles
  unsigned i = 0;
  unsigned j = 0;
  for (auto it = m.triangle_begin(); it != m.triangle_end(); ++it) {

    // for each possible adjacent triangle, sharing one of the 3 sides
    for (j = 0; j < 3; ++j) {
      if (m.is_shared_edge( (*it).edge(j) )) {
        Qm = (m.adj_triangle(*it, (*it).edge(j))).value();
        trim = (m.adj_triangle(*it, (*it).edge(j)));
      }
      // else boundary condition
      else {
        Qm = QVar((*it).value().h,0,0);
        trim = (*it);
      }
     
      // update
      dQ[i] = dQ[i] + (-dt/(*it).area()) * f(  (*it).edge_normal(j).x, (*it).edge_normal(j).y, dt, (*it).value(), Qm, t, force, (*it), trim);
    }
    dQ[i] = dQ[i] + (dt/(*it).area()) * source((*it), t);
    ++i; 
  }

  // update new values in value once all are calculated
  unsigned x = 0;
  for (auto it = m.triangle_begin(); it != m.triangle_end(); ++it){

      (*it).value() = (*it).value() + dQ[x];
      ++x;
  };

  // return next time step
  return t + dt;
}

/** Convert the triangle-averaged values to node-averaged values for viewing. */
template <typename MESH>
void post_process(MESH& m) {
  // translate the triangle-averaged values to node-averaged values
  QVar q;
  double a; 

  // for all graph nodes
  for (auto it = m.node_begin(); it != m.node_end(); ++it){
    q.h = 0; q.hv = 0; q.hu = 0;
    a=0;

    // calc weighted average using area
    for (auto it2 = (*it).adj_triangle_begin(); it2 != (*it).adj_triangle_end(); ++it2){

      q += (*it2).area() * (*it2).value();
      a += (*it2).area();
    }

    // update physical node value
    (*it).value() = (1.0/a) * q;
  }
}

/** Set initial conditions based on what type of system we're modelling which is called from command line and stored in variable*/
void set_initial_conditions(MeshType& m, unsigned ic_version) {
  double h;
  // Pebble in a pond
  if (ic_version == 0){
    for (auto it = m.node_begin(); it != m.node_end(); ++it){
      h = 1 - 0.75 * exp(-80.0 * ( pow((*it).position().x - 0.75,2) + pow((*it).position().y,2)) );
      (*it).value() = QVar(h,0,0);
    }
  }
  // Release of large, sharp column of water
  else if (ic_version == 1){
    for (auto it = m.node_begin(); it != m.node_end(); ++it){
      h = 1 + 0.75 * heaviside( pow((*it).position().x - 0.75,2) + pow((*it).position().y,2) - pow(0.15,2) );
      (*it).value() = QVar(h,0,0);
    }
  }
  // Dam break and a temporary waterfall
  else if (ic_version == 2){
    for (auto it = m.node_begin(); it != m.node_end(); ++it){
      h = 1 + 0.75 * heaviside( (*it).position().x );
      (*it).value() = QVar(h,0,0);
    }
  }
  else{
    for (auto it = m.node_begin(); it != m.node_end(); ++it){
      (*it).value() = QVar(1.0,0,0);
    }
  }

  QVar q;
  int i;
  for (auto it = m.triangle_begin(); it != m.triangle_end(); ++it){
    q.h = 0; q.hv = 0; q.hu = 0;
    for (i = 0; i < 3; ++i){
      q = q + (*it).node(i).value();
    }
    (*it).value() = (1.0/3.0)*q;
  }
}

// sample SDL listener
struct my_listener : public CS207::SDL_Listener {
  void handle(SDL_Event e) {   // we are forced to implement this function
    switch (e.type) {
      case SDL_KEYDOWN: {
        // Keyboard 'c' to center
        if (e.key.keysym.sym == SDLK_UP) {
          boat_angular *= 1.1;
          cout << "Boat Angular Speed: " << boat_angular << std::endl;
        }
        if (e.key.keysym.sym == SDLK_DOWN) {
          boat_angular *= 0.9;
          cout << "Boat Angular Speed: " << boat_angular << std::endl;
        }
      } break;
    }
  }
  
  // constructor
  my_listener(CS207::SDLViewer& viewer, MeshType& mesh) : viewer_(viewer), mesh_(mesh) {};
  private:
   CS207::SDLViewer& viewer_;
   MeshType& mesh_;
};

int main(int argc, char* argv[])
{
  // Check arguments
  if (argc < 3 || argc > 4) {
    std::cerr << "Usage: shallow_water NODES_FILE TRIS_FILE [modelType]\n";
    exit(1);
  }

  // create our mesh and nodes
  MeshType mesh;
  std::vector<MeshType::node_type> mesh_node;

  // Read all Points and add them to the Mesh
  std::ifstream nodes_file(argv[1]);
  Point p;
  while (CS207::getline_parsed(nodes_file, p)) {
    mesh_node.push_back(mesh.add_node(p));
  }

  // Read all mesh triangles and add them to the Mesh
  std::ifstream tris_file(argv[2]);
  std::array<int,3> t;
  while (CS207::getline_parsed(tris_file, t)) {
    mesh.add_triangle(mesh_node[t[0]], mesh_node[t[1]], mesh_node[t[2]]);
  }

  // Print out the stats
  std::cout << mesh.num_nodes() << " "
            << mesh.num_edges() << " "
            << mesh.num_triangles() << std::endl;

  // Set the initial conditions to command line argument if possible defaulted to 1
  int ic_version = 1;
  if (argc == 4) {
    int val = atoi(argv[3]);
    if (val >= 0 && val <= 3)
    ic_version = val;
  }

  // Perform any needed precomputation passing in command line
  set_initial_conditions(mesh, ic_version);

  double min_x, max_x, min_y, max_y;
  double mean_h = 0;
  for (auto it = mesh.node_begin(); it != mesh.node_end(); ++it){
    if (it == mesh.node_begin()){
      min_x = (*it).position().x;
      max_x = (*it).position().x;
      min_y = (*it).position().y;
      max_y = (*it).position().y;
    }
    else{
      min_x = std::min(min_x, (*it).position().x);
      max_x = std::max(max_x, (*it).position().x);
      min_y = std::min(min_y, (*it).position().y);
      max_y = std::max(max_y, (*it).position().y);
    }
    mean_h += (*it).value().h/mesh.num_nodes();
  }

  DiffusingBoatForce force1(min_x,max_x, min_y, max_y);
  //DefaultForce force;
  BombForce force2;
  BoatGoingInCirclesForce force3;

  auto force = make_combined_functor(force1, force2, force3);

  RotatingCurvedFloor bfxn;
  BathymetrySource<RotatingCurvedFloor> source1(bfxn);
  FountainOrSink source2;
  auto source = make_combined_functor(source1, source2);

  // Launch the SDLViewer
  CS207::SDLViewer viewer;
  viewer.launch();

  TanhNodeColor color_funct(5,mean_h);

  // add nodes via node_begin()
  auto node_map = viewer.empty_node_map(mesh);
  viewer.add_nodes(mesh.node_begin(), mesh.node_end(),
                   color_funct, NodePosition(), node_map);
  //viewer.add_edges(mesh.edge_begin(), mesh.edge_end(), node_map);
  viewer.add_triangles(mesh.triangle_begin(), mesh.triangle_end(), node_map);
  viewer.center_view();

  // add listener
  my_listener* l = new my_listener(viewer,mesh); 
  viewer.add_listener(l);

  // CFL stability condition requires dt <= dx / max|velocity|
  // For the shallow water equations with u = v = 0 initial conditions
  //   we can compute the minimum edge length and maximum original water height
  //   to set the time-step
  // Compute the minimum edge length and maximum water height for computing dt

  auto max_height_it = std::max_element(mesh.node_begin(), mesh.node_end(), NodeHeightComparator());
  double max_height = (*max_height_it).value().h;
  auto min_edge_length_it = std::min_element(mesh.edge_begin(), mesh.edge_end(), EdgeLengthComparator());
  double min_edge_length = (*min_edge_length_it).length();
  double dt = 0.25 * min_edge_length / (sqrt(grav * max_height));

  // simulation time constraints
  double t_start = 0;
  double t_end = 10;

  // Preconstruct a Flux functor
  EdgeFluxCalculator f;


  // Begin the time stepping
  for (double t = t_start; t < t_end; t += dt) {

    //std::cout<< "time: " << t << std::endl;

    // Step forward in time with forward Euler
    hyperbolic_step(mesh, f, t, dt, force, source);

    // Update node values with triangle-averaged values
    post_process(mesh);

    // Update the viewer with new node positions
    viewer.add_nodes(mesh.node_begin(), mesh.node_end(),
                     color_funct, NodePosition(), node_map);
    viewer.set_label(t);

    // These lines slow down the animation for small meshes.
    if (mesh.num_nodes() < 100)
      CS207::sleep(0.01);
  }

  return 0;
}
