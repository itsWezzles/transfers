/**
 * @file poisson.cpp
 * Test script for treating the Graph as a MTL Matrix
 * and solving a Poisson equation.
 *
 * @brief Reads in two files specified on the command line.
 * First file: 3D Points (one per line) defined by three doubles.
 * Second file: Edges (one per line) defined by 2 indices into the point list
 *              of the first file.
 *
 * Launches an SDLViewer to visualize the solution.
 */

#include "CS207/SDLViewer.hpp"
#include "CS207/Util.hpp"
#include "CS207/Color.hpp"

#include "BoundingBox.hpp"
#include "Graph.hpp"
#include "Point.hpp"

#include <cmath>
#include <fstream>
#include <iostream>
#include <boost/numeric/mtl/mtl.hpp>
#include <boost/numeric/itl/itl.hpp>

struct node_info { bool boundary; };
struct edge_info {};

typedef Graph<node_info,edge_info> GraphType;
typedef GraphType::Node Node;
typedef GraphType::Edge Edge;

class GraphSymmetricMatrix {
 private: GraphType& g_;
 public:
  GraphSymmetricMatrix(GraphType& g) : g_(g) {}
  inline std::size_t dim() const { return g_.size(); }

  template <typename VectorIn, typename VectorOut, typename Assign>
  void mult(const VectorIn& v, VectorOut& w, Assign) const {
    for (auto jit = g_.node_begin(); jit != g_.node_end(); ++jit) {
      auto nj = *jit; GraphType::size_type j = nj.index();
      double result = (nj.value().boundary) ? v[j] : -(double)nj.degree()*v[j];
      for (auto eit = nj.edge_begin(); eit != nj.edge_end(); ++eit) {
        auto ni = (*eit).node2(); GraphType::size_type i = ni.index();
        if (!(ni.value().boundary || nj.value().boundary)) result += v[i];
      }
      Assign::apply(w[j], result);
    }
  }
  template <typename VectorIn>
  mtl::vector::mat_cvec_multiplier<GraphSymmetricMatrix, VectorIn>
  operator*(const VectorIn& v) const {
    return mtl::vector::mat_cvec_multiplier<GraphSymmetricMatrix, VectorIn>(*this, v);
  }
};

inline std::size_t size(const GraphSymmetricMatrix& A) {
  return A.dim()*A.dim();
}
inline std::size_t num_rows(const GraphSymmetricMatrix& A) { return A.dim(); }
inline std::size_t num_cols(const GraphSymmetricMatrix& A) { return A.dim(); }

namespace mtl {
  namespace ashape {
    template<>
    struct ashape_aux<GraphSymmetricMatrix> {
      typedef nonscal type;
    };
  }
  template<>
  struct Collection<GraphSymmetricMatrix> {
    typedef double value_type;
    typedef unsigned size_type;
  };
}

class ForcingFunction {
  public:
  double operator()(Point p) { return 5.0*cos(norm_1(p)); }
};
class BoundaryFunction {
  public:
  // @return true if p is in domain (result in res), false otherwise
  bool operator()(Point p, double& res) {
    if (norm_inf(p) == 1.0) { res = 0; return true; }
    if (norm_inf(p-Point(.6,.6,0)) < .2 || norm_inf(p-Point(.6,-.6,0)) < .2
     || norm_inf(p-Point(-.6,.6,0)) < .2 || norm_inf(p-Point(-.6,-.6,0)) < .2) {
      res = -0.2; return true;
    }
    BoundingBox bb (Point(-.6,-.2,-1), Point(.6,.2,1));
    if (bb.contains(p)) { res = 1; return true; }
    return false;
  }
};

template <typename VECTOR>
class PoissonSolutionPosition {
 private: VECTOR soln_;
 public:
  PoissonSolutionPosition(const VECTOR& soln) : soln_(soln) {}

  template <typename NODE>
  Point operator()(const NODE& node) {
    Point p = node.position();
    return Point(p.x, p.y, soln_[node.index()]);
  }
};

template <typename VECTOR>
class HeatColor {
 private: VECTOR soln_; const double max_;
 public:
  HeatColor(const VECTOR& soln, const double max) : soln_(soln), max_(max) {};

  template <typename NODE>
  CS207::Color operator()(const NODE& node) {
    return CS207::Color::make_heat(abs(soln_[node.index()]/max_));
  }
};

template <class Graph, class Viewer, class Vector, class Real,
          class OStream = std::ostream>
class visual_iteration : public itl::cyclic_iteration<Real, OStream>
{
 private:
  typedef itl::cyclic_iteration<Real, OStream> super;
  typedef visual_iteration self;
  const Graph& g_;
  const Vector& u_;
  Viewer v_;

  void visualize() {
    v_.clear();
    auto node_map = v_.empty_node_map(g_);
    double max = 0;
    for (unsigned i = 0; i < g_.num_nodes(); ++i)
      if (u_[i] > max) max = u_[i];
    if (max == 0) max = 1;
    v_.add_nodes(g_.node_begin(), g_.node_end(), HeatColor<Vector>(u_, max),
                 PoissonSolutionPosition<Vector>(u_), node_map);
    v_.add_edges(g_.edge_begin(), g_.edge_end(), node_map);
  }
 public:
  visual_iteration(const Graph& g, const Vector& u, const Vector& r0,
                   int max_iter_, Real tol_, Real atol_ = Real(0),
                   int cycle_ = 100, OStream& out = std::cout) :
                   super(r0, max_iter_, tol_, atol_, cycle_, out),
                   g_(g), u_(u) {
    v_.launch();
  }
  bool finished() { return super::finished(); }

  template <typename T>
  bool finished(const T& r) {
    bool ret = super::finished(r);
    if (this->i % super::cycle == 0) visualize();
    return ret;
  }
};

int main(int argc, char** argv)
{
  // Check arguments
  if (argc < 2) {
    std::cerr << "Usage: " << argv[0] << " NODES_FILE EDGES_FILE\n";
    exit(1);
  }

  // Construct the Graph
  GraphType graph;
  std::vector<typename GraphType::node_type> nodes;
  std::ifstream nodes_file(argv[1]);
  for (Point p; CS207::getline_parsed(nodes_file, p); )
    nodes.push_back(graph.add_node(p));
  std::ifstream tets_file(argv[2]);
  for (std::array<int,2> t; CS207::getline_parsed(tets_file, t); ) {
    graph.add_edge(nodes[t[0]], nodes[t[1]]);
  }
//  std::cout << "num_nodes:" << graph.num_nodes() << std::endl;
//  std::cout << "num_edges:" << graph.num_edges() << std::endl;

  // Construct the GraphSymmetricMatrix
  GraphSymmetricMatrix A (graph);
//  std::cout << "A.dim():" << A.dim() << std::endl;

  // Define b
  typedef mtl::dense_vector<double> vt;
  auto e_it = graph.edge_begin();
  const double h = norm((*e_it).node1().position()-(*e_it).node2().position());
  const double h_sq = h*h;
  vt b(A.dim());
  double res; ForcingFunction ff; BoundaryFunction bf;
  for (auto nit = graph.node_begin(); nit != graph.node_end(); ++nit) {
    Node n = *nit; GraphType::size_type idx = n.index();
    if (bf(n.position(), res)) { // node i is on a boundary
      n.value().boundary = true; b[idx] = res;
//      std::cout << "b[" << idx << "]=" << b[idx] << std::endl;
    } else {
      n.value().boundary = false; b[idx] = h_sq*ff(n.position());
//      std::cout << "b[" << idx << "]=" << b[idx] << std::endl;
      for (auto eit = n.edge_begin(); eit != n.edge_end(); ++eit) {
        if (bf((*eit).node2().position(), res)) b[idx] -= res;
      }
    }
  }
  std::cout << "b:" << b << std::endl;

  // Solve Au = b using MTL
  vt u(A.dim(), 0.0);
  itl::pc::identity<GraphSymmetricMatrix> P(A);
//  itl::basic_iteration<double> iter(b, 1000, 0);
//  itl::cyclic_iteration<double> iter(b, 1000, 0, 1e-9, 50);
  visual_iteration<GraphType, CS207::SDLViewer, vt, double> iter(graph, u, b, 1000, 0, 1e-9, 50);

//  std::cout << "b: " << b << std::endl;
  itl::cg(A, u, b, P, iter);
//  std::cout << "u: " << u << std::endl;

  return 0;
}
