#ifndef CS207_GRAPH_HPP
#define CS207_GRAPH_HPP

/** @file Graph.hpp
 * @brief An undirected graph type
 */

#include "CS207/Util.hpp"
#include "Point.hpp"
#include "MortonCoder.hpp"
#include "BoundingBox.hpp"

#include <algorithm>
#include <vector>
#include <cassert>
#include <unordered_map>
#include <unordered_set>

/** @class Graph
 * @brief A template for 3D undirected graphs.
 *
 * Users can add and retrieve nodes and edges. Edges are unique (there is at
 * most one edge between any pair of distinct nodes).
 */
template <typename V, typename E>
class Graph {
 private:
  // internal type for nodes
  struct node_data {
    unsigned uid;  // Unique ID for node
    Point position;  // The position of the node
    V value;  // user-specified value
  };
  // internal type for edges
  struct edge_data {
    unsigned n1_uid;  // Index of 1st Node of Edge
    unsigned n2_uid;  // Index of 2nd Node of Edge
    E value;
  };
  typedef std::vector<node_data> nodes_type;
  /** Type of node_map_ private field */
  typedef std::unordered_map<unsigned, unsigned> node_map_type;
  /** Type of edge_matrix_ private field */
  typedef std::unordered_set<unsigned> edge_set_type;
  typedef std::unordered_map<unsigned, edge_set_type> edge_matrix_type;
  /** Type of edges_ private field */
  typedef std::unordered_map<unsigned, edge_data> edges_map_type;
  typedef std::unordered_map<unsigned, edges_map_type> edges_type;
  /** Type of morton code to node uid set private field */
  typedef std::unordered_set<unsigned> node_set_type;
  typedef std::unordered_map<unsigned, node_set_type> code_to_node_set_type;

 public:

  /** Type of this graph. */
  typedef Graph graph_type;

  /** Predeclaration of Node type. */
  class Node;
  /** Synonym for Node (following STL conventions). */
  typedef Node node_type;

  /** Predeclaration of Edge type. */
  class Edge;
  /** Synonym for Edge (following STL conventions). */
  typedef Edge edge_type;

  /** Type of indexes and sizes. Return type of Node::index() and
      Graph::num_nodes(), argument type of Graph::node. */
  typedef unsigned size_type;

  /** Type of node iterators, which iterate over all graph nodes. */
  class node_iterator;

  /** Type of edge iterators, which iterate over all graph edges. */
  class edge_iterator;

  /** Type of incident iterators, which iterate incident edges to a node. */
  class incident_iterator;

  /** Type of user-specified value */
  typedef V node_value_type;
  typedef E edge_value_type;

  // CONSTRUCTOR AND DESTRUCTOR

  /** Construct an empty graph. */
  Graph() {
  }
  /** Default destructor */
  ~Graph() = default;

  // NODES

  /** @class Graph::Node
   * @brief Class representing the graph's nodes.
   *
   * Node objects are used to access information about the Graph's nodes.
   */
  class Node : private totally_ordered<Node> {
   public:
    /** Construct an invalid node.
     *
     * Valid nodes are obtained from the Graph class, but it
     * is occasionally useful to declare an @i invalid node, and assign a
     * valid node to it later. For example:
     *
     * @code
     * Node x;
     * if (...should pick the first node...)
     *   x = graph.node(0);
     * else
     *   x = some other node using a complicated calculation
     * do_something(x);
     * @endcode
     */
    Node() : graph_(nullptr), uid_(0) {}

    /** Return this node's position. */
    Point position() const {
      assert(graph_->node_map_.count(uid_) > 0);
      size_type index = graph_->node_map_[uid_];
      assert(0 <= index && index < graph_->size());
      return graph_->nodes_[index].position;
    }

    void set_position(const Point& p) {
      size_type index = graph_->node_map_[uid_];
      MortonCoder<>::code_type cur_code =
        graph_->mc_.code(graph_->nodes_[index].position);
      MortonCoder<>::code_type new_code = graph_->mc_.code(p);
      if (cur_code != new_code) {
        graph_->code_to_node_set_[cur_code].erase(uid_);
        graph_->code_to_node_set_[cur_code].insert(uid_);
      }
      graph_->nodes_[index].position = p;
    }

    /** Return this node's index, a number in the range [0, graph_size). */
    size_type index() const {
//      assert(graph_->node_map_.count(uid_) > 0);
      size_type index = graph_->node_map_[uid_];
//      assert(0 <= index && index < graph_->size());
      return index;
    }

    /** Return this node's value by reference (non-const) */
    node_value_type& value() {
      assert(graph_->node_map_.count(uid_) > 0);
      size_type index = graph_->node_map_[uid_];
      assert(0 <= index && index < graph_->size());
      return graph_->nodes_[index].value;
    }
    /** Return this node's value by reference (const) */
    const node_value_type& value() const {
      assert(graph_->node_map_.count(uid_) > 0);
      size_type index = graph_->node_map_[uid_];
      assert(0 <= index && index < graph_->size());
      return graph_->nodes_[index].value;
    }

    bool operator==(const Node& n) const {
      return graph_ == n.graph_ && uid_ == n.uid_;
    }
    bool operator< (const Node& n) const {
      return graph_ == graph_ && uid_ < n.uid_;
    }


    /** Return Node's degree.
     *
     * Complexity: amortized O(1).
     */
    size_type degree() const {
      auto em_it = graph_->edge_matrix_.find(this->uid_);
      if (em_it == graph_->edge_matrix_.end())
        return 0;
      return em_it->second.size();
    }
    /** Return beginning indicident_iterator.
     *
     * Complexity: amortized O(1).
     */
    incident_iterator edge_begin() const {
      auto em_it = graph_->edge_matrix_.find(this->uid_);
      edge_set_type::const_iterator es_it;
      if (em_it != graph_->edge_matrix_.end())
        es_it = em_it->second.begin();
      assert(graph_);
      return incident_iterator(this, em_it, es_it);
    }
    /** Return ending indicident_iterator.
     *
     * Complexity: amortized O(1).
     */
    incident_iterator edge_end() const {
      return incident_iterator(this, graph_->edge_matrix_.end(),
                               edge_set_type::const_iterator());
    }


   private:
    friend class Graph;
    Graph* graph_;  // Pointer to this Node's Graph
    size_type uid_;  // This Node's uid

    Node(const Graph* graph, size_type uid)
        : graph_(const_cast<Graph*>(graph)), uid_(uid) {}
  };

  /** Return the number of nodes in the graph.
   *
   * Complexity: O(1).
   */
  size_type size() const { return nodes_.size(); }

  /** Synonym for size(). */
  size_type num_nodes() const { return size(); }

  /** Add a node to the graph, returning the added node.
   * @param[in] position The new node's position
   * @post new size() == old size() + 1
   * @post result_node.index() == old size()
   * @post result_node.position() == position
   * @post result_node.value() == value
   *
   * Complexity: amortized O(1).
   */
  Node add_node(const Point& position,
                const node_value_type& value = node_value_type()) {
    size_type uid = cur_node_uid_;
    size_type index = nodes_.size();
    nodes_.push_back({uid, position, value});
    node_map_[uid] = index;  // remember mapping of Node's uid->index
    // insert morton code for this node
    code_to_node_set_[mc_.code(nodes_[index].position)].insert(uid);
    ++cur_node_uid_;
    return Node(this, uid);
  }

  /** Determine if this Node belongs to this Graph
   * @return True if @a n is currently a Node of this Graph
   *
   * Complexity: O(1).
   */
  bool has_node(const Node& n) const { return node_map_.count(n.uid_) > 0; }

  /** Return the node with index @a i.
   * @pre 0 <= @a i < size()
   * @post result_node.index() == i
   *
   * Complexity: O(1).
   */
  Node node(size_type i) const {
    assert(i < size());
    return Node(this, nodes_[i].uid);
  }

  /** Remove a node from the graph.
   * @param[in] n Node to be removed
   * @pre @a n is a valid node of this graph.
   * @post new size() == old size() - 1
   * @post has_node(n) == false
   * @post for any node n2, has_edge(n,n2) == false
   *
   * Can invalidate outstanding iterators. @a n becomes invalid, as do any
   * other Node objects equal to @a n. All other Node objects remain valid.
   *
   * Complexity: O(Number of edges of n).
   */
  void remove_node(const Node& n) {
    if (edge_matrix_.count(n.uid_) > 0) {
      // remove all edges connected to node
      std::vector<size_type> adj_nodes;
      auto it = edge_matrix_[n.uid_].begin();
      // remember adjacent nodes: remove_edge modifies edges_matrix_
      for (; it != edge_matrix_[n.uid_].end(); adj_nodes.push_back(*it), ++it);
      for (auto it = adj_nodes.begin(); it != adj_nodes.end(); ++it)
        remove_edge(Edge(this, n.uid_, *it));
    }
    // remove node data by overwriting nodes_ entry with nodes_'s last entry
    size_type idx = node_map_[n.uid_];
    // remove morton code for this node
    code_to_node_set_[mc_.code(nodes_[idx].position)].erase(n.uid_);
    nodes_[idx] = nodes_[nodes_.size()-1];
    nodes_.pop_back();
    node_map_.erase(n.uid_);
    // update mapping for node that moved to index of deleted one
    node_map_[nodes_[idx].uid] = idx;
    // delete this Node's entries in edge_matrix_ and edges_
    edge_matrix_.erase(n.uid_); edges_.erase(n.uid_);

  }

  /** Remove all nodes and edges from this graph.
   * @post num_nodes() == 0 && num_edges() == 0
   *
   * Invalidates all outstanding Node and Edge objects.
   */
  void clear() {
    nodes_.clear(); node_map_.clear();
    edges_.clear(); edge_matrix_.clear();
    num_edges_ = 0;
  }


  // EDGES

  /** @class Graph::Edge
   * @brief Class representing the graph's edges.
   *
   * Edges are order-insensitive pairs of nodes. Two Edges with the same nodes
   * are considered equal if they connect the same nodes, in either order.
   */
  class Edge : private totally_ordered<Edge> {
   public:
    /** Construct an invalid Edge. */
    Edge() : graph_(nullptr), a_uid_(0), b_uid_(0) {}

    /** Return a node of this Edge */
    Node node1() const { return Node(graph_, a_uid_); }

    /** Return the other node of this Edge */
    Node node2() const {
      assert(graph_);
      return Node(graph_, b_uid_);
    }

    edge_value_type& value() {
      size_type this_a = a_uid_, this_b = b_uid_;
      set_min_max(this_a, this_b);
      return graph_->edges_[this_a][this_b].value;
    }
    const edge_value_type& value() const {
      size_type this_a = a_uid_, this_b = b_uid_;
      set_min_max(this_a, this_b);
      auto got = edges_.find(this_a);
      if (got != edges_.end() && got->second.count(this_b) > 0)
        return got.find(this_b)->second.value;
      else return edge_value_type();
    }
    /** Two edges are equal if their graphs are equal and
     *  the minimum and maximum nodes of the edges are equal
     * */
    bool operator==(const Edge& that) const {
      size_type this_a = a_uid_, this_b = b_uid_;
      set_min_max(this_a, this_b);
      size_type that_a = that.a_uid_, that_b = that.b_uid_;
      set_min_max(that_a, that_b);
      return graph_ == that.graph_ && this_a == that_a && this_b == that_b;
    }
    /** This Edge is less than that Edge if
     *  this's min node < that's min node OR
     *  this's min node == that's min node and this's max node < that's max node
     * */
    bool operator<(const Edge& that) const {
      size_type this_a = a_uid_, this_b = b_uid_;
      set_min_max(this_a, this_b);
      size_type that_a = that.a_uid_, that_b = that.b_uid_;
      set_min_max(that_a, that_b);
      return this_a < that_a || (this_a == that_a && this_b < that_b);
    }

   private:
    // Only Graph can access our private members
    friend class Graph;
    // Use this space declare private data members for Edge objects
    // Graph needs a way to construct valid Edge objects

    Graph* graph_;  // Pointer to Edge's Graph
    size_type a_uid_;  // uid of Edge's Node
    size_type b_uid_;  // uid of Edge's Node

    /** Private Constructor */
    Edge(const Graph* graph, size_type a_uid, size_type b_uid)
        : graph_(const_cast<Graph*>(graph)), a_uid_(a_uid), b_uid_(b_uid) {}
  };

  /** Return the total number of edges in the graph.
   *
   * Complexity: O(1).
   */
  size_type num_edges() const { return num_edges_; }

  /** Return the edge with "index" @a i.
   * @pre 0 <= @a i < num_edges()
   * @return the Edge resulting from incrementing the iterator i times
   *
   * Complexity: O(num_nodes() + num_edges()).
   */
  Edge edge(size_type i) const {
    edge_iterator it = edge_begin();
    for (int k = 0; k < i; ++it, ++k);
    return *it;
  }

  /** Test whether two nodes are connected by an edge.
   * @pre @a a and @a b are valid nodes of this graph
   * @return true if, for some @a i, edge(@a i) connects @a a and @a b.
   *
   * Complexity: amortized O(1).
   */
  bool has_edge(const Node& a, const Node& b) const {
    auto got = edge_matrix_.find(a.uid_);
    return got != edge_matrix_.end() && got->second.count(b.uid_) > 0;
  }

  /** Add an edge to the graph, or return the current edge if it already exists.
   * @pre @a a and @a b are distinct valid nodes of this graph
   * @return an Edge object e with e.node1() == @a a and e.node2() == @a b
   * @post has_edge(@a a, @a b) == true
   * @post If old has_edge(@a a, @a b), new num_edges() == old num_edges().
   *       Else,                        new num_edges() == old num_edges() + 1.
   *
   * Can invalidate edge indexes -- in other words, old edge(@a i) might not
   * equal new edge(@a i). Must not invalidate outstanding Edge objects.
   *
   * Complexity: amortized O(1).
   */
  Edge add_edge(const Node& a, const Node& b) {
    assert(a != b);
    size_type a_uid = a.uid_, b_uid = b.uid_; set_min_max(a_uid, b_uid);
    auto got = edge_matrix_.find(a.uid_);
    if (got == edge_matrix_.end() || got->second.count(b.uid_) == 0) {
      // Edge a-b does not exist
      edges_[a_uid][b_uid] = { a_uid, b_uid, edge_value_type() };
      // create edge in both directions in adjacency matrix
      edge_matrix_[a.uid_].insert(b.uid_); edge_matrix_[b.uid_].insert(a.uid_);
      ++num_edges_;
    }
    return Edge(this, a_uid, b_uid);
  }

  /** Remove an edge, if any, returning the number of edges removed.
   * @param[in] a,b The nodes potentially defining an edge to be removed.
   * @return 1 if old has_edge(@a a, @a b), 0 otherwise
   * @pre @a a and @a b are valid nodes of this graph
   * @post !has_edge(@a a, @a b)
   * @post new num_edges() == old num_edges() - result
   *
   * Can invalidate edge indexes -- in other words, old edge(@a i) might not
   * equal new edge(@a i). Can invalidate all edge and incident iterators.
   * Invalidates any edges equal to Edge(@a a, @a b). Must not invalidate
   * other outstanding Edge objects.
   *
   * Complexity: amortized O(1).
   */
  size_type remove_edge(const Node& a, const Node& b) {
    if (!has_edge(a, b)) return 0;
    return remove_edge(Edge(this, a.uid_, b.uid_));
  }

  /** Remove an edge, if any, returning the number of edges removed.
   * @param[in] e The edge to remove
   * @pre @a e is a valid edge of this graph
   * @pre has_edge(@a e.node1(), @a e.node2())
   * @post !has_edge(@a e.node1(), @a e.node2())
   * @post new num_edges() == old num_edges() - 1
   *
   * This is a synonym for remove_edge(@a e.node1(), @a e.node2()), but its
   * implementation can assume that @a e is definitely an edge of the graph.
   * This might allow a faster implementation.
   *
   * Can invalidate edge indexes -- in other words, old edge(@a i) might not
   * equal new edge(@a i). Can invalidate all edge and incident iterators.
   * Invalidates any edges equal to Edge(@a a, @a b). Must not invalidate
   * other outstanding Edge objects.
   *
   * Complexity: amortized O(1).
   */
  size_type remove_edge(const Edge& e) {
    // remove Edge from adjacency matrix
    edge_matrix_[e.a_uid_].erase(e.b_uid_);
    edge_matrix_[e.b_uid_].erase(e.a_uid_);
    // remove Edge data
    size_type min = e.a_uid_, max = e.b_uid_; set_min_max(min, max);
    edges_[min].erase(max);
    --num_edges_;
    return 1;
  }

  // ITERATORS

  /** @class Graph::node_iterator
   * @brief Iterator class for nodes. A forward iterator. */
  class node_iterator {
   public:
    // These type definitions help us use STL's iterator_traits.
    /** Element type. */
    typedef Node value_type;
    /** Type of pointers to elements. */
    typedef Node* pointer;
    /** Type of references to elements. */
    typedef Node& reference;
    /** Iterator category. */
    typedef std::input_iterator_tag iterator_category;
    /** Difference between iterators */
    typedef std::ptrdiff_t difference_type;

    /** Construct an invalid node_iterator. */
    node_iterator() : graph_(nullptr), it_(nullptr) {}

    /** Return the current Node of the iterator */
    Node operator*() const {
      return Node(graph_, (*it_).uid);
    }
    /** Advance the iterator */
    node_iterator& operator++() {
      ++it_;
      return *this;
    }
    /** Two node_iterators are equal if their Graphs are equal
     *  and nodes_type iterators are at the same location.
     * */
    bool operator==(const node_iterator& that) const {
      return graph_ == that.graph_ && it_ == that.it_;
    }
    bool operator!=(const node_iterator& that) const {
      return !(*this == that);
    }

   private:
    friend class Graph;
    friend class edge_iterator;
    node_iterator(const Graph* graph, typename nodes_type::const_iterator it)
                 : graph_(const_cast<Graph*>(graph)), it_(it) {}
    Graph* graph_;  // pointer to this node_iterator's Graph
    typename nodes_type::const_iterator it_;
  };

  /** Returns a beginning node_iterator */
  node_iterator node_begin() const {
    return node_iterator(this, nodes_.begin());
  }
  /** Returns an ending node_iterator */
  node_iterator node_end() const { return node_iterator(this, nodes_.end()); }

  class neighborhood_iterator {
   public:
    // These type definitions help us use STL's iterator_traits.
    /** Element type. */
    typedef Node value_type;
    /** Type of pointers to elements. */
    typedef Node* pointer;
    /** Type of references to elements. */
    typedef Node& reference;
    /** Iterator category. */
    typedef std::input_iterator_tag iterator_category;
    /** Difference between iterators */
    typedef std::ptrdiff_t difference_type;
    /** Construct an invalid neighborhood_iterator. */
    neighborhood_iterator() : graph_(nullptr), code_(0), code_end_(0),
                              ns_it_(nullptr) {}

    /** Return the current Node of the iterator */
    Node operator*() const {
      return Node(graph_, *ns_it_);
    }
    /** Advance the iterator to next valid element */
    neighborhood_iterator& operator++() {
      ++ns_it_;
      fix();
      return *this;
    }
    void fix() {
      // while current code has no uids or this node iterator is at the end
      while (graph_->code_to_node_set_.count(code_) == 0
         || ns_it_ == (graph_->code_to_node_set_.find(code_))->second.end()) {
        ++code_; // code has no more node uids, so move to next code
        if (code_ == code_end_) break; // no more codes, so return
        if (graph_->code_to_node_set_.count(code_) > 0)
          ns_it_ = (graph_->code_to_node_set_.find(code_))->second.begin();
      }
    }
    /** Two node_iterators are equal if their Graphs are equal
     *  and nodes_type iterators are at the same location.
     * */
    bool operator==(const neighborhood_iterator& that) const {
      return graph_ == that.graph_ && code_ == that.code_
          && (ns_it_ == that.ns_it_ || code_ == code_end_);
    }
    bool operator!=(const neighborhood_iterator& that) const {
      return !(*this == that);
    }
   private:
    friend class Graph;
    neighborhood_iterator(const Graph* graph,
                          MortonCoder<>::code_type code,
                          MortonCoder<>::code_type code_end,
                          node_set_type::const_iterator ns_it)
                        : graph_(const_cast<Graph*>(graph)),
                          code_(code), code_end_(code_end), ns_it_(ns_it) {}
    Graph* graph_;
    MortonCoder<>::code_type code_;
    MortonCoder<>::code_type code_end_;
    node_set_type::const_iterator ns_it_;
  };

  neighborhood_iterator node_begin (const BoundingBox& bb) const {
    // grab code of minimum
    MortonCoder<>::code_type min_code = mc_.code(bb.min());
    MortonCoder<>::code_type code_end = mc_.code(bb.max())+1;
    node_set_type::const_iterator ns_it;
    if (code_to_node_set_.count(min_code) > 0)
      ns_it = (code_to_node_set_.find(min_code))->second.begin();
    auto it = neighborhood_iterator(this, min_code, code_end, ns_it);
    it.fix();
    return it;
  }
  // returns iterator to next valid element after last element
  neighborhood_iterator node_end (const BoundingBox& bb) const {
    MortonCoder<>::code_type code_end = mc_.code(bb.max())+1;
    node_set_type::const_iterator ns_it;
    return neighborhood_iterator(this, code_end, code_end, ns_it);
  }

  /** @class Graph::edge_iterator
   * @brief Iterator class for edges. A forward iterator. */
  class edge_iterator {
   public:
    // These type definitions help us use STL's iterator_traits.
    /** Element type. */
    typedef Edge value_type;
    /** Type of pointers to elements. */
    typedef Edge* pointer;
    /** Type of references to elements. */
    typedef Edge& reference;
    /** Iterator category. */
    typedef std::input_iterator_tag iterator_category;
    /** Difference between iterators */
    typedef std::ptrdiff_t difference_type;

    /** Construct an invalid edge_iterator. */
    edge_iterator() : graph_(nullptr), a_it_(nullptr), b_it_(nullptr) {}

    /** Returns Edge at current position of iterator */
    Edge operator*() const { return Edge(graph_, a_it_->first, b_it_->first); }
    /** Advance iterator to next valid Edge.
     *  If there are no more valid Edge objects, iterator is at end.
     * */
    edge_iterator& operator++() {
      ++b_it_;
      while (b_it_ == a_it_->second.end()) {
        ++a_it_;  // a has no more edges, so move to next a
        if (a_it_ == graph_->edges_.end()) break; // no more a's, so return
        b_it_ = a_it_->second.begin();
      }
      return *this;
    }
    /** Two edge_iterators are equal if their Graphs are equal
     *  and their a iterators are equal
     *  and their b iterators are equal OR the a iterator is at the end.
     * */
    bool operator==(const edge_iterator& iter) const {
      // on reaching the end of a's, b's (a's edges) become irrelevant
      return graph_ == iter.graph_ && a_it_ == iter.a_it_
             && (b_it_ == iter.b_it_ || a_it_ == graph_->edges_.end());
    }
    bool operator!=(const edge_iterator& iter) const {
      return !(*this == iter);
    }

   private:
    friend class Graph;
    edge_iterator(const Graph* graph, typename edges_type::const_iterator a_it,
                  typename edges_map_type::const_iterator b_it)
                : graph_(const_cast<Graph*>(graph)), a_it_(a_it), b_it_(b_it) {}
    Graph* graph_;  // pointer to this edge_iterator's Graph
    typename edges_type::const_iterator a_it_;  // iterates Node a of edge
    typename edges_map_type::const_iterator b_it_;  // iterates Node b of edge
  };

  /** Return beginning edge_iterator */
  edge_iterator edge_begin() const {
    auto a_it = edges_.begin();
    typename edges_map_type::const_iterator b_it;
    while (a_it != edges_.end()) {
      b_it = a_it->second.begin();
      if (b_it != a_it->second.end()) break;
      ++a_it;  // this a doesn't have any edges, so skip to next a
    }
    return edge_iterator(this, a_it, b_it);
  }
  /** Return ending edge_iterator */
  edge_iterator edge_end() const {
    return edge_iterator(this, edges_.end(),
                         typename edges_map_type::const_iterator());
  }


  /** @class Graph::incident_iterator
   * @brief Iterator class for edges incident to a given node. A forward
   * iterator. */
  class incident_iterator {
   public:
    // These type definitions help us use STL's iterator_traits.
    /** Element type. */
    typedef Edge value_type;
    /** Type of pointers to elements. */
    typedef Edge* pointer;
    /** Type of references to elements. */
    typedef Edge& reference;
    /** Iterator category. */
    typedef std::input_iterator_tag iterator_category;
    /** Difference between iterators */
    typedef std::ptrdiff_t difference_type;

    /** Construct an invalid incident_iterator. */
    incident_iterator() : node_(nullptr), a_it_(nullptr), b_it_(nullptr) {}

    /** Return the Edge pointed to by the iterator */
    Edge operator*() const {
      return Edge(this->node_->graph_, this->node_->uid_, *b_it_);
    }
    /** Advance the iterator to the next valid Edge.
     *  If there are no more valid Edges, it's set to the end iterator.
     * */
    incident_iterator& operator++() {
      ++b_it_;
      if (b_it_ == a_it_->second.end())
        a_it_ = node_->graph_->edge_matrix_.end();
      return *this;
    }
    /** Two incident_iterators are equal if their Nodes are equal
     *  and their a iterators are equal
     *  and their b iterators are equal OR the a iterator is at the end.
     * */
    bool operator==(const incident_iterator& that) const {
      return node_ == that.node_ && a_it_ == that.a_it_
             && (a_it_ == node_->graph_->edge_matrix_.end()
                || b_it_ == that.b_it_);
    }
    bool operator!=(const incident_iterator& that) const {
      return !(*this == that);
    }

   private:
    friend class Graph;
    incident_iterator(const Node* node, edge_matrix_type::const_iterator em_it,
                      edge_set_type::const_iterator es_it)
                    : node_(node), a_it_(em_it), b_it_(es_it) {}
    const Node* node_;  // pointer to this iterator's Node
    edge_matrix_type::const_iterator a_it_;  // outer matrix ("a") iterator
    edge_set_type::const_iterator b_it_;  // node's adjacency set ("b") iterator
  };

 private:
  size_type cur_node_uid_ = 0; // uid counter for uniqueness
  // NOTE: depends on having less than MAX(size_type) nodes
  nodes_type nodes_;  // stores actual node data
  node_map_type node_map_;  // map of node uids to indices into nodes_

  size_type num_edges_ = 0;
  // for each Edge, both directions exist
  edge_matrix_type edge_matrix_;  // stores each Node's adjacent Edge set
  // for each Edge, only min Node -> max Node direction exists
  edges_type edges_;  // map of actual Edge data (no duplicates)

  BoundingBox bb_ = BoundingBox(Point(-5,-5,-5), Point(5,5,5));
  MortonCoder<5> mc_ = MortonCoder<5>(bb_);
  code_to_node_set_type code_to_node_set_;
};

#endif
