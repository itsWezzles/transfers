#pragma once
#include <GL/glu.h>

float EPSILON = 0.000001;

std::pair<Point,Point> unProject(int x, int y, int winH) {
  //int winH = viewer_->window_height();

  GLdouble modelMatrix[16];
  glGetDoublev(GL_MODELVIEW_MATRIX, modelMatrix);
  GLdouble projMatrix[16];
  glGetDoublev(GL_PROJECTION_MATRIX, projMatrix);
  int viewport[4];
  glGetIntegerv(GL_VIEWPORT, viewport);

  Point backPoint, frontPoint;
  gluUnProject(x, winH - y, 1.0, modelMatrix, projMatrix, viewport,
               &backPoint.x, &backPoint.y, &backPoint.z);
  gluUnProject(x, winH - y, 0.0, modelMatrix, projMatrix, viewport,
               &frontPoint.x, &frontPoint.y, &frontPoint.z);

  return {frontPoint, backPoint};
}

bool tri_intersection(Point v1, Point v2, Point v3, Point x1, Point x2) {
	Point s = x2-x1;
	Point e1 = v2-v1;
	Point e2 = v3-v1;
	Point p = cross(s,e2);
	double det = dot(e1, p);

	if (det > -EPSILON && det < EPSILON)
	  return false;

	double inv_det = 1.0 / det;
	Point c = x1 - v1;
	double u = dot(c,p) * inv_det;

	if (u < 0.0 || u > 1.0)
	  return false;

	Point q = cross(c,e1);
	double vv = dot(s,q)*inv_det;

	if (vv < 0.0 || u + vv > 1.0)
	  return false;

	double tt = dot(e2,q) * inv_det;

  return tt > EPSILON;
}

struct RedColor {
  template <typename NODE>
  CS207::Color operator()(const NODE&) {
    return CS207::Color(1,0,0);
  }
};
struct GreenColor {
  template <typename NODE>
  CS207::Color operator()(const NODE&) {
    return CS207::Color(0,1,0);
  }
};
struct DefaultColor {
  template <typename NODE>
  CS207::Color operator()(const NODE&){
    return CS207::Color(1,1,1);
  }
};

// A default position functor that returns node.position() for any node
struct DefaultPosition {
  template <typename NODE>
  Point operator()(const NODE& node) {
    return node.position();
  }
};

template <typename M, typename H>
struct tri_colorer: public CS207::SDLViewer::SDL_Listener {
  typedef typename M::tri_value_type tri_value_type;
  typedef typename M::triangle_iterator triangle_iterator;
  typedef typename M::node_type Node;
  typedef typename M::triangle_type Triangle;
  triangle_iterator begin_; triangle_iterator end_;
  triangle_iterator current_; triangle_iterator temp;
  std::map<Node, unsigned>* node_map_;
  CS207::SDLViewer* viewer_;
  M* mesh_;
  H& keyhandler_;

  /** Node position function object for use in the SDLViewer. */
  struct NodePosition {
    template <typename NODE>
    Point operator()(const NODE& n) {
      // positions of the nodes
      Point temp;
      temp.x = n.position().x; temp.y = n.position().y;
      temp.z = n.position().z;
      return temp;
    }
  };

  tri_colorer() {}

  tri_colorer(triangle_iterator begin, triangle_iterator end, triangle_iterator current,
              std::map<Node, unsigned>* node_map, CS207::SDLViewer* viewer,
              M* mesh, H& keyhandler)
            : begin_(begin), end_(end), current_(current), temp(--end),
              node_map_(node_map), viewer_(viewer), mesh_(mesh), keyhandler_(keyhandler) {}


  void handle(SDL_Event event, CS207::GLCamera* camera_) {

    Uint8* keystate = SDL_GetKeyState(NULL);

    //continuous-response keys
    if (keystate[SDLK_RIGHT] && current_!= temp) {
      viewer_->add_node((*current_).node(0), DefaultColor(), NodePosition(),
                        *node_map_);
      viewer_->add_node((*current_).node(1), DefaultColor(), NodePosition(),
                        *node_map_);
      viewer_->add_node((*current_).node(2), DefaultColor(), NodePosition(),
                        *node_map_);
      ++current_;
      viewer_->add_node((*current_).node(0), RedColor(), NodePosition(),
                        *node_map_);
      viewer_->add_node((*current_).node(1), RedColor(), NodePosition(),
                        *node_map_);
      viewer_->add_node((*current_).node(2), RedColor(), NodePosition(),
                        *node_map_);
    }

    if (keystate[SDLK_LEFT] && current_!= begin_) {
      viewer_->add_node((*current_).node(0), DefaultColor(), NodePosition(),
                        *node_map_);
      viewer_->add_node((*current_).node(1), DefaultColor(), NodePosition(),
                        *node_map_);
      viewer_->add_node((*current_).node(2), DefaultColor(), NodePosition(),
                        *node_map_);
      --current_;
      viewer_->add_node((*current_).node(0), RedColor(), NodePosition(),
                        *node_map_);
      viewer_->add_node((*current_).node(1), RedColor(), NodePosition(),
                        *node_map_);
      viewer_->add_node((*current_).node(2), RedColor(), NodePosition(),
                        *node_map_);
    }

    switch (event.type) {
      case SDL_MOUSEBUTTONDOWN: {
        if(event.button.state == SDL_BUTTON(1)) {
          int winH = viewer_->window_height();
          std::pair<Point,Point> line = unProject(event.button.x,
                                                  event.button.y, winH);

          viewer_->add_node((*current_).node(0), DefaultColor(),
                            NodePosition(), *node_map_);
          viewer_->add_node((*current_).node(1), DefaultColor(),
                            NodePosition(), *node_map_);
          viewer_->add_node((*current_).node(2), DefaultColor(),
                            NodePosition(), *node_map_);
          Point x1 = line.first; Point x2 = line.second;
          for (auto it = mesh_->triangle_begin(); it != mesh_->triangle_end(); ++it) {
            Triangle tri = *it;
            Point v1 = Point(tri.node(0).position().x,
                             tri.node(0).position().y, tri.node(0).position().z);
            Point v2 = Point(tri.node(1).position().x,
                             tri.node(1).position().y, tri.node(1).position().z);
            Point v3 = Point(tri.node(2).position().x,
                             tri.node(2).position().y, tri.node(2).position().z);

            if (tri_intersection(v1, v2, v3, x1, x2)) {
              current_ = it;
              viewer_->add_node((*current_).node(0), GreenColor(),
                                NodePosition(), *node_map_);
              viewer_->add_node((*current_).node(1), GreenColor(),
                                NodePosition(), *node_map_);
              viewer_->add_node((*current_).node(2), GreenColor(),
                                NodePosition(), *node_map_);
            }
          }
        }
      } break;
      case SDL_KEYDOWN: { // Keyboard 'i' to zoom
        if (event.key.keysym.sym == SDLK_o) { camera_->zoom(1.25); }
        if (event.key.keysym.sym == SDLK_i) { camera_->zoom(0.8); }
        if (event.key.keysym.sym == SDLK_e && current_ != temp) {
          viewer_->add_node((*current_).node(0), DefaultColor(),
                            NodePosition(), *node_map_);
          viewer_->add_node((*current_).node(1), DefaultColor(),
                            NodePosition(), *node_map_);
          viewer_->add_node((*current_).node(2), DefaultColor(),
                            NodePosition(), *node_map_);
          ++current_;
          viewer_->add_node((*current_).node(0), RedColor(), NodePosition(),
                            *node_map_);
          viewer_->add_node((*current_).node(1), RedColor(), NodePosition(),
                            *node_map_);
          viewer_->add_node((*current_).node(2), RedColor(), NodePosition(),
                            *node_map_);
        }
        if (event.key.keysym.sym == SDLK_w && current_ != begin_) {
          viewer_->add_node((*current_).node(0), DefaultColor(),
                            NodePosition(), *node_map_);
          viewer_->add_node((*current_).node(1), DefaultColor(),
                            NodePosition(), *node_map_);
          viewer_->add_node((*current_).node(2), DefaultColor(),
                            NodePosition(), *node_map_);
          --current_;
          viewer_->add_node((*current_).node(0), RedColor(), NodePosition(),
                            *node_map_);
          viewer_->add_node((*current_).node(1), RedColor(), NodePosition(),
                            *node_map_);
          viewer_->add_node((*current_).node(2), RedColor(), NodePosition(),
                            *node_map_);
        }
        keyhandler_(event.key.keysym.sym, *current_);
      } break;
      default: return;
    }
  }
};
