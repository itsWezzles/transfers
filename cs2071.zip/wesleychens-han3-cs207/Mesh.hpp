#pragma once
/**
 * @file Mesh.hpp
 */

#include "Graph.hpp"
#include "Point.hpp"
#include <algorithm>
#include <cassert>
#include <functional>
#include <vector>

/** @class Mesh
 * @brief A template for 3D triangular meshes.
 *
 * Users can add triangles and retrieve nodes, edges, and triangles.
 */
template <typename N, typename E, typename T>
class Mesh {
 public:
  /** Type of indexes and sizes. Return type of Mesh::num_nodes(). */
  typedef unsigned size_type;
  typedef N node_value_type;
  typedef E edge_value_type;
  typedef T tri_value_type;

  typedef typename Graph<N,E>::Node Node;
  typedef typename Graph<N,E>::Edge Edge;
  typedef Node node_type;
  typedef Edge edge_type;

  class Triangle;
  typedef Triangle triangle_type;

  /*
   *  Adds a node to the mesh with position `p` and value `value`.
   *  @post new num_nodes() == old num_nodes() + 1
   */
  Node add_node(const Point& position,
                const node_value_type& value = node_value_type()) {
    return g_.add_node(position, value);
  }

  /*
   *  Adds a triangle to the mesh containing `Node`s `n1`, `n2`, `n3`.
   *  @pre n1, n2, n3 belong to this mesh (e.g., were created via add_node)
   *  @post new num_triangles() == old num_triangles() + 1
   *  @post new num_nodes() == old num_nodes()
   *  @post new num_edges() == old num_edges() + 3
   *  @return Triangle that was just added
   */
  Triangle add_triangle(Node& n1, Node& n2, Node& n3) {

    // create nodes vector for triangle
    size_type uid = tris_.size();
    std::vector<size_type> nodes;
    nodes.push_back(n1.index()); nodes.push_back(n2.index());
    nodes.push_back(n3.index());

    // resize nodes -> triangles map as appropriate
    size_type min_size = std::max({n1.index(), n2.index(), n3.index()}) + 1;
    if (min_size > node_to_tris_.size()) node_to_tris_.resize(min_size);
    node_to_tris_[n1.index()].push_back(uid);
    node_to_tris_[n2.index()].push_back(uid);
    node_to_tris_[n3.index()].push_back(uid);

    // associate edges with this new triangle
    map_edge(n1.index(), n2.index(), uid);
    map_edge(n2.index(), n3.index(), uid);
    map_edge(n1.index(), n3.index(), uid);

    // add triangle's three edges to underlying graph
    g_.add_edge(n1, n2); g_.add_edge(n2, n3); g_.add_edge(n1, n3);

    // store internal triangle data
    struct internal_tri_data tri_data;
    tri_data.nodes = nodes;
    tris_.push_back(tri_data);

    // user gets a proxy object
    return Triangle(this, uid);
  }

  /*
   *  Returns (maximally two) Triangles associated with Edge `e`.
   *  @pre `e` is an edge of this mesh's underlying graph
   *  @return A vector of Triangles
   */
  std::vector<Triangle> triangles(Edge e) {
    size_type i1 = e.node1().index(); size_type i2 = e.node2().index();
    return i1 < i2 ? edge_to_tris_[i1][i2] : edge_to_tris_[i2][i1];
  }

  typename Graph<N, E>::node_iterator node_begin() const {
    return g_.node_begin();
  }

  typename Graph<N, E>::node_iterator node_end() const {
    return g_.node_end();
  }

  typename Graph<N, E>::edge_iterator edge_begin() const {
    return g_.edge_begin();
  }

  typename Graph<N, E>::edge_iterator edge_end() const {
    return g_.edge_end();
  }


  class triangle_iterator {
   public:
    typedef Triangle value_type;
    typedef Triangle* pointer;
    typedef Triangle& reference;
    typedef std::input_iterator_tag iterator_category;
    typedef std::ptrdiff_t difference_type;

    triangle_iterator() : mesh_(nullptr), idx_(0) {}

    Triangle operator*() const { return Triangle(mesh_, idx_); }

    triangle_iterator& operator++() { ++idx_; return *this; }

    triangle_iterator& operator--() { --idx_; return *this; }

    bool operator==(const triangle_iterator& that) const {
      return mesh_ == that.mesh_ && idx_ == that.idx_;
    }
    bool operator!=(const triangle_iterator& that) const {
      return !(*this == that);
    }

   private:
    friend class Mesh;
    triangle_iterator(const Mesh* mesh, size_type idx)
                     : mesh_(const_cast<Mesh*>(mesh)), idx_(idx) {}
    Mesh* mesh_; size_type idx_;
  };

  triangle_iterator triangle_begin() const {
    return triangle_iterator(this, 0);
  }
  triangle_iterator triangle_end() const {
    return triangle_iterator(this, tris_.size());
  }

  /** Return the number of nodes in the mesh. */
  size_type num_nodes() const { return g_.num_nodes(); }
  /** Return the number of edges in the mesh. */
  size_type num_edges() const { return g_.num_edges(); }
  /** Return the number of triangles in the mesh. */
  size_type num_triangles() const { return tris_.size(); }

  class Triangle {
   public:
    Triangle() : mesh_(nullptr), uid_(0) {}
    /* @return value of Triangle */
    tri_value_type& value() { return mesh_->tris_[uid_].value; }
    /*
     * @pre 0 <= i < 3
     * @return Triangle's ith Node */
    Node node(size_type i) {
      assert(i < 3); return mesh_->g_.node(mesh_->tris_[uid_].nodes[i]);
    }
    /* @pre 0 <= i < 3
     * @return Triangle's ith Edge, Edge between node(i), node((i+1)%3) */
    Edge edge(size_type i) {
      assert(i < 3);
      Node na = mesh_->g_.node(mesh_->tris_[uid_].nodes[i]);
      Node nb = mesh_->g_.node(mesh_->tris_[uid_].nodes[(i+1)%3]);
      assert(mesh_->g_.has_edge(na, nb));
      return mesh_->g_.add_edge(na, nb);
    }

    bool operator==(const Triangle& that) const {
      return mesh_ == that.mesh_ && uid_ == that.uid_;
    }

    bool operator!=(const Triangle& that) const {
      return mesh_ != that.mesh_ || uid_ != that.uid_;
    }

    double area() { // half cross product formula
      Point AB = this->node(1).position() - this->node(0).position();
      Point AC = this->node(2).position() - this->node(0).position();
      return norm(cross(AB, AC)) / 2.0;
    }

    /* @pre e is an Edge of Triangle
     * @return Point representing outward normal of this Edge for Triangle */
    Point normal(Edge e) {
      Point pos1 = e.node1().position();
      Point pos2 = e.node2().position();

      // get vector between nodes in edge, then rotate perpendicularly
      Point normal = pos1 - pos2;
      double temp = normal.y; normal.y = -normal.x; normal.x = temp;

      Point edge_center = pos1 + ((pos2 - pos1) / 2);

      Point triangle_center = this->node(0).position()/3
                            + this->node(1).position()/3
                            + this->node(2).position()/3;

      float distance1 = norm(edge_center + normal - triangle_center);
      float distance2 = norm(edge_center - normal - triangle_center);

      return distance1 > distance2 ? normal : -normal;
    }

   private:
    friend class Mesh;
    Mesh* mesh_; size_type uid_;
    Triangle(const Mesh* mesh, size_type uid)
            : mesh_(const_cast<Mesh*>(mesh)), uid_(uid) {}
  };

  class adj_triangle_iterator {
   public:
    // These type definitions help us use STL's iterator_traits.
    /** Element type. */
    typedef Triangle value_type;
    /** Type of pointers to elements. */
    typedef Triangle* pointer;
    /** Type of references to elements. */
    typedef Triangle& reference;
    /** Iterator category. */
    typedef std::input_iterator_tag iterator_category;
    /** Difference between iterators */
    typedef std::ptrdiff_t difference_type;

    /** Construct an invalid adj_triangle_iterator. */
    adj_triangle_iterator() : mesh_(nullptr), it_(nullptr) {}

    /** Return the current Triangle of the iterator */
    Triangle operator*() const {
      return Triangle(mesh_, *it_);
    }
    /** Advance the iterator */
    adj_triangle_iterator& operator++() {
      ++it_;
      return *this;
    }
    /** Two triangle iterators are equal if their meshes are equal
     *  and underlying vector iterators are at the same location.
     * */
    bool operator==(const adj_triangle_iterator& that) const {
      return mesh_ == that.mesh_ && it_ == that.it_;
    }
    bool operator!=(const adj_triangle_iterator& that) const {
      return !(*this == that);
    }

   private:
    friend class Mesh;
    adj_triangle_iterator(const Mesh* mesh,
                          std::vector<size_type>::const_iterator it)
                 : mesh_(const_cast<Mesh*>(mesh)), it_(it) {}
    Mesh* mesh_;  // pointer to this node_iterator's Graph
    typename std::vector<size_type>::const_iterator it_;
  };

  /** Return beginning adj_triangle_iterator.
   */
  adj_triangle_iterator adj_triangle_begin(Node &n) const {
    auto it = node_to_tris_[n.index()].begin();
    return adj_triangle_iterator(this, it);
  }
  /** Return ending adj_triangle_iterator.
   */
  adj_triangle_iterator adj_triangle_end(Node &n) const {
    auto it = node_to_tris_[n.index()].end();
    return adj_triangle_iterator(this, it);
  }



 private:

  struct internal_tri_data {
    std::vector<size_type> nodes; // invariant: size() == 3
    tri_value_type value;
  };

  std::vector<internal_tri_data> tris_;
  std::vector<std::vector<size_type>> node_to_tris_;
  std::vector<std::vector<std::vector<Triangle>>> edge_to_tris_;

  Graph<N,E> g_;

  /*
   *  Internal helper function for associating an edge (specified
   *  by two node indexes) with a Triangle (specified by its `tid`).
   *
   *  @pre i1 < num_nodes()
   *  @pre i2 < num_nodes()
   *  @pre tid < num_nodes()
   */
  void map_edge(size_type i1, size_type i2, size_type tid) {
    if (i2 < i1) { size_type temp = i1; i1 = i2; i2 = temp; }

    if (i1+1 > edge_to_tris_.size()) edge_to_tris_.resize(i1+1);
    if (i2+1 > edge_to_tris_[i1].size()) edge_to_tris_[i1].resize(i2+1);
    edge_to_tris_[i1][i2].push_back(Triangle(this, tid));
  }
};
