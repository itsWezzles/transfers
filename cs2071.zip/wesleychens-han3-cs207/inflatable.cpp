
/**
 * @file inflatable.cpp
 * Test script for treating the Graph as a MTL Matrix
 * and solving a Poisson equation.
 *
 * @brief Reads in two files specified on the command line.
 * First file: 3D Points (one per line) defined by three doubles.
 * Second file: Edges (one per line) defined by 2 indices into the point list
 *              of the first file.
 *
 * Launches an SDLViewer to visualize the solution.
 */

#include "CS207/SDLViewer.hpp"
#include "CS207/Util.hpp"
#include "CS207/Color.hpp"

#include "BoundingBox.hpp"
#include "Graph.hpp"
#include "Point.hpp"
#include "Listener.hpp"
#include "Mesh.hpp"
#include "CollisionDetector.hpp"
#include <cassert>
#include <cmath>
#include <fstream>
#include <iostream>

static double volume;

typedef struct node_info {
  Point velocity;
  double mass;
  double damping;
  double radius;
} node_info;

typedef struct edge_info {
  double spring_constant;
  double rest_len;
} edge_info;

typedef struct {
} tri_info;

// Gravity in meters/sec^2
static constexpr double grav = 9.81;

typedef Graph<node_info,edge_info> GraphType;
typedef GraphType::Node Node;
typedef GraphType::Edge Edge;

typedef Mesh<node_info,edge_info,tri_info> MeshType;

/*
 * @param[in] t A triangle
 * @return Outward normal vector for this triangle.  Note: length is not necessarily 1!
 * @author Bo Han
 * Complexity: O(1)
*/
template <typename TRI>
Point outnormal(TRI t) {
  Point AB = t.node(1).position() - t.node(0).position();
  Point BC = t.node(2).position() - t.node(1).position();
  return cross(AB, BC);
}

/*
 * @param[in] m A valid mesh
 * @post `volume` static variable reflects current mesh volume.
 * @author Bo Han
 * Complexity: O(|T|), where |T| is the number of triangles in the graph
*/
template <typename M>
void update_mesh_volume(M& m) {
  volume = 0;
  for (auto ti = m.triangle_begin(); ti != m.triangle_end(); ++ti) {
    volume += outnormal(*ti).z * ((*ti).node(0).position().z
                              + (*ti).node(1).position().z
                              + (*ti).node(2).position().z)/3.0;
  }
}

/** Change a graph's nodes according to a step of the symplectic Euler
 *    method with the given node force.
 * @param[in,out] g Graph
 * @param[in] t The current time (useful for time-dependent forces)
 * @param[in] dt The time step
 * @param[in] force Function object defining the force per node
 * @pre G::node_value_type supports node info struct
 * @return the next time step (usually @a t + @a dt)
 *
 * @a force is called as @a force(n, @a t), where n is a node of the graph
 * and @a t is the current time parameter. @a force must return a Point
 * representing the node's force at time @a t.
 */
template <typename M, typename F, typename C>
double symp_euler_step(M &m, double t, double dt, F force, C constraint) {
  update_mesh_volume(m);
  for (auto n_it = m.node_begin(); n_it != m.node_end(); ++n_it) {
    // set position based on current {position, velocity}
    const Point cur_v = (*n_it).value().velocity;
    (*n_it).set_position((*n_it).position() + cur_v*dt);
  }
  for (auto n_it = m.node_begin(); n_it != m.node_end(); ++n_it) {
    // set velocity based on current {velocity, force}
    const double mass = (*n_it).value().mass;
    (*n_it).value().velocity += (force(*n_it, dt)/mass)*dt;
    constraint(m, dt);
  }

  return t + dt;
}

class GravityForce {
  public:
    /*
     * @param[in] n Node to compute gravity force for.
     * @param[in] t Current simulation time.
     * @return Point representing gravity force
     * @author Kevin Schmid
     * Complexity: O(1)
     */
    Point operator()(Node n, double t) {
      (void) t; return n.value().mass * Point(0,0,-grav);
    }
};


class MassSpringForce {
  public:
    /*
     * @param[in] n Node to compute mass spring force for.
     * @param[in] t Current simulation time.
     * @return Point representing mass spring force, after considering all incident edges.
     * @author Kevin Schmid
     * Complexity: O(deg(n))
     */
    Point operator()(Node n, double t) {
      (void)t; Point res = Point(0,0,0);
      // iterate through edges of n, adding contribution by edge
      for (auto it = n.edge_begin(); it != n.edge_end(); ++it) {

        const Point diff = n.position()-(*it).node2().position();
        const double dist = norm(diff);
        const double K = (*it).value().spring_constant;
        const double L = (*it).value().rest_len;
        res += -K*(diff/dist)*(dist-L);

      }
      return res;
    }
};

class WindForce {
  private: MeshType& m_; double c_; Point w_;
  public:

    /*
     * @param[in] m A valid mesh.
     * @param[in] c Interaction factor.
     * @param[in] w air velocity.
     * @return A wind force object, which can be applied to nodes in mesh `m`.
     * @author Bo Han
     * Complexity: O(1)
     */
    WindForce(MeshType& m, double c, Point w) : m_(m), c_(c), w_(w) {}

    /*
     * @param[in] n Node to compute wind force for.
     * @param[in] t Current simulation time.
     * @return Point representing wind force, after considering all adjacent triangles to n.
     * @author Bo Han
     * Complexity: O(|T|), where |T| is the number of triangles in the mesh.
     */
    template <typename NODE>
    Point operator()(NODE n, double t) {
      (void)t;
      Point ni = Point(0,0,0); int num = 0;
      for (auto ti = m_.adj_triangle_begin(n); ti != m_.adj_triangle_end(n);
           ++ti) {
        ni += outnormal(*ti);
      }
      if (num == 0) return ni;
      ni /= (double)num;
      return c_ * dot(w_-n.value().velocity, ni) * ni;
    }
};

class BalloonForce {
  private:
    MeshType& m_; double c_;
  public:
    /*
     * @param[in] m A valid mesh.
     * @param[in] c Gas contant.
     * @return A balloon force object, which can be applied to nodes in mesh `m`.
     * @author Bo Han
     * Complexity: O(1)
     */
    BalloonForce(MeshType& m, double c) : m_(m), c_(c) {}
    template <typename NODE>
    /*
     * @param[in] n Node to compute balloon force for.
     * @param[in] t Current simulation time.
     * @return Point representing balloon force, after considering all adjacent triangles to n.
     * @author Bo Han
     * Complexity: O(|T|), where |T| is the number of triangles in the mesh.
     */
    Point operator()(NODE n, double t) {
      (void) t;
      Point f = Point(0, 0, 0); int num = 0;
      for (auto ti = m_.adj_triangle_begin(n); ti != m_.adj_triangle_end(n);
           ++ti, ++num) {
        f += c_/volume * outnormal(*ti);
      }
      assert(num != 0);
      return num ? f/(double)num : Point(0, 0, 0);
    }
};

template <typename F1, typename F2>
class Combo2Force {
  private: F1 f1_; F2 f2_;
  public:
    // @pre f1, f2 support Point operator()(Node n, double t)
    Combo2Force(F1 f1, F2 f2) : f1_(f1), f2_(f2) {}
    // @return Point that is the sum of the provided f1, f2 applied on the input
    Point operator()(Node n, double t) { return f1_(n, t) + f2_(n, t); }
};

// @pre f1, f2 support Point operator()(Node n, double t)
// @return a combination force supporting operator()
template <typename F1, typename F2>
Combo2Force<F1,F2> make_combined_force(F1 f1, F2 f2) {
  return Combo2Force<F1,F2>(f1, f2);
}

// @pre f1, f2, f3 support Point operator()(Node n, double t)
// @return a combination force supporting operator()
template <typename F1, typename F2, typename F3>
Combo2Force<F1,Combo2Force<F2,F3>> make_combined_force(F1 f1, F2 f2, F3 f3) {
  return Combo2Force<F1,Combo2Force<F2,F3>>(f1, make_combined_force(f2, f3));
}


class ZPlaneConstraint {
  private:
    const double z_;
  public:
    // @pre z is desired z-coordinate to be above
    // @pre p is (0,0,1)
    ZPlaneConstraint(double z) : z_(z) {};
    // @pre g is valid graph
    // @post any node below the plane is reset to be not below the plane
    void operator()(MeshType& m, double t) {
      (void)t; (void)m;
      for (auto m_it = m.node_begin(); m_it != m.node_end(); ++m_it) {
        const Point cur_pos = (*m_it).position();
        if (cur_pos.z < z_) {
          (*m_it).set_position(Point(cur_pos.x, cur_pos.y, z_));
          (*m_it).value().velocity.z = 0;
        }
      }
    }
};

/*
 * Functor for use in Abhi and James' SDL listener.
 * @param[in] key The key the user pressed.  SDL enum type.
 * @param[in] t  Relevant triangle.
 * @post Triangle t's value is adjusted based on documentation (depends on `key`)
 * @author Kevin Schmid and Bo Han
 * Complexity: O(1)
 */
class KeyHandler {
  public:
  template <typename TRI>
  void operator()(unsigned key, TRI t) {
    if (key == SDLK_g) {
      for (int i = 0; i < 3; ++i) {
        t.edge(i).value().spring_constant -= 1;
      }
    }
    if (key == SDLK_h) {
      for (int i = 0; i < 3; ++i) {
        t.edge(i).value().spring_constant += 1;
      }
    }
    if (key == SDLK_t) {
      for (int i = 0; i < 3; ++i) {
        t.node(i).value().velocity.z -= 20;
      }
    }
    if (key == SDLK_y) {
      for (int i = 0; i < 3; ++i) {
        t.node(i).value().velocity.z += 20;
      }
    }
    if (key == SDLK_p) {
      for (int i = 0; i < 3; ++i) {
        t.node(i).value().velocity += 10*outnormal(t);
      }
    }
  }
};

/*
 * Main sympletic euler step routine.
 * @author Kevin Schmid
 * Complexity: O(1)
 */
int main(int argc, char* argv[])
{

  if (argc != 3) {
    return -1;
  }


  // declare two meshes
  // Design decision: decided to leave duplicated code for each mesh, since there are
  // specific parts.  Alternatives considered: use vector of meshes.
  MeshType mesh;
  MeshType mesh2;
  std::vector<typename MeshType::node_type> mesh_node;
  std::vector<typename MeshType::node_type> mesh_node2;

  // Read all Points and add them to the Mesh
  std::ifstream nodes_file(argv[1]);
  Point p;
  while (CS207::getline_parsed(nodes_file, p)) {
    mesh_node.push_back(mesh.add_node(p));

    // vertically separate second mesh from first mesh by 2 units
    p.z += 2;
    mesh_node2.push_back(mesh2.add_node(p));
  }

  // Read all mesh triangles and add them to the Mesh
  std::ifstream tris_file(argv[2]);
  std::array<int,3> t;
  while (CS207::getline_parsed(tris_file, t)) {
    mesh.add_triangle(mesh_node[t[0]], mesh_node[t[1]], mesh_node[t[2]]);
    mesh2.add_triangle(mesh_node[t[0]], mesh_node[t[1]], mesh_node[t[2]]);
  }

  // initial condiitons
  // CREDIT: Daniel Newman for constants
  for (auto it = mesh_node.begin(); it != mesh_node.end(); it++) {
    (*it).value().mass = 0.1/mesh.num_nodes();
  }

  for (auto it = mesh.edge_begin(); it != mesh.edge_end(); ++it) {
    (*it).value().spring_constant = 30.0;
    (*it).value().rest_len = norm((*it).node1().position() - (*it).node2().position());
  }

  for (auto it = mesh_node2.begin(); it != mesh_node2.end(); it++) {
    (*it).value().mass = 0.1/mesh2.num_nodes();
  }

  for (auto it = mesh2.edge_begin(); it != mesh2.edge_end(); ++it) {
    (*it).value().spring_constant = 30.0;
    (*it).value().rest_len = norm((*it).node1().position() - (*it).node2().position());
  }

  // Print out the stats
  std::cout << mesh.num_nodes() << " "
            << mesh.num_edges() << " "
            << mesh.num_triangles() << std::endl;

  // Launch the SDLViewer
  CS207::SDLViewer viewer;
  viewer.launch();

  auto node_map = viewer.empty_node_map(mesh);
  viewer.add_nodes(mesh_node.begin(), mesh_node.end(), node_map);
  viewer.add_edges(mesh.edge_begin(), mesh.edge_end(), node_map);

  auto node_map2 = viewer.empty_node_map(mesh2);
  viewer.add_nodes(mesh_node2.begin(), mesh_node2.end(), node_map2);
  viewer.add_edges(mesh2.edge_begin(), mesh2.edge_end(), node_map2);
  viewer.center_view();


  auto tri_beg = mesh.triangle_begin();
  auto tri_end = mesh.triangle_begin();

  // can reuse key handler in both listeners
  // one listener per mesh
  KeyHandler kh;
  tri_colorer<MeshType,KeyHandler>* listener = new tri_colorer<MeshType,KeyHandler> (tri_beg, tri_end, tri_beg, &node_map, &viewer, &mesh, kh);
  viewer.add_listener(listener);

  auto tri_beg2 = mesh2.triangle_begin();
  auto tri_end2 = mesh2.triangle_begin();
  tri_colorer<MeshType,KeyHandler>* listener2 = new tri_colorer<MeshType,KeyHandler> (tri_beg2, tri_end2, tri_beg2, &node_map2, &viewer, &mesh2, kh);
  viewer.add_listener(listener2);

  double dt = .001;
  double t_start = 0;
  double t_end = 10;

  // initial conditions: credit to Daniel Newman
  GravityForce gravity;
  MassSpringForce msf;
  BalloonForce bf(mesh, 15);
  BalloonForce bf2(mesh2, 15);
  ZPlaneConstraint ground(-1.5);

  auto combo = make_combined_force(gravity, msf, bf);
  auto combo2 = make_combined_force(gravity, msf, bf2);

  CollisionDetector<MeshType> cd;
  cd.add_mesh(&mesh);
  cd.add_mesh(&mesh2);

  // Begin the time stepping
  unsigned int state = 0;
  for (double t = t_start; t < t_end; t += dt) {
    // Step forward in time with forward Euler
    symp_euler_step(mesh, t, dt, combo, ground);
    symp_euler_step(mesh2, t, dt, combo2, ground);

    // Update the viewer with new node positions
    viewer.add_nodes(mesh_node.begin(), mesh_node.end(), node_map);
    viewer.add_nodes(mesh_node2.begin(), mesh_node2.end(), node_map2);
    viewer.set_label(t);

    // These lines slow down the animation for small meshes.
    // Feel free to remove them or tweak the constants.
    if (mesh.num_nodes() < 100)
      CS207::sleep(0.05);

    auto m = cd.list_collisions();
    // if state changed, print status update
    if (state != m.size() || t == 0) {
      if (m.size() > 0) {
        std::cout << "Collision\n";
      } else {
        std::cout << "No collision\n";
      }
    }
    state = m.size();
  }
  return 0;
}
