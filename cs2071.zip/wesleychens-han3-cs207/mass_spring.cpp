/**
 * @file mass_spring.cpp
 * Implementation of mass-spring system using Graph
 *
 * @brief Reads in two files specified on the command line.
 * First file: 3D Points (one per line) defined by three doubles
 * Second file: Tetrahedra (one per line) defined by 4 indices into the point
 * list
 */

#include <fstream>
#include <limits>
#include <vector>

#include "CS207/SDLViewer.hpp"
#include "CS207/Util.hpp"
#include "CS207/Color.hpp"

#include "Graph.hpp"
#include "Point.hpp"

struct node_info {
  Point velocity;
  double mass;
  double damping;
  double radius;
};
struct edge_info {
  double spring_constant;
  double rest_len;
};

// Gravity in meters/sec^2
static constexpr double grav = 9.81;

typedef Graph<node_info,edge_info> GraphType;
typedef GraphType::Node Node;
typedef GraphType::Edge Edge;

/** Change a graph's nodes according to a step of the symplectic Euler
 *    method with the given node force.
 * @param[in,out] g Graph
 * @param[in] t The current time (useful for time-dependent forces)
 * @param[in] dt The time step
 * @param[in] force Function object defining the force per node
 * @pre G::node_value_type supports node info struct
 * @return the next time step (usually @a t + @a dt)
 *
 * @a force is called as @a force(n, @a t), where n is a node of the graph
 * and @a t is the current time parameter. @a force must return a Point
 * representing the node's force at time @a t.
 */
template <typename G, typename F, typename C>
double symp_euler_step(G& g, double t, double dt, F force, C constraint) {
  for (auto n_it = g.node_begin(); n_it != g.node_end(); ++n_it) {
    // set position based on current {position, velocity}
    const Point cur_v = (*n_it).value().velocity;
    (*n_it).set_position((*n_it).position() + cur_v*dt);
  }
  for (auto n_it = g.node_begin(); n_it != g.node_end(); ++n_it) {
    // set velocity based on current {velocity, force}
    const double mass = (*n_it).value().mass;
    (*n_it).value().velocity += (force(*n_it, t)/mass)*dt;
  }
  // check constraints
  constraint(g, t);
  return t + dt;
}

class ConstantConstraint {
  private: Node n_;
  public:
    // @pre n is valid node of graph
    ConstantConstraint(Node n) : n_(n) {};
    void operator()(GraphType& g, double t) {
      (void)t; (void)g; n_.value().velocity = Point(0.0,0.0,0.0);
    }
};
class ZPlaneConstraint {
  private: const double z_; const Point p_;
  public:
    // @pre z is desired z-coordinate to be above
    // @pre p is (0,0,1)
    ZPlaneConstraint(double z, Point p) : z_(z), p_(p) {};
    // @pre g is valid graph
    // @post any node below the plane is reset to be not below the plane
    void operator()(GraphType& g, double t) {
      (void)t;
      for (auto n_it = g.node_begin(); n_it != g.node_end(); ++n_it) {
        const Point cur_pos = (*n_it).position();
        if (dot(cur_pos, p_) < z_) {
          (*n_it).set_position(Point(cur_pos.x, cur_pos.y, z_));
        }
      }
    }
};
class SphereConstraint {
  private: const Point c_; const double r_;
           BoundingBox bb_;
  public:
    // @pre c is center of sphere not be intersected with
    // @pre r is radius of sphere
    SphereConstraint(Point c, double r) : c_(c), r_(r) {
      bb_ = BoundingBox(c, r);
    }
    // @pre g is valid graph
    // @post any node colliding with sphere will be reset to not collide
    void operator()(GraphType& g, double t) {
      (void)t;
      for (auto n_it = g.node_begin(bb_); n_it != g.node_end(bb_); ++n_it) {
        const Point cur_pos = (*n_it).position();
        const Point diff = cur_pos - c_;
        const double dist = norm(diff);
        if (dist < r_) {
          Point new_pos = (diff/dist)*r_ + c_;
          (*n_it).set_position(new_pos);
          const Point cur_v = (*n_it).value().velocity;
          const Point R = diff/dist;
          (*n_it).value().velocity = cur_v - dot(cur_v, R)*R;
        }
      }
    }
};
class SelfCollisionConstraint {
  public:
    // @pre g is valid graph
    // @post any node colliding with another node will be reset to not collide
    void operator()(GraphType& g, double t) {
      (void)t;
      // traverse nodes, storing minimum edge lengths for each node
      for (auto n_it = g.node_begin(); n_it != g.node_end(); ++n_it) {
        Node n = *n_it;
        n.value().radius = std::numeric_limits<double>::max();
        for (auto e_it = n.edge_begin(); e_it != n.edge_end(); ++e_it) {
          Node n2 = (*e_it).node2();
          double dist = norm(n.position()-n2.position());
          if (dist < n.value().radius)
            n.value().radius = dist;
        }
      }
      // traverse nodes, making sure it doesn't collide with the other nodes
      for (auto n_it = g.node_begin(); n_it != g.node_end(); ++n_it) {
        const Point n_pos = (*n_it).position();
        BoundingBox bb = BoundingBox(n_pos);
        // traverse all other nodes, make sure this node isn't colliding
        for (auto o_it = g.node_begin(bb); o_it != g.node_end(bb); ++o_it) {
          if (*o_it == *n_it) continue;
          const Point o_pos = (*o_it).position();
          const Point diff = n_pos - o_pos; const double dist = norm(diff);
          const double radius = (*o_it).value().radius;
          if (dist >= radius) continue;
          Point new_n_pos = (diff/dist)*radius + o_pos;
          (*n_it).set_position(new_n_pos);
          const Point cur_n_v = (*n_it).value().velocity;
          const Point R = diff/dist;
          (*n_it).value().velocity = cur_n_v - dot(cur_n_v, R)*R;
          break;
        }
      }
    }
};
template <typename C1, typename C2>
class Combo2Constraint {
  private: C1 c1_; C2 c2_;
  public:
    // @pre c1, c2 support void operator()(GraphType& g, double t)
    Combo2Constraint<C1,C2>(C1 c1, C2 c2) : c1_(c1), c2_(c2) {}
    // @pre g is valid graph
    // @post c1 and c2 are applied to the graph
    void operator()(GraphType& g, double t) {
        c1_(g, t); c2_(g, t);
    }
};
// @pre c1, c2 support void operator()(GraphType& g, double t)
// @return a combination constraint supporting operator()
template <typename C1, typename C2>
Combo2Constraint<C1,C2> make_combined_constraint(C1 c1, C2 c2) {
  return Combo2Constraint<C1,C2>(c1, c2);
}
// @pre c1, c2, c3 support void operator()(GraphType& g, double t)
// @return a combination constraint supporting operator()
template <typename C1, typename C2, typename C3>
Combo2Constraint<C1,Combo2Constraint<C2,C3>>
make_combined_constraint(C1 c1, C2 c2, C3 c3) {
  auto c23 = make_combined_constraint(c2, c3);
  return Combo2Constraint<C1,Combo2Constraint<C2,C3>>(c1, c23);
}
// @pre c1, c2, c3, c4 support void operator()(GraphType& g, double t)
// @return a combination constraint supporting operator()
template <typename C1, typename C2, typename C3, typename C4>
Combo2Constraint<C1,Combo2Constraint<C2,Combo2Constraint<C3,C4>>>
make_combined_constraint(C1 c1, C2 c2, C3 c3, C4 c4) {
  auto c234 = make_combined_constraint(c2, c3, c4);
  return Combo2Constraint<C1,Combo2Constraint<C2,Combo2Constraint<C3,C4>>>(c1,
      c234);
}

class DampingForce {
  public:
    // @pre n is a valid node
    // @return Point representing damping force
    Point operator()(Node n, double t) {
      (void)t; return -n.value().damping * n.value().velocity;
    }
};
class GravityForce {
  public:
    // @pre n is a valid node
    // @return Point representing gravity force
    Point operator()(Node n, double t) {
      (void) t; return n.value().mass * Point(0,0,-grav);
    }
};
class MassSpringForce {
  public:
    // @pre n is a valid node
    // @return Point representing mass-spring force
    Point operator()(Node n, double t) {
      (void)t; Point res = Point(0,0,0);
      // iterate through edges of n, adding contribution by edge
      for (auto it = n.edge_begin(); it != n.edge_end(); ++it) {
        const Point diff = n.position()-(*it).node2().position();
        const double dist = norm(diff);
        const double K = (*it).value().spring_constant;
        const double L = (*it).value().rest_len;
        res += -K*(diff/dist)*(dist-L);
      }
      return res;
    }
};
template <typename F1, typename F2>
class Combo2Force {
  private: F1 f1_; F2 f2_;
  public:
    // @pre f1, f2 support Point operator()(Node n, double t)
    Combo2Force(F1 f1, F2 f2) : f1_(f1), f2_(f2) {}
    // @return Point that is the sum of the provided f1, f2 applied on the input
    Point operator()(Node n, double t) { return f1_(n, t) + f2_(n, t); }
};

// @pre f1, f2 support Point operator()(Node n, double t)
// @return a combination force supporting operator()
template <typename F1, typename F2>
Combo2Force<F1,F2> make_combined_force(F1 f1, F2 f2) {
  return Combo2Force<F1,F2>(f1, f2);
}
// @pre f1, f2, f3 support Point operator()(Node n, double t)
// @return a combination force supporting operator()
template <typename F1, typename F2, typename F3>
Combo2Force<F1,Combo2Force<F2,F3>> make_combined_force(F1 f1, F2 f2, F3 f3) {
  return Combo2Force<F1,Combo2Force<F2,F3>>(f1, make_combined_force(f2, f3));
}

int main(int argc, char* argv[]) {
  // Check arguments
  if (argc < 2) {
    std::cerr << "Usage: " << argv[0] << " NODES_FILE TETS_FILE\n";
    exit(1);
  }

  GraphType graph;
  std::vector<typename GraphType::node_type> nodes;

  // Create a nodes_file from the first input argument
  std::ifstream nodes_file(argv[1]);
  // Interpret each line of the nodes_file as a 3D Point and add to the Graph
  Point p;
  while (CS207::getline_parsed(nodes_file, p))
    nodes.push_back(graph.add_node(p));

  // Create a tets_file from the second input argument
  std::ifstream tets_file(argv[2]);
  // Interpret each line of the tets_file as four ints which refer to nodes
  std::array<int,4> t;
  while (CS207::getline_parsed(tets_file, t)) {
    for (unsigned i = 1; i < t.size(); ++i) {
      graph.add_edge(nodes[t[0]], nodes[t[1]]);
      graph.add_edge(nodes[t[0]], nodes[t[2]]);
      // Diagonal edges: include as of HW2 #2
      graph.add_edge(nodes[t[0]], nodes[t[3]]);
      graph.add_edge(nodes[t[1]], nodes[t[2]]);
      graph.add_edge(nodes[t[1]], nodes[t[3]]);
      graph.add_edge(nodes[t[2]], nodes[t[3]]);
    }
  }

  // Set initial conditions for your nodes, if necessary.
  // set initial node velocities to 0
  for (auto n_it = graph.node_begin(); n_it != graph.node_end(); ++n_it)  {
    (*n_it).value().velocity = Point(0,0,0);
    (*n_it).value().mass = 1.0/graph.size();
    (*n_it).value().damping = 1.0/graph.size();
  }
  // set resting edge lengths
  for (auto e_it = graph.edge_begin(); e_it != graph.edge_end(); ++e_it) {
    (*e_it).value().spring_constant = 100.0;
    const Point diff = (*e_it).node1().position()-(*e_it).node2().position();
    (*e_it).value().rest_len = norm(diff);
  }


  // Print out the stats
  std::cout << graph.num_nodes() << " " << graph.num_edges() << std::endl;

  // Launch the SDLViewer
  CS207::SDLViewer viewer;
  auto node_map = viewer.empty_node_map(graph);
  viewer.launch();

  viewer.add_nodes(graph.node_begin(), graph.node_end(), node_map);
  viewer.add_edges(graph.edge_begin(), graph.edge_end(), node_map);

  viewer.center_view();

  // Begin the mass-spring simulation
  double dt = 0.0001;
  double t_start = 0;
  double t_end = 5.0;

  Node n1; Node n2;
  for (auto n_it = graph.node_begin(); n_it != graph.node_end(); ++n_it)  {
    if ((*n_it).position() == Point(0,0,0)) n1 = *n_it;
    else if ((*n_it).position() == Point(1,0,0)) n2 = *n_it;
  }
  auto cc1 = ConstantConstraint(n1);
  auto cc2 = ConstantConstraint(n2);
  auto cc = make_combined_constraint(cc1, cc2);
  auto czpc = ZPlaneConstraint(-0.75, Point(0,0,1));
  auto csc = SphereConstraint(Point(0.5,0.5,-0.5), 0.15);
  SelfCollisionConstraint cscc;
  auto constraint = make_combined_constraint(cc, czpc, csc, cscc);

  MassSpringForce f1; GravityForce f2; DampingForce f3;
  auto force = make_combined_force(f1, f2, f3);
  //auto force = make_combined_force(f1, f2, f3);
  for (double t = t_start; t < t_end; t += dt) {
    //std::cout << "t = " << t << std::endl;
    symp_euler_step(graph, t, dt, force, constraint);
    // Update viewer with nodes' new positions
    viewer.add_nodes(graph.node_begin(), graph.node_end(), node_map);
    viewer.set_label(t);

    // These lines slow down the animation for small graphs, like grid0_*.
    // Feel free to remove them or tweak the constants.
    if (graph.size() < 100)
      CS207::sleep(0.001);
  }

  return 0;
}
