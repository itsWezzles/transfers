/**
 * @file shallow_water.cpp
 * Implementation of a shallow water system using Mesh
 *
 * @brief Reads in two files specified on the command line.
 * First file: 3D point list (one per line) defined by three doubles
 * Second file: Triangles (one per line) defined by 3 indices into the point list
 */

#include "CS207/SDLViewer.hpp"
#include "CS207/Util.hpp"
#include "CS207/Color.hpp"
#include "Point.hpp"
#include <fstream>
#include <iostream>
#include <limits>
#include "boost/program_options.hpp"

#include "Mesh.hpp"

namespace po = boost::program_options;

#define H(x) (x < 0)

bool debug = false;
#define DBG if (debug)

// Standard gravity (average gravity at Earth's surface) in meters/sec^2
static constexpr double grav = 9.80665;

/** Water column characteristics */
struct QVar {
  double h;	  // Height of fluid
  double hu;	// Height times average x velocity of column
  double hv;	// Height times average y velocity of column

  /** Default constructor.
   *
   * A default water column is 1 unit high with no velocity. */
  QVar()
    : h(1), hu(0), hv(0) {
  }
  /** Construct the given water column. */
  QVar(double h_, double hu_, double hv_)
    : h(h_), hu(hu_), hv(hv_) {
  }
};

std::ostream& operator<<(std::ostream& os, const QVar& q) {
  os << "Q({" << q.h << "," << q.hu << "," << q.hv << ")}";
  return os;
}

QVar& operator*=(QVar &a, double b) {
  a.h *= b; a.hu *= b; a.hv *= b;
  return a;
}
QVar operator*(QVar a, double b) {
  return a *= b;
}
QVar operator*(double b, QVar a) {
  return a *= b;
}

QVar& operator/=(QVar &a, double b) {
  a.h /= b; a.hu /= b; a.hv /= b;
  return a;
}

QVar operator/(QVar a, double b) {
  return a /= b;
}
QVar operator/(double b, QVar a) {
  return a /= b;
}

QVar& operator-=(QVar &a, QVar b) {
  a.h -= b.h; a.hu -= b.hu; a.hv -= b.hv;
  return a;
}
QVar operator-(QVar a, QVar b) {
  return a -= b;
}

QVar& operator+=(QVar &a, QVar b) {
  a.h += b.h; a.hu += b.hu; a.hv += b.hv;
  return a;
}
QVar operator+(QVar a, QVar b) {
  return a += b;
}

/** Function object for calculating shallow-water flux.
 *          |e
 *   T_k    |---> n = (nx,ny)   T_m
 *   QBar_k |                   QBar_m
 *          |
 * @param[in] nx, ny Defines the 2D outward normal vector n = (@a nx, @a ny)
 *            from triangle T_k to triangle T_m. The length of n is equal to the
 *            the length of the edge, |n| = |e|.
 * @param[in] dt The time step taken by the simulation. Used to compute the
 *               Lax-Wendroff dissipation term.
 * @param[in] qk The values of the conserved variables on the left of the edge.
 * @param[in] qm The values of the conserved variables on the right of the edge.
 * @return The flux of the conserved values across the edge e
 */
struct EdgeFluxCalculator {
  QVar operator()(double nx, double ny, double dt,
                  const QVar& qk, const QVar& qm) {
    double e_length = sqrt(nx*nx + ny*ny);
    nx /= e_length;
    ny /= e_length;

    // The velocities normal to the edge
    double wm = (qm.hu*nx + qm.hv*ny) / qm.h;
    double wk = (qk.hu*nx + qk.hv*ny) / qk.h;

    // Lax-Wendroff local dissipation coefficient
    double vm = sqrt(grav*qm.h) + sqrt(qm.hu*qm.hu + qm.hv*qm.hv) / qm.h;
    double vk = sqrt(grav*qk.h) + sqrt(qk.hu*qk.hu + qk.hv*qk.hv) / qk.h;
    double a  = dt * std::max(vm*vm, vk*vk);

    // Helper values
    double scale = 0.5 * e_length;
    double gh2   = 0.5 * grav * (qm.h*qm.h + qk.h*qk.h);

    // Simple flux with dissipation for stability
    return QVar(scale * (wm*qm.h  + wk*qk.h)           - a * (qm.h  - qk.h),
                scale * (wm*qm.hu + wk*qk.hu + gh2*nx) - a * (qm.hu - qk.hu),
                scale * (wm*qm.hv + wk*qk.hv + gh2*ny) - a * (qm.hv - qk.hv));
  }
};

/** Node position function object for use in the SDLViewer. */
struct NodePosition {
  template <typename NODE>
  Point operator()(const NODE& n) {
    return Point(n.position().x, n.position().y, n.value().q.h);
  }
};

// Define NodeData, EdgeData, TriData, etc

typedef struct {
  QVar q;
} NodeData;

typedef struct {
  QVar oldq;
  QVar q;
} TriData;


typedef struct {
} empty;

typedef Mesh<NodeData,int,TriData> MeshType;

inline QVar boundary(MeshType::Triangle tri) {
  return QVar(tri.value().q.h, 0, 0);
}


/** Integrate a hyperbolic conservation law defined over the mesh m
 * with flux functor f by dt in time.
 */
template <typename MESH, typename FLUX>
double hyperbolic_step(MESH& m, FLUX& f, double t, double dt) {
  for (auto tb = m.triangle_begin(); tb != m.triangle_end(); ++tb) {
    MeshType::Triangle tri = *tb;
    tri.value().oldq = tri.value().q;
  }

  for (auto tb = m.triangle_begin(); tb != m.triangle_end(); ++tb) {
    auto triangle = *tb;
    double frac =  dt / triangle.area();

    for (int ei = 0; ei < 3; ++ei) {
      QVar Qm = boundary(triangle);

      MeshType::Edge e = triangle.edge(ei);
      auto tris = m.triangles(e);
      for (auto ti = tris.begin(); ti != tris.end(); ++ti) {
        if (*ti == triangle) continue;
        Qm = (*ti).value().oldq;
        break;
      }
      Point normal = triangle.normal(triangle.edge(ei));
      triangle.value().q -= frac * f(normal.x, normal.y, dt,
                                     triangle.value().oldq, Qm);
    }
  }
  return t + dt;
}

/** Convert the triangle-averaged values to node-averaged values for viewing. */
template <typename MESH>
void post_process(MESH& m) {
  // HW4B: Post-processing step
  // Translate the triangle-averaged values to node-averaged values
  // Implement Equation 8 from your pseudocode here
  for (auto ni = m.node_begin(); ni != m.node_end(); ++ni) {
    auto n = *ni;
    double ttlarea = 0.0;
    for (auto ti = m.adj_triangle_begin(n); ti != m.adj_triangle_end(n); ++ti) {
      ttlarea += (*ti).area();
    }
    n.value().q = QVar(0, 0, 0);
    for (auto ti = m.adj_triangle_begin(n); ti != m.adj_triangle_end(n); ++ti) {
      n.value().q += (*ti).area()/ttlarea * (*ti).value().q;
    }
  }
}

QVar pebble_depression(const Point& p) {
  double x = 1.0 - 0.75*exp(-80.0*(pow(p.x-.75, 2) + pow(p.y, 2)));
  return QVar(x, 0, 0);
}

QVar large_column(const Point& p) {
  double x = 1 + 0.75 * H(pow(p.x-.75, 2) + pow(p.y, 2) - .15*.15);
  return QVar(x, 0, 0);
}

QVar dam(const Point& p) {
  double x = 1 + .75*H(p.x);
  return QVar(x, 0, 0);
}

typedef enum {
  DAM,
  PEBBLE,
  COLUMN,
  INVALID
} init_type;

inline init_type get_init_type(std::string s) {
  if (s == "dam") {
    return DAM;
  } else if (s == "pebble") {
    return PEBBLE;
  } else if (s == "column") {
    return COLUMN;
  } else {
    return INVALID;
  }
}

int main(int argc, char* argv[])
{

  po::options_description desc("Allowed options");
  init_type mode;
  std::string nodes;
  std::string triangles;

  desc.add_options()
    ("v", "logging")
    ("init", po::value<std::string>(), "initialization condition to use")
    ("files", po::value<std::vector<std::string>>(), "data files");

    po::variables_map vm;
  try {

    po::positional_options_description pod;
    pod.add("files", -1);
    po::store(po::command_line_parser(argc, argv).options(desc).positional(pod).run(), vm);
    po::notify(vm);

    auto files = vm["files"].as<std::vector<std::string>>();

    if (files.size() != 2) {
      std::cout << desc;
      return 1;
    }

    debug = vm.count("v");
    mode = vm.count("init") ? get_init_type(vm["init"].as<std::string>()) : COLUMN;

    if (mode == INVALID) {
      std::cout << "Invalid mode.\n";
      return 1;
    }

    nodes = files[0];
    triangles = files[1];

  } catch (const std::exception &e) {
    std::cout << desc;
    return 1;
  }



  MeshType mesh;
  std::vector<typename MeshType::node_type> mesh_node;

  // Read all Points and add them to the Mesh
  std::ifstream nodes_file(nodes);
  Point p;
  while (CS207::getline_parsed(nodes_file, p)) {
    mesh_node.push_back(mesh.add_node(p));
  }

  // Read all mesh triangles and add them to the Mesh
  std::ifstream tris_file(triangles);
  std::array<int,3> t;
  while (CS207::getline_parsed(tris_file, t)) {
    mesh.add_triangle(mesh_node[t[0]], mesh_node[t[1]], mesh_node[t[2]]);
  }

  // Print out the stats
  std::cout << mesh.num_nodes() << " "
            << mesh.num_edges() << " "
            << mesh.num_triangles() << std::endl;

  // HW4B Initialization
  // Set the initial conditions
  for (auto ti = mesh.triangle_begin(); ti != mesh.triangle_end(); ++ti) {
    (*ti).value().q = QVar(0, 0, 0);
    for (unsigned i = 0; i < 3; ++i) {
      auto n = (*ti).node(i);
      switch (mode) {
        case PEBBLE:
          (*ti).value().q += pebble_depression(n.position())/3;
          break;
        case DAM:
          (*ti).value().q += dam(n.position())/3;
          break;
        case COLUMN:
          (*ti).value().q += large_column(n.position())/3;
          break;
        case INVALID:
          assert(0);
      }
    }
  }
  // Perform any needed precomputation
  double max_height = std::numeric_limits<double>::min();
  for (auto ti = mesh.triangle_begin(); ti != mesh.triangle_end(); ++ti) {
    if ((*ti).value().q.h > max_height) max_height = (*ti).value().q.h;
  }
  double min_edge_length = std::numeric_limits<double>::max();
  for (auto ei = mesh.edge_begin(); ei != mesh.edge_end(); ++ei) {
    double length = norm((*ei).node1().position() - (*ei).node2().position());
    if (length < min_edge_length) min_edge_length = length;
  }

  // Launch the SDLViewer
  CS207::SDLViewer viewer;
  viewer.launch();

  auto node_map = viewer.empty_node_map(mesh);
  viewer.add_nodes(mesh.node_begin(), mesh.node_end(),
                   CS207::DefaultColor(), NodePosition(), node_map);
  viewer.add_edges(mesh.edge_begin(), mesh.edge_end(), node_map);
  viewer.center_view();

  // HW4B: Timestep
  // CFL stability condition requires dt <= dx / max|velocity|
  // For the shallow water equations with u = v = 0 initial conditions
  //   we can compute the minimum edge length and maximum original water height
  //   to set the time-step
  // Compute the minimum edge length and maximum water height for computing dt
  double dt = .5 * min_edge_length / (sqrt(grav * max_height));
  double t_start = 0;
  double t_end = 10;

  DBG {
  std::cerr << "min_edge_length:" << min_edge_length << " "
            << "max_height:" << max_height << " "
            << "dt:" << dt << std::endl;
  }
  // Preconstruct a Flux functor
  EdgeFluxCalculator f;

  // Begin the time stepping
  for (double t = t_start; t < t_end; t += dt) {
    DBG {
    auto tri_it = mesh.triangle_begin();
    auto tri_it_end = mesh.triangle_end();
    int i = 0;
    while (tri_it != tri_it_end) {
      std::cerr << "Triangle " << i << "@ " << t << std::endl;
      MeshType::Triangle tri = *tri_it;
      std::cerr << "Area " << tri.area() << std::endl;
      std::cerr << "Node positions "
                << tri.node(0).position() << " "
                << tri.node(1).position() << " "
                << tri.node(2).position() << std::endl;
      std::cerr << tri.value().q << std::endl;

      for (int e = 0; e < 3; e++) {
        MeshType::Edge edge = tri.edge(e);
        std::cerr << "edge " << e << " "
                  << "normal vector " << tri.normal(edge) << std::endl;
      }
      ++i; ++tri_it;
    }
    }
    // Step forward in time with forward Euler
    hyperbolic_step(mesh, f, t, dt);

    // Update node values with triangle-averaged values
    post_process(mesh);

    // Update the viewer with new node positions
    // HW4B: Need to define node_iterators before these can be used!
    viewer.add_nodes(mesh.node_begin(), mesh.node_end(),
                     CS207::DefaultColor(), NodePosition(), node_map);
    viewer.set_label(t);

    // These lines slow down the animation for small meshes.
    // Feel free to remove them or tweak the constants.
    if (mesh.num_nodes() < 100)
      CS207::sleep(0.05);
  }

  return 0;
}
