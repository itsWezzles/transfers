/**
 * @file mtl_test.cpp
 * Test script for interfacing with MTL4 and it's linear solvers.
 */

#include <iostream>
#include <vector>
// HW3: Need to install/include Boost and MTL in Makefile
#include <boost/numeric/mtl/mtl.hpp>
#include <boost/numeric/itl/itl.hpp>

class IdentityMatrix {
  public:
  unsigned d;
  IdentityMatrix(unsigned dim) : d(dim) {}

  template <typename VectorIn, typename VectorOut, typename Assign>
  void mult(const VectorIn& v, VectorOut& w, Assign) const {
    std::cout << "v:" << v << std::endl;
    std::cout << "w:" << w << std::endl;
    for (unsigned i = 0; i < d; ++i) Assign::apply(w[i], v[i]);
  }
  template <typename VectorIn>
  mtl::vector::mat_cvec_multiplier<IdentityMatrix, VectorIn>
  operator*(const VectorIn& v) const {
    return mtl::vector::mat_cvec_multiplier<IdentityMatrix, VectorIn>(*this, v);
  }

};

inline std::size_t size(const IdentityMatrix& A) { return A.d*A.d; }
inline std::size_t num_rows(const IdentityMatrix& A) { return A.d; }
inline std::size_t num_cols(const IdentityMatrix& A) { return A.d; }

namespace mtl {
  namespace ashape {
    template<>
    struct ashape_aux<IdentityMatrix> {
      typedef nonscal type;
    };
  }
  template<>
  struct Collection<IdentityMatrix> {
    typedef double value_type;
    typedef unsigned size_type;
  };
}

int main()
{
  // Construct an IdentityMatrix and "solve" Ix = b
  // using MTL's conjugate gradient solver
  using namespace std;
  typedef mtl::dense_vector<unsigned> vt;

  const unsigned dim = 20;
  IdentityMatrix A(dim);
  vt b(dim); iota(b);
  vt x(dim);
  std::cout << "b: " << b << std::endl;
  std::cout << "x: " << x << std::endl;

  itl::pc::identity<IdentityMatrix> P(A);
  itl::basic_iteration<unsigned> iter(b, 1000, 0);

  itl::cg(A, x, b, P, iter);
  std::cout << "b: " << b << std::endl;
  std::cout << "x: " << x << std::endl;

  return 0;
}
