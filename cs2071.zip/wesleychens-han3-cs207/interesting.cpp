/**
 * @file interesting.cpp
 * Make an interesting graph. LOTS OF COPY/PASTE from shortest_path,subgraph
 *
 * @brief Reads in two files specified on the command line.
 * First file: 3D Points (one per line) defined by three doubles
 * Second file: Tetrahedra (one per line) defined by 4 indices into the point
 * list
 */

#include "CS207/SDLViewer.hpp"
#include "CS207/Util.hpp"
#include "CS207/Color.hpp"

#include "Graph.hpp"

#include <cmath>
#include <vector>
#include <fstream>
#include <iterator>
#include <queue>

/** An iterator that skips over elements of another iterator based on whether
 * those elements satisfy a predicate.
 *
 * Given an iterator range [@a first, @a last) and a predicate @a pred,
 * this iterator models a filtered range such that all i with
 * @a first <= i < @a last and @a pred(*i) appear in order of the original range.
 */
template <typename Pred, typename It>
class filter_iterator
    : private equality_comparable<filter_iterator<Pred,It>> {
 public:
  // Get all of the iterator traits and make them our own
  typedef typename std::iterator_traits<It>::value_type        value_type;
  typedef typename std::iterator_traits<It>::pointer           pointer;
  typedef typename std::iterator_traits<It>::reference         reference;
  typedef typename std::iterator_traits<It>::difference_type   difference_type;
  typedef typename std::input_iterator_tag                     iterator_category;

  typedef filter_iterator<Pred,It> self_type;

  // Constructor
  filter_iterator(const Pred& p, const It& first, const It& last)
      : p_(p), it_(first), end_(last) {
  }

  value_type operator*() const { return *it_; }
  self_type& operator++() {
    do { ++it_; } while (it_ != end_ && !p_(*it_));
    return *this;
  }
  bool operator==(const self_type& other) const {
    return it_ == other.it_ && end_ == other.end_;
  }

 private:
  Pred p_;
  It it_;
  It end_;
};

/** Helper function for constructing filter_iterators.
 *
 * Usage:
 * // Construct an iterator that filters odd values out and keeps even values.
 * std::vector<int> a = ...;
 * auto it = make_filtered(a.begin(), a.end(), [](int k) {return k % 2 == 0;});
 */
template <typename Pred, typename Iter>
filter_iterator<Pred,Iter> make_filtered(const Iter& it, const Iter& end,
                                         const Pred& p) {
  return filter_iterator<Pred,Iter>(p, it, end);
}

/** Include only nodes within some distance of a given point */
struct PointDistPredicate {
  const Point p_;
  const double dist_;

  PointDistPredicate(Point p, double dist) : p_(p), dist_(dist) {}
  template <typename NODE>
  bool operator()(const NODE& n) { return norm(n.position()-p_) <= dist_; }
};

/** Comparator that compares the distance from a given point p. */
struct MyComparator {
  const Point p_;
  MyComparator(const Point& p) : p_(p) {};

  template <typename NODE>
  bool operator()(const NODE& node1, const NODE& node2) const {
    return norm(node1.position()-p_) < norm(node2.position()-p_);
  }
};


/** Calculate shortest path lengths in @a g from the nearest node to @a point.
 * @param[in,out] g Input graph
 * @param[in] point Point to find the nearest node to.
 * @post Graph has modified node values indicating the minimum path length
 *           to the nearest node to @a point
 * @post Graph nodes that are unreachable to the nearest node to @a point have
 *           the value() -1.
 * @return The maximum path length found.
 *
 * Finds the nearest node to @a point and treats that as the root node for a
 * breadth first search.
 * This sets node's value() to the length of the shortest path to
 * the root node. The root's value() is 0. Nodes unreachable from
 * the root have value() -1.
 */
int shortest_path_lengths(Graph<int>& g, const Point& point) {
  // initialize all distances to -1
  for (auto it = g.node_begin(); it != g.node_end(); ++it) (*it).value() = -1;
  auto nearest_it = std::min_element(g.node_begin(), g.node_end(),
                                     MyComparator(point));
  std::queue<Graph<int>::Node> q;
  int next_val = 0;
  (*nearest_it).value() = next_val;
  q.push(*nearest_it);
  while (!q.empty()) {
    Graph<int>::Node& cur_node = q.front();
    q.pop();
    next_val = cur_node.value()+1;
    // add current node's connections to queue if unvisited
    for (auto it = cur_node.edge_begin(); it != cur_node.edge_end(); ++it) {
      auto next_node = (*it).node2();
      if (next_node.value() < 0) { // use node's value as a "visited" set
        next_node.value() = next_val;
        q.push(next_node);
      }
    }
  }
  return next_val-1;
}

// A heat color functor that returns a heat for a node
struct HeatColor {
  const double max_;
  HeatColor(const int max) : max_((double)max) {};

  template <typename NODE>
  CS207::Color operator()(const NODE& node) {
    return CS207::Color::make_heat(node.value()/max_);
  }
};

// A grey color functor that returns a grey value for a node
struct GreyColor {
  const double max_;
  GreyColor(const int max) : max_((double)max) {};

  template <typename NODE>
  CS207::Color operator()(const NODE& node) {
    return CS207::Color(node.value()/max_);
  }
};

int main(int argc, char* argv[])
{
  // Check arguments
  if (argc < 2) {
    std::cerr << "Usage: " << argv[0] << " NODES_FILE TETS_FILE\n";
    exit(1);
  }

  // Construct a Graph
  typedef Graph<int> GraphType;
  GraphType graph;
  std::vector<GraphType::node_type> nodes;

  // Create a nodes_file from the first input argument
  std::ifstream nodes_file(argv[1]);
  // Interprit each line of the nodes_file as a 3D Point and add to the Graph
  Point p;
  while (CS207::getline_parsed(nodes_file, p))
    nodes.push_back(graph.add_node(p));

  // Create a tets_file from the second input argument
  std::ifstream tets_file(argv[2]);
  // Interprit each line of the tets_file as four ints which refer to nodes
  std::array<int,4> t;
  while (CS207::getline_parsed(tets_file, t))
    for (unsigned i = 1; i < t.size(); ++i)
      for (unsigned j = 0; j < i; ++j)
        graph.add_edge(nodes[t[i]], nodes[t[j]]);

  // Print out the stats
  std::cout << graph.num_nodes() << " " << graph.num_edges() << std::endl;

  // Launch the SDLViewer
  CS207::SDLViewer viewer;
  viewer.launch();

  // Use shortest_path_lengths to set the node values to the path lengths
  // Construct a Color functor and view with the SDLViewer
  int longest_path = shortest_path_lengths(graph, {-1, 0, 1});

  PointDistPredicate pred = PointDistPredicate({0,0,-0.25}, 0.5);
  auto b_it = make_filtered(graph.node_begin(), graph.node_end(), pred);
  auto e_it = make_filtered(graph.node_end(), graph.node_end(), pred);
  auto node_map = viewer.empty_node_map(graph);
  viewer.add_nodes(b_it, e_it, GreyColor(longest_path), node_map);
  viewer.add_edges(graph.edge_begin(), graph.edge_end(), node_map);
  viewer.center_view();
  return 0;
}
