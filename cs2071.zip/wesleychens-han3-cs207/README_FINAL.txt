Bo Han, Kevin Schmid
Our final project consists of a meshed mass spring, combined with a collision detector and visualizer extensions to interact with the mesh during the simulation.

In order to run the executable, compile with "make" and run "./inflatable data/sphere{12,1082}*". Note that using the 1082 sphere will be slow.

To interact during the simulation, first select a triangle by clicking on it with the mouse or cycling through with the 'e' and 'w' keys. After selecting a triangle, press ['g','h'] to [de,in]crease the spring constant of that triangle's edges by 1, press ['t','y'] to [de,in]crease the z directional velocity of the selected triangle by 20, press 'p' to increase the velocity in the outward normal direction of the triangle (this moves the mesh in a more predictable manner).
Note: due to the design of the visualizer listener, pressing a particular key will affect all meshes in the simulation (further discussed in COLLAB_EVAL.txt).
