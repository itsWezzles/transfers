#ifndef CS207_COLLISION_HPP
#define CS207_COLLISION_HPP

/** @file CollisionDetector.hpp
 * @brief A collision detector for multiple well-formed meshes
 * 
 * Brian Connolly
 * Rajiv Tarigopula
 * CS207 Final Project
 * Collision Detection (Prompt 4)
 *
 */

#include "CS207/Util.hpp"
#include "Point.hpp"
#include "Graph.hpp"
#include "Mesh.hpp"
#include "MortonCoder.hpp"

#include <math.h>       // fabs,sqrt
#include <algorithm>
#include <vector>
#include <cassert>


/** @class CollisionDetector
 * @brief A template for multiple well-formed (closed) meshes.
 *
 * Users can add and remove well-formed meshes to the collision detector,
 * which will check for collisions between all possible pairs of meshes each time list_collisions() is called.
 * Users can also check for collisions between a specific pair of meshes at any timestep.
 *
 * M is user-defined mesh type.
 */
template<typename M>
class CollisionDetector {

 typedef M mesh_type;  //This is the user-defined mesh type.

 private:
  // Vector to hold meshes, which we will check for collisions
  std::vector<mesh_type*> meshes_;

 public:

  // PUBLIC TYPE DEFINITIONS 
  
  /** Type of this collision detector. */
  typedef CollisionDetector collision_type;

  /** Synonym for Node (following STL conventions). */
  typedef typename mesh_type::node_type node_type;

  /** Synonym for Edge (following STL conventions). */
  typedef typename mesh_type::edge_type edge_type;

  /** Synonym for Triangle (following STL conventions). */
  typedef typename mesh_type::Triangle triangle_type;  
  
  /** Type of indexes and sizes. */
  typedef unsigned size_type;

  
  // CONSTRUCTOR AND DESTRUCTOR

  /** Construct an empty CollisionDetector. 
   * 
   * meshes is a vector of all of the meshes the user has added to the collision
   * detector which the user wants to check for collisions
   * 
   */
  CollisionDetector() 
    : meshes_() {
  }
  /** Default destructor */
  ~CollisionDetector() = default;


  // PUBLIC FUNCTIONS

  /** Add a mesh to the collision detector
   *  @pre Mesh is a well-formed mesh
   *  @param @a mesh A pointer to the mesh you want to add to the collision detector
   *  @post Mesh is now in the vector of meshes @a meshes
   *
   *  Complexity O(1) 
   */  
  void add_mesh(mesh_type* mesh) {
    meshes_.push_back(mesh);
  }
  
  /** Find the number of meshes in the collision detector
   *  @return The number of meshes in @a meshes in the collision detector
   *
   *  Complexity O(1) 
   */  
  int size() {
    return meshes_.size(); 
  }
  
  /** Remove a mesh from the collision detector
   *  @pre @a mesh is a valid mesh of this collision detector
   *  @param @a mesh A pointer to the mesh you want to remove from the collision detector
   *  @post new size() == old size() - 1
   *
   *  Complexity polynomial in size() 
   */  
  void remove_mesh(mesh_type* mesh) {
    size_type index = mesh_index(mesh);
    if(index >= 0) {
      meshes_.erase(meshes_.begin() + index);
    }  
  }
  
  /** Check if a mesh is already in the collision detector
   *  @pre @a mesh is a well-formed mesh
   *  @param @a mesh A pointer to the mesh you want to check 
   *  @return True if mesh is is already in our vector of meshes, false otherwise
   *
   *  Complexity O(n)
   */    
  bool has_mesh(mesh_type* mesh) { 
    return mesh_index(mesh) >= 0; 
  }

  /** Return the index of a given mesh in our collision detector's mesh vector
   *  @pre @a mesh is a well-formed mesh
   *  @param @a mesh A pointer to the mesh you want to check 
   *  @return The index of the given mesh in @a meshes, -1 otherwise
   *
   *  Complexity O(n)
   */    
  size_type mesh_index(mesh_type* mesh) {
    int i = 0;
    for(auto iter = meshes_.begin(); iter != meshes_.end(); ++iter) {
      if((*iter) == mesh) return i;
      ++i;
    }

    return -1;
  }
  
  /** Check if collisions occur between meshes in the collision detector
   *
   *  @return True if there are collisions between meshes, false otherwise
   *
   *  Complexity polynomial in size() - (n^2)/2
   */    
  bool collisions_exist() {
    auto collisions = list_collisions();
    return collisions.size() != 0;
  }
      
  /** List collisions between meshes in the collision detector
   *
   *  @return A vector of pairs of meshes that had collisions at this timestep
   *
   *  Complexity polynomial in size() - (n^2)/2
   */  
  typename std::vector<std::pair<mesh_type*,mesh_type*> > list_collisions() {
    std::vector<std::pair<mesh_type*,mesh_type*> > collisions;
       
    int halfway = ceil(meshes_.size() / 2.0);
    auto iter = meshes_.begin();
    
    for(int i = 0; i < halfway; ++i) {     
      for(auto it = meshes_.begin(); it != meshes_.end(); ++it) {      
        if((*iter) == (*it)) continue;

        if(is_collision((*iter), (*it))) {
          collisions.push_back(std::make_pair((*iter),(*it)));
        }
      }  
      ++iter;
    }
    return collisions;
  }

  /** Determine if two specific meshes collide
   *  @pre Meshes are well-formed meshes
   *  @return True if the given meshes collide, false otherwise
   *  @param @a meshA A pointer to the mesh you want to check collision with @a meshB
   *  @param @a meshB A pointer to the mesh you want to check collision with @a meshA
   *  @post Will return true if a collision occurrs between these meshes at this timestep
   *
   * Complexity O(n * m) where n is the number of triangles in this mesh and m is
   * the number of nodes in the passed in mesh
   */
  bool is_collision(mesh_type* meshA, mesh_type* meshB) {
    // Loop through each node seeing if it intersects the triangle
    for(auto iter = meshA->node_begin(); iter != meshA->node_end(); ++iter) {
      if(is_collision((*iter), meshB)) {
        return true;
      }
    }

    return false;
  }
   /** Determine where two specific meshes collide
   *  @pre Meshes are well-formed meshes
   *  @return vector of nodes idx where collision occurs
   *  @param @a meshA A pointer to the mesh you want to check collision with @a meshB
   *  @param @a meshB A pointer to the mesh you want to check collision with @a meshA
   *  @post Will return vector of nodes idx where collision occurs
   *
   * Complexity O(n * m) where n is the number of triangles in this mesh and m is
   * the number of nodes in the passed in mesh
   */
  std::vector<size_type> where_collision(mesh_type* meshA, mesh_type* meshB) {
	std::vector<size_type> store;  
    // Loop through each node seeing if it intersects the triangle
    for(auto iter = meshA->node_begin(); iter != meshA->node_end(); ++iter) {
      if(is_collision((*iter), meshB)) {
        store.push_back((*iter).index());
      }
    }
	return store;

  }

  /** Determine if a node collides with a mesh
   *  @pre Node exists, mesh is a well-formed mesh
   *  @return True if the given node collides with the given mesh, false otherwise
   *  @param @a node A pointer to the node you want to check collision with @a mesh
   *  @param @a mesh A pointer to the mesh you want to check collision with @a node
   *  @post Will return true if a collision occurrs between this node and this mesh at this timestep
   *
   * Complexity O(m) where m is the number of nodes in the passed in mesh
   */
  bool is_collision(node_type node, mesh_type* mesh) {
    Point p0 = node.position();
    Point p1 = Point(0,0,1);

    int num_intersections = 0;

    for(auto iter = mesh->triangle_begin(); iter != mesh->triangle_end(); ++iter) {
      triangle_type tri = *iter;
      // Determine the normal to the plane the triangle is in
      Point u = tri.node(1).position() - tri.node(0).position();
      Point v = tri.node(2).position() - tri.node(0).position();
      Point n = cross(u, v);
      Point v0 = tri.node(0).position();

      double denom = dot(n, (p1 - p0));
      if(denom == 0) {
        continue;
      }

      double r = dot(n, (v0 - p0)) / denom;
      
      // If the ray intersects the plane, see if it intersects the triangle
      if(r >= 0) {
        Point intersect = p0 + r * (p1 - p0);
        Point w = intersect - v0;
        auto denom = pow(dot(u,v), 2) - dot(u,u) * dot(v,v);
        auto s = (dot(u,v) * dot(w,v) - dot(v,v) * dot(w,u)) / denom;
        auto t = (dot(u,v) * dot(w,u) - dot(u,u) * dot(w,v)) / denom;

        if(s >= 0 && t >= 0 && (s+t) <= 1) {
          ++num_intersections;
        }
      }
    }

    return (num_intersections % 2) == 1;
  }  
};
#endif
