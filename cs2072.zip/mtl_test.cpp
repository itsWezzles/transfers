/**
 * @file mtl_test.cpp
 * Test script for interfacing with MTL4 and it's linear solvers.
 */

#include <boost/numeric/mtl/mtl.hpp>
#include <boost/numeric/itl/itl.hpp>
#include <cassert>
#include <iostream>

struct IdentityMatrix
{
    IdentityMatrix(int dim) : dim_(dim) {}

    template <typename VectorIn, typename VectorOut, typename Assign>
    void mult(const VectorIn& v, VectorOut& w, Assign) const
    {
       // Identity multiplicaiton is trivial
       Assign::apply(w, v);       
    }

    template <typename VectorIn>
    mtl::vector::mat_cvec_multiplier<IdentityMatrix, VectorIn> operator*(const VectorIn& v) const
    {   return mtl::vector::mat_cvec_multiplier<IdentityMatrix, VectorIn>(*this, v);    }

    int dim_;
};

inline std::size_t size(const IdentityMatrix& A) { return A.dim_ * A.dim_; }
inline std::size_t num_rows(const IdentityMatrix& A) { return A.dim_; }
inline std::size_t num_cols(const IdentityMatrix& A) { return A.dim_; }

namespace mtl { 

    template <>
    struct Collection<IdentityMatrix>
    {
        typedef double value_type;
        typedef int    size_type;
    };

    namespace ashape {
        template <> struct ashape_aux<IdentityMatrix> 
        {       typedef nonscal type;    };
    }
}

int main(int, char**)
{

    const int size = 40;

    typedef IdentityMatrix matrix_type;
    IdentityMatrix A(size);

    mtl::dense_vector<double> x(size, 2.0), b(size);

    std::cout << "old x: " << x << std::endl;

    b = A * x;
    std::cout << "b: " << b << std::endl;
    x = 0;
    itl::cyclic_iteration<double> iter(b, 100, 1.e-11, 0.0, 5);

    cg(A, x, b, iter); 

    std::cout << "new x: " << x << std::endl;

    return 0;
}
