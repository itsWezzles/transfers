/**
 * @file mass_spring.cpp
 * Implementation of mass-spring system using Graph
 *
 * @brief Reads in two files specified on the command line.
 * First file: 3D Points (one per line) defined by three doubles
 * Second file: Tetrahedra (one per line) defined by 4 indices into the point
 * list
 */

#include <fstream>

//#define NO_GRAPHIC 0
// I'm using a codeblocks environment so as not to program on the Virtual Machine (got a new computer which has a high resolution and makes 
// the default Virtualbox 800x600 size very very small and unreadable =( #firstworldproblems
#ifndef NO_GRAPHIC
#include "CS207/SDLViewer.hpp"
#endif // NO_GRAPHIC
#include "CS207/Util.hpp"
#include "CS207/Color.hpp"

#include "Graph.hpp"
#include "Point.hpp"


// Gravity in meters/sec^2
static constexpr double grav = 9.81;

// node value type contains a mass and a velocity, info belonging to a point
struct node_value_type{

  double mass_;
  Point vel_;

  node_value_type() : mass_(0) {
      // set mass_ to 0 to indicate an invalid node_value_type (i.e. created, but not properly initialized, mass=0
      // this can be asserted for
  }

  void print(std::ostream & os) const {
    os << "<" << mass_ << "," << "(" << vel_ << ")" << ">";
  }
};

// similar struct to store edge data, including the spring constant and the initial length
struct edge_value_type{

  double K_;
  double initial_length_;

  edge_value_type() : K_(0), initial_length_(0) {
      // set K_ and length_ to 0 to indicate an invalid edge (i.e. created, but not properly initialized, length=0, K=0
      // again, can be asserted for to make sure poperly initialized
  }

  void print(std::ostream & os) const {
    os << "<" << initial_length_ << ">";
  }
};

typedef Graph<node_value_type, edge_value_type> GraphType;
typedef GraphType::Node Node;
typedef GraphType::Edge Edge;

// helpful printout inline functions
inline std::ostream & operator << (std::ostream & os, const node_value_type & nodeVal) {
    nodeVal.print(os);
    return os;
}

inline std::ostream & operator << (std::ostream & os, const edge_value_type & edgeVal) {
    edgeVal.print(os);
    return os;
}

inline std::ostream & operator << (std::ostream & os, const Node & node) {
    node.print(os);
    return os;
}

inline std::ostream & operator << (std::ostream & os, const Edge & edge) {
    edge.print(os);
    return os;
}

/** Force Framework */

/** Force function object for HW2 #1. */
struct Problem1Force {
  /** Return the force applying to @a n at time @a t.
   *
   * For HW2 #1, this is a combination of mass-spring force and gravity,
   * except that points at (0, 0, 0) and (1, 0, 0) never move. We can
   * model that by returning a zero-valued force. */

  template <typename NODE>
  Point operator()(NODE n, double t) {

    // check nodes to fix, and return 0 force
    if (n.position() == Point(0,0,0) || n.position() == Point(1,0,0)) {
      return Point (0,0,0);
    }
    else {
      // Apply the spring force
      Point spring = Point(0,0,0);

      auto incident_end = n.incident_end();
      for( auto incident_it = n.incident_begin(); incident_it != incident_end; ++incident_it) {
        // incident iterator goes through edge_uids so get the other node
        Edge e = *incident_it;
        Node node2;
        if ( n == e.node1()) {
          node2 = e.node2();
        }
        else {
          node2 = e.node1();
        }

        // use formula to sum effect of all incident nodes
        Point diff = n.position() - node2.position();
        double magnitude = norm(diff);
        spring += -e.value().K_*(diff/magnitude)*(magnitude - (*incident_it).value().initial_length_);

      }

      // final force includes spring force and gravitational force
      return spring + n.value().mass_ * Point(0,0,-grav);
    }
  }
};

/** Return the gravity force applying to @a n at time @a t. */
struct GravityForce {

  template <typename NODE>
  Point operator()(NODE n, double t) {
      return n.value().mass_ * Point(0,0,-grav);
  }
};

/** Return the mass spring force applying to @a n at time @a t. */
struct MassSpringForce {

  template <typename NODE>
  Point operator()(NODE n, double t) {

      // Apply the spring force
      Point spring = Point(0,0,0);

      auto incident_end = n.incident_end();
      for( auto incident_it = n.incident_begin(); incident_it != incident_end; ++incident_it) {
        // incident iterator goes through edge_uids so get the other node
        Edge e = *incident_it;
        Node node2;
        if ( n == e.node1()) {
          node2 = e.node2();
        }
        else {
          node2 = e.node1();
        }

        // use formula to sum effect of all incident nodes
        Point diff = n.position() - node2.position();
        double magnitude = norm(diff);
        spring += -e.value().K_*(diff/magnitude)*(magnitude - (*incident_it).value().initial_length_);
      }
      return spring;
  }
};

/** Return the damping force applying to @a n at time @a t. */
struct DampingForce {

  static constexpr double C = 0.1; // damping constant

  template <typename NODE>
  Point operator()(NODE n, double t) {
      return -C * n.value().vel_;
  }
};


// First method of trying to combine 2+ forces
#if 0 
template <typename F1, typename F2, typename F3>
struct CombinedForce
{
     F1 f1_;
     F2 f2_;
     F3 f3_;

     CombinedForce(F1 f1, F2 f2, F3 f3) : f1_(f1), f2_(f2), f3_(f3) {} // default constructor initializations

     template <typename NODE>
     Point operator() (NODE n, double t)
     {
        return f1_(n,t) + f2_(n,t) + f3_(n,t);
     }
};


template <typename F1, typename F2, typename F3>
CombinedForce<F1,F2,F3> make_combined_force(F1 f1, F2 f2, F3 f3)
{
    return CombinedForce<F1,F2,F3>(f1, f2, f3);
}
#endif

// Combine forces pairwise (a 3 combine will combine the first pair, then the second)
template <typename F1, typename F2>
struct CombinedForce
{
  F1 f1_;
  F2 f2_;

  CombinedForce(F1 f1, F2 f2) : f1_(f1), f2_(f2) {} // default constructor initializations

  template <typename NODE>
  Point operator() (NODE n, double t)
  {
    return f1_(n,t) + f2_(n,t);
  }
};

// CombinedForce for 2 forces
template <typename F1, typename F2>
CombinedForce<F1, F2> make_combined_force(F1 f1, F2 f2)
{
  return CombinedForce<F1,F2>(f1, f2);
}

// CombinedForce for 3 forces
template <typename F1, typename F2, typename F3>
CombinedForce<F1, CombinedForce<F2,F3> > make_combined_force(F1 f1, F2 f2, F3 f3)
{
  return CombinedForce<F1, CombinedForce<F2,F3> >(f1, CombinedForce<F2,F3>(f2, f3));
}

/** Constraint Framework */

// create node constraint functor
struct NodeConstraint {

  template <typename GRAPH>
  void operator()(GRAPH & g, double t) {
    for (auto it = g.node_begin(); it != g.node_end(); ++it)
    {
      Node nd = *it;
      if (nd.position() == Point(0,0,0) || nd.position() == Point(1,0,0)) { // if not anchored point
        // clear velocity
        nd.value().vel_ = Point(0,0,0);
      }
    }
  }
};

// create plane constraint functor
struct PlaneConstraint {

  template <typename GRAPH>
  void operator()(GRAPH & g, double t) {
    for (auto it = g.node_begin(); it != g.node_end(); ++it)
    {
      Node nd = *it;
      if ( dot(nd.position(), Point(0,0,1)) < -0.75) { // node on side of plane

        // set position to nearest point on plane
        nd.set_position(nd.position()*Point(1,1,0) + Point(0,0,-0.75));

        // set z component of velocity to zero
        nd.value().vel_.z = 0;
      }
    }
  }
};

// create spherical constraint functor
struct SphereConstraint {

  template <typename GRAPH>
  void operator()(GRAPH & g, double t) {
    static const Point c = Point (0.5,0.5,-0.5); // center
    static const double r = 0.15; // radius
    for (auto it = g.node_begin(); it != g.node_end(); ++it)
    {
      Node nd = *it;

      // intermediate values for constraint evaluation
      Point diffVector = nd.position() - c;
      Point R = diffVector / norm(diffVector); // unit vector from center to node

      if (norm(nd.position() - c) < r) { // node inside sphere

        // set position t nearest point on sphere
        nd.set_position(c + R * r);

        // set normal velocity to zero
        Point v = nd.value().vel_;
        nd.value().vel_ = v - dot(v,R)* R;
      }
    }
  }
};

// combined constraints much like combined force
template <typename C1, typename C2>
struct CombinedConstraint {

  template <typename GRAPH>
  void operator()(GRAPH & g, double t) {
    C1 c1;
    C2 c2;
    c1(g, t);
    c2(g, t);
  }
};

/** Change a graph's nodes according to a step of the symplectic Euler
 *    method with the given node force.
 * @param[in,out] g Graph
 * @param[in] t The current time (useful for time-dependent forces)
 * @param[in] dt The time step
 * @param[in] force Function object defining the force per node
 * @pre G::node_value_type supports all numeric types (float,int,double)
 * @return the next time step (usually @a t + @a dt)
 *
 * @a force is called as @a force(n, @a t), where n is a node of the graph
 * and @a t is the current time parameter. @a force must return a Point
 * representing the node's force at time @a t.
 */

template <typename G, typename F>
double symp_euler_step(G& g, double t, double dt, F force) {

  for( auto it = g.node_begin(); it != g.node_end(); ++it) {
    Node nd = *it;

    /* deprecated "if" condition - only when using Problem1Force*/
    //if (nd.position() != Point(0,0,0) && nd.position() != Point(1,0,0)) {
      Point pos_old = nd.position();
      nd.set_position(pos_old + nd.value().vel_ * dt);
    //}
  }

  // use constraint framework
  NodeConstraint nc;
  nc(g, t);

  /*
  // If running multiple constraints
  CombinedConstraint< NodeConstraint, CombinedConstraint<PlaneConstraint,SphereConstraint> > constraints;
  constraints(g, t);
  */

  for( auto it = g.node_begin(); it != g.node_end(); ++it) {
    Node nd = *it;

    if (nd.position() != Point(0,0,0) && nd.position() != Point(1,0,0)) { // ignore euler update for 2 points in combined
      Point v_old = nd.value().vel_;
      nd.value().vel_ = v_old + force(nd, t)*dt/nd.value().mass_;
    }
  }
  return t + dt;
}

int main(int argc, char* argv[]) {
  // Check arguments
  if (argc != 3) {
    std::cerr << "Usage: " << argv[0] << " NODES_FILE TETS_FILE\n";
    exit(1);
  }

  GraphType graph;
  std::vector<typename GraphType::node_type> nodes;

  // Create a nodes_file from the first input argument
  std::ifstream nodes_file(argv[1]);

  // Interpret each line of the nodes_file as a 3D Point and add to the Graph
  Point p;
  while (CS207::getline_parsed(nodes_file, p))
    nodes.push_back(graph.add_node(p));

  // Create a tets_file from the second input argument
  std::ifstream tets_file(argv[2]);
  // Interpret each line of the tets_file as four ints which refer to nodes
  std::array<int,4> t;
  while (CS207::getline_parsed(tets_file, t)) {
    for (unsigned i = 1; i < t.size(); ++i) {
      graph.add_edge(nodes[t[0]], nodes[t[1]]);
      graph.add_edge(nodes[t[0]], nodes[t[2]]);
#if 1
      // Diagonal edges: include as of HW2 #2
      graph.add_edge(nodes[t[0]], nodes[t[3]]);
      graph.add_edge(nodes[t[1]], nodes[t[2]]);
#endif
      graph.add_edge(nodes[t[1]], nodes[t[3]]);
      graph.add_edge(nodes[t[2]], nodes[t[3]]);
    }
  }

  // Initialize starting values for every node inthe graph
  for( auto it = graph.node_begin(); it != graph.node_end(); ++it)
  {
    // vel_ 0 is already initialized by default constuctor
    // make sure non-integer division for mass
    (*it).value().mass_ = 1.0 / graph.num_nodes();
  }

  // initialize the initial length and spring constant for every edge
  for( auto it = graph.edge_begin(); it != graph.edge_end(); ++it)
  {
    Edge e = *it;
    e.value().K_ = 100;
    e.value().initial_length_ = norm(e.node2().position() - e.node1().position());
  }

  // Print out the stats
  std::cout << graph.num_nodes() << " " << graph.num_edges() << std::endl;

  // Launch the SDLViewer if not in codeblocks environment
#ifndef NO_GRAPHIC
  CS207::SDLViewer viewer;
  auto node_map = viewer.empty_node_map(graph);
  viewer.launch();

  viewer.add_nodes(graph.node_begin(), graph.node_end(), node_map);
  viewer.add_edges(graph.edge_begin(), graph.edge_end(), node_map);

  viewer.center_view();
#endif

  // Begin the mass-spring simulation
  double dt = 0.0001;
  double t_start = 0;
  double t_end = 5.0;

  for (double t = t_start; t < t_end; t += dt) {
    //std::cout << "t = " << t << std::endl;

    /*Problem1Force is deprecated */
    //(void) symp_euler_step(graph, t, dt, Problem1Force());

    // one force grav only
    //(void) symp_euler_step(graph, t, dt, GravityForce());

    // two forces spring+grav
    // (void) symp_euler_step(graph, t, dt, make_combined_force(GravityForce(), MassSpringForce()));

    // three forces spring+grav+damp
    (void) symp_euler_step(graph, t, dt, make_combined_force(GravityForce(), MassSpringForce(), DampingForce()));

    // Update viewer with nodes' new positions if not in codeblocks environment
#ifndef NO_GRAPHIC
    viewer.add_nodes(graph.node_begin(), graph.node_end(), node_map);
    viewer.set_label(t);
#else
    for (auto it = graph.node_begin(); it != graph.node_end(); ++it) {
      std::cout << (*it) << std::endl;
    }
#endif

    // slow down animation for small grid sizes that run quickly
    if (graph.size() < 100)
      CS207::sleep(0.00001);
  }

  return 0;
}
