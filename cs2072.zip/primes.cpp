#include "CS207/Util.hpp"
#include <limits>

using namespace std;

/** Return true iff @a n is prime.
 * @pre @a n >= 0 */
bool is_prime(int n)
{
  // assert pre
  assert(n >= 0);
  // Two arrays to determine untested/prime and untested/composite

  /** Note: the divide by 100 is because using the full integer range results in memory overuse and is rejected by compiler and virtual machine */
  static array<int, numeric_limits<int>::max()/100> primeLookup;
  static array<int, numeric_limits<int>::max()/100> notPrimeLookup;

  // Check our history if we've tested this number before
  if (notPrimeLookup[n] == true) {
    return false;
  }
  else if (primeLookup[n] == true) {
    return true;
  }

  // else, calculate primeness from our algorithm
  for (int i = n-1; i*i >= n; --i) {
    if (n % i == 0) {
      notPrimeLookup[n] = true;
      return false;
    }
  }
  primeLookup[n] = true;
  return true;
}
/**
 * @post return true if @a is prime, else false */

int main()
{
  while (!cin.eof()) {
    // How many primes to test? And should we print them?
    cerr << "Input Number: ";
    int n = 0;
    CS207::getline_parsed(cin, n);
    if (n <= 0)
      break;

    cerr << "Print Primes (y/n): ";
    char confirm = 'n';
    CS207::getline_parsed(cin, confirm);
    bool print_primes = (confirm == 'y' || confirm == 'Y');

    CS207::Clock timer;

    // Loop and count primes from 2 up to n
    int num_primes = 0;
    for (int i = 2; i <= n; ++i) {
      if (is_prime(i)) {
        ++num_primes;
        if (print_primes)
          cout << i << endl;
      }
    }

    double elapsed_time = timer.seconds();

    cout << "There are " << num_primes
         << " primes less than or equal to " << n << ".\n"
         << "Found in " << (1000 * elapsed_time) << " milliseconds.\n\n";
  }

  return 0;
}
