#ifndef CS207_GRAPH_HPP
#define CS207_GRAPH_HPP

/** @file Graph.hpp
 * @brief An undirected graph type
 */

#include "CS207/Util.hpp"
#include "Point.hpp"

#include <algorithm>
#include <vector>
#include <set>
#include <queue>
#include <map>
#include <cassert>
#include <ostream>


/** @class Graph
 * @brief A template for 3D undirected graphs.
 *
 * Users can add and retrieve nodes and edges. Edges are unique (there is at
 * most one edge between any pair of distinct nodes).  Nodes cannot be declared
 * at the same position.
 */

// NEW
template <typename V, typename E>
class Graph {
 private:

 public:

  // PUBLIC TYPE DEFINITIONS

  /** Type of this graph. */
  typedef Graph graph_type;

  /** Predeclaration of Node type. */
  class Node;
  /** Synonym for Node (following STL conventions). */
  typedef Node node_type;

  /** Predeclaration of Edge type. */
  class Edge;
  /** Synonym for Edge (following STL conventions). */
  typedef Edge edge_type;

  /** Type of indexes and sizes. Return type of Node::index() and
      Graph::num_nodes(), argument type of Graph::node.
      chose to make unsigned int to add specificity */
  typedef unsigned int size_type;

  /** templating a V node_value_type */
  typedef V node_value_type;

  /** NEW templating a E edge_value_type */
  typedef E edge_value_type;

  /** Type of node iterators, which iterate over all graph nodes. */
  class node_iterator;

  /** Type of edge iterators, which iterate over all graph edges. */
  class edge_iterator;

  /** Type of incident iterators, which iterate incident edges to a node. */
  class incident_iterator;

  // CONSTRUCTOR AND DESTRUCTOR

  /** Construct an empty graph. */
  Graph() {
    // empty graph, nothing will be there, empty vectors declared
  }

  /** Default destructor */
  ~Graph() = default;

  // NODES

  /** @class Graph::Node
   * @brief Class representing the graph's nodes.
   *
   * Node objects are used to access information about the Graph's nodes.
   */
  class Node : private totally_ordered<Node> {
   public:
    /** Construct an invalid node.
     *
     * Valid nodes are obtained from the Graph class, but it
     * is occasionally useful to declare an @i invalid node, and assign a
     * valid node to it later. For example:
     *
     * @code
     * Node x;
     * if (...should pick the first node...)
     *   x = graph.node(0);
     * else
     *   x = some other node using a complicated calculation
     * do_something(x);
     * @endcode
     */
    Node()
      : graph_(0) {
	    // an invalid node is one that belongs to no graph
    }

    /** Return this node's position. */
    Point position() const {
      // access position using public getter of graph as node doesn't need to know how graph works
      return graph_->getPosition(node_uid_);
    }

    /**NEW Set this node's position */
    void set_position(const Point& p) {
        graph_->nodes_[node_uid_].position_ = p;
    }

    /** Return this node's index, a number in the range [0, nodes_.size()).
     * By my design, this does not return the nth active node index, node_uid_, as a getter
     */
    size_type index() const {
      // return current index
      return node_uid_;
    }

    /** Default destructor */
    ~Node() = default;

    /** getter & setter for value, returns reference to internal data
     * Usage:
     *        Node aNode = ...;
     *        aNode.value() = 5;
     *        node_value_type i = aNode.value();
     */

    node_value_type& value() {
      return graph_->nodes_[node_uid_].value_;
    }

    /** getter for value, const
     * Usage:
     *        const Node aNode = ...;
     *        node_value_type node_val = aNode.value();
     */
    const node_value_type& value() const {
      // value() is const, node_value will match const node_value_type& get_node_value(size_type uid) const
      return graph_->nodes_[node_uid_].value_;
    }

    /**
     * == operator
     * @pre valid declared node passed in
     * @post returns true only if node id's are equal and both nodes are on the same graph
    */
    bool operator == (const Node& node) const {
      return (this->graph_ == node.graph_ && this->node_uid_ == node.node_uid_);
    }

    /**
     * < operator
     * @pre valid declared node passed in
     * @post returns true only if first node id is nuemrically less than the second node and both belong to the same graph
    */
    bool operator < (const Node& node) const {
      return (this->graph_ == node.graph_ && this->node_uid_ < node.node_uid_);
    }

    // Get degree which is calculated from incident_list mapped to specific root node
    // @return must return number greater than or equal to zero, and less than num_nodes()
    size_type degree() const {
      return graph_->degree(node_uid_);
    }

    // Set begin iterator for incident iterator by using this node as root
    incident_iterator incident_begin() const {
    	incident_iterator it(graph_);

    // use the set iterator after using node uid to map to correct set
    	it.pos_ = graph_->incident_list_[node_uid_].begin();
    	return it;
    }

    // Set end interator for incident_interator by using this node as root
    incident_iterator incident_end() const {
      incident_iterator it(graph_);

    	// use the set iterator after using node uid to map to correct set
    	it.pos_ = graph_->incident_list_[node_uid_].end();
    	return it;
    }

    // Useful ostream printout function to help debug
    void print(std::ostream & os) const {
        os << "[" << index() << ":" << degree() << ":" << value() << "]";
    }

   private:
    // Only Graph can access our private members
    friend class Graph;

    // Declaring private data members for Node objects
    // Graph needs a way to construct valid Node objects

    // handle back to graph
    graph_type *graph_;

    // UID
    size_type node_uid_;

    // Constructor
    Node(graph_type *graph, size_type node_uid)
      : graph_(graph), node_uid_(node_uid) {
    }
  };

  /** Return this node's position */
  Point getPosition(size_type uid) const {
      // access position using current
      return nodes_[uid].position_;
  }

  /** Return the number of nodes in the graph. */
  size_type size() const {
    // returns number of active_ids
    return active_node_uid_.size();
  }

  /** Synonym for size(). */
  size_type num_nodes() const {
    return size();
  }

  /** Return deegree */
  size_type degree(size_type nuid)  {
      return incident_list_[nuid].size();
  }

  /**
   * Determine if this Node belongs to this Graph
   * Use defined operator
   * @return True if @a n is currently a Node of this Graph
   */
  bool has_node(const Node& n) const {

    // check input invariant
    assert(n.index() == nodes_[n.index()].index_);

    // immediate exit of not in graph
    if (n.graph_ == this)
    {
      // search for matching index nodes
      for (std::set<size_type>::const_iterator it = active_node_uid_.begin(); it != active_node_uid_.end(); ++it) {
        if (nodes_[*it].index_ == n.index()) {
            return true;
        }
      }
    }
    // if set exhausted, not found
    return false;
  }

  /** Determine if this Node of given position exists in graph
   * Overloaded from above
   * Use defined operator
   * @param valid position, and memory for uid to be replaced if found
   * @return True if @a position is a position of a node in the graph, stores the found node into uid if existing
   */
  bool has_node(const Point& position, size_type& uid) const {
    // iteratte through set of active nodes
    for (std::set<size_type>::const_iterator it = active_node_uid_.begin(); it != active_node_uid_.end(); ++it) {
      // if match
      if ( nodes_[*it].position_ == position) {
          // assign found id via iterator to the input parameter
          uid = *it;
          return true;
      }
    }
    // if set exhausted, not found
    return false;
  }

  /** Add a node to the graph, returning the added node.
   * @param[in] position The new node's position and value
   * @param[in] node_value_type if given, must be of node_value_type
   * @post new active_node_id.size() == old active_node_id.size() + 1
   * @post result_node.index() == old size()
   *
   * @pre getNextNodeId returns active_node_id.size()
   */
  Node add_node(const Point& position, node_value_type value = node_value_type() ) {

    // assert invariant
    assert_node_storage_invariant();

    // declare temp id space to hold id of already existing node
    size_type foundId;

    // first check if node already exists using overloaded has_node(const Position&, size_type &)
    // if node exists, update its value
    if (has_node(position, foundId)) {
      Node n(this, foundId);
      n.value() = value;
      return n;
    }

    // get nextID but must be called before push_back, else will return off by one error
    size_type next_uid_ = getNextNodeId();

    // if needing to push back
    if (nodes_.size() == active_node_uid_.size()) {

      // add node data to internal data struct
      nodes_.push_back(node_internal());
    }

    // save index for this node
    nodes_[next_uid_].index_ = next_uid_;

    // save position within this struct
    nodes_[next_uid_].position_ = position;

    // save value for this node
    nodes_[next_uid_].value_ = value;

    // add to uid set
    active_node_uid_.insert(next_uid_);

    //incident_list_[next_uid_] = std::set<size_type>();
    incident_list_.insert(std::pair<size_type, std::set<size_type>>(next_uid_, std::set<size_type>()));

    // assert invariant
    assert_node_storage_invariant();

    // return newly added and created node
    return Node(this, next_uid_);
  }


  /** Return the node with active index @a i.
   * @pre 0 <= @a i < active_node.uid_.size()
   * @post result_node.index() == *active_node_uid_.find(i)
   */
  Node node(size_type i) const {

    // assert precondition
    assert(i < this->size());

    // return i th active node in the active node list
    std::set<size_type>::const_iterator cit = active_node_uid_.begin();
    for (int j =0; j < i; ++j)
    {
        ++cit;
    }
    Node n(const_cast<graph_type *>(this), *cit);
    assert_node_index_invariant(n);
    return n;
  }

  /** gets next available node id to help reuse IDs
   * @return returns first numeric free ID, else next one in line
   * @invariant free_node_uid.size() +  active_node_uid_.size() == nodes_.size()
   * must be called before push_back, else will return off by one error
  **/
  size_type getNextNodeId() {
    // generate new ID if none freed
    if (free_node_uid_.empty()) {
      return nodes_.size();
    }
    // return first freed id if available
    else {
      size_type next_id = free_node_uid_.front();
      free_node_uid_.pop();
      return next_id;
    }
  }

  /** Remove a node from the graph.
   * @param[in] n Node to be removed
   * @pre @a n is a valid node of this graph.
   * @post new size() == old size() - 1
   *
   * Can invalidate outstanding iterators. @a n becomes invalid, as do any
   * other Node objects equal to @a n. All other Node objects remain valid.
   */

  // signature is not set up to return anything
  void remove_node(const Node& n) {

    // validate parameter invariant
    assert(n.index() == nodes_[n.index()].index_);

    // assert invariant
    assert_node_storage_invariant();

    // erase node index from active uid list, save output of set::erase() for good practice
    size_type numErase = active_node_uid_.erase(n.index());

    if (numErase != 0) {
      // add erased index to freed list for recycling
      free_node_uid_.push(n.index());

      // call function to remove all edges of node, storing numEdgesRemoved for good practice
      size_type numEdgesRemoved = remove_all_incident(n);

      // remove set from the node->set mapping in incident_list_
      incident_list_.erase(n.index());

      // would return here if wanted to return numEdgesRemoved
      // quiet compiler warning
      (void) numEdgesRemoved;

    }
    // assert invariant
    assert_node_storage_invariant();

    return;
  }

  /** Remove all nodes and edges from this graph.
   * @post num_nodes() == 0 && num_edges() == 0
   *
   * Invalidates all outstanding Node and Edge objects.
   */
  void clear() {

    // clear node_internal vector
    nodes_.clear();

    // clear edge_internal vector
    edges_.clear();

    // clear active and free nodes
    active_node_uid_.clear();
    clearQueue(free_node_uid_);

    // clear active and free edges
    active_edge_uid_.clear();
    clearQueue(free_edge_uid_);

    // clear incident_list_
    incident_list_.clear();
  }

  void clearQueue(std::queue<size_type> &q) {
    // clear queue by swapping with empty one
    std::queue<size_type> empty;
    std::swap(q, empty);
  }

  // EDGES

  /** @class Graph::Edge
   * @brief Class representing the graph's edges.
   *
   * Edges are order-insensitive pairs of nodes. Two Edges with the same nodes
   * are considered equal if they connect the same nodes, in either order.
   */
  class Edge : private totally_ordered<Edge> {
   public:
    /** Construct an invalid Edge. */
    Edge()
      : graph_(0) {
	    // an invalid edge is one that does not belong to any graph
    }

    /** Return a node of this Edge */
    Node node1() const {
      // access current UID's internals of node1 via getter
      return graph_->getNode1(edge_uid_);
    }

    /** Return the other node of this Edge */
    Node node2() const {
      // access current UID's internals of node2 via getter
      return graph_->getNode2(edge_uid_);
    }

    /** Return this edge's index, a number in the range [0, edges_.size()). */
    size_type index() const {
      // return current index
      return edge_uid_;
    }

    /** Default detructor */
    ~Edge() = default;

    /** NEW getter & setter for value, returns reference to internal data
     * Usage:
     *        Edge aEdge = ...;
     *        aEdge.value() = 5;
     *        edge_value_type i = aEdge.value();
     */

    edge_value_type& value() {
      return graph_->edges_[edge_uid_].value_;
    }

    /** NEW getter for value, const
     * Usage:
     *        const Edge aEdge = ...;
     *        edge_value_type edge_val = aEdge.value();
     */
    const edge_value_type& value() const {
      // value() is const, node_value will match const node_value_type& get_node_value(size_type uid) const
      return graph_->edges_[edge_uid_].value_;
    }


    /** == operator
     * @pre valid declared edge passed in
     * @post returns true only if edge id's are equal and both edges are on the same graph
    */
    bool operator == (const Edge& edge) const {
      return (this->graph_ == edge.graph_ && this->edge_uid_ == edge.edge_uid_);
    }

    /** < operator
     * @pre valid declared edge passed in
     * @post returns true only if edge id's are equal and both edges are on the same graph
    */
    bool operator < (const Edge& edge) const {
      return (this->graph_ == edge.graph_ && this->edge_uid_ < edge.edge_uid_);
    }

    // ostream function to help debug
    void print(std::ostream & os) const {
        os << "(" << node1().index() << "," << node2().index() << ")";
    }

   private:

    // Only Graph can access our private members
    friend class Graph;

    // Use this space declare private data members for Edge objects
    // Graph needs a way to construct valid Edge objects

    // handle back to graph
    graph_type *graph_;

    // UID
    size_type edge_uid_;

    // Constructor
    Edge(graph_type *graph, size_type edge_uid)
      : graph_(graph), edge_uid_(edge_uid) {
    }
  };

  /** return const inetrnal index */
  size_type const & internal_index(Node const & n) const {
    return nodes_[n.index()].index_;
  }

  /** Return first node of this Edge, proxy public getter */
  Node getNode1(size_type uid) const {
    // access current UID's internals of node1
    return edges_[uid].node1_;
  }

  /** Return the other node of given Edge, proxy public getter */
  Node getNode2(size_type uid) const {
    // access current UID's internals of node1
    return edges_[uid].node2_;
  }

  /** Return the total number of edges in the graph. */
  size_type num_edges() const {
    // return private member
    return active_edge_uid_.size();
  }

  /** Return the edge with active index @a i.
   * @pre 0 <= @a i < num_edges()
   * @post result_edge.index() == *active_node_uid_.find(i)
   */
  Edge edge(size_type i) {
    // assert preconditions
    assert(i < this->num_edges());

    // return ith active edge in new map
    std::set<size_type>::const_iterator cit = active_edge_uid_.begin();
    for (int j =0; j < i; ++j)
    {
        ++cit;
    }
    Edge e(this, *cit);
    assert_edge_index_invariant(e);
    return e;
  }

  /** Test whether two nodes are connected by an edge.
   * Using defined operators now
   * @pre @a a and @a b are valid nodes of this graph
   * @return true if, for some @a i, edge(@a i) connects @a a and @a b.
   */
  bool has_edge(const Node& a, const Node& b) const {

    // validate parameter invariant for node a
    assert(a.index() == nodes_[a.index()].index_);

    // validate parameter invariant for node b
    assert(b.index() == nodes_[b.index()].index_);

    // iterate through vector of uids to compare if the internal edge struct matches
    for (std::set<size_type>::const_iterator it = active_edge_uid_.begin(); it != active_edge_uid_.end(); ++it) {
        // if both nodes match, we have the edge using defined operators
        if ( (edges_[*it].node1_ == a && edges_[*it].node2_ == b)
             || (edges_[*it].node1_ == b && edges_[*it].node2_ == a) ) {
          return true;
        }
    }
    // if set exhausted, not found
    return false;
  }

  /** Test whether two nodes are connected by an edge.
   * Overlaoded from above
   * @pre @a a and @a b are valid nodes of this graph, @a uid is declared space for param uid if found
   * @return true if, for some @a i, edge(@a i) connects @a a and @a b, updates param uid with uid of found edge.
   * @param @a size_type uid memory declared to be updated
   */
  bool has_edge(const Node& a, const Node& b, size_type& uid) const {

    // validate parameter invariant for node a
    assert(a.index() == nodes_[a.index()].index_);

    // validate parameter invariant for node b
    assert(b.index() == nodes_[b.index()].index_);

    // iterate through vector of uids to compare if the internal edge struct matches
    for (std::set<size_type>::const_iterator it = active_edge_uid_.begin(); it != active_edge_uid_.end(); ++it) {
        // if both nodes match, we have the edge using defined operators
        if ( (edges_[*it].node1_ == a && edges_[*it].node2_ == b)
             || (edges_[*it].node1_ == b && edges_[*it].node2_ == a) ) {
          uid = *it;
          return true;
        }
    }
    // if set exhausted, not found
    return false;
  }

  /** Add an edge to the graph, or return the current edge if it already exists.
   * @pre @a a and @a b are distinct valid nodes of this graph
   * @return an Edge object e with e.node1() == @a a and e.node2() == @a b
   * @post has_edge(@a a, @a b) == true
   * @post If old has_edge(@a a, @a b), new num_edges() == old num_edges().
   *       Else,                        new num_edges() == old num_edges() + 1.
   *
   * Can invalidate edge indexes -- in other words, old edge(@a i) might not
   * equal new edge(@a i). Must not invalidate outstanding Edge objects.
   */

   // NEW 3rd condition
  Edge add_edge(const Node& a, const Node& b, edge_value_type value = edge_value_type()) {

    // validate parameter invariant for node a
    assert(a.index() == nodes_[a.index()].index_);

    // validate parameter invariant for node b
    assert(b.index() == nodes_[b.index()].index_);

    // assert invariant
    assert_edge_storage_invariant();

    // declare temp id space to hold id of already existing edge
    size_type foundId;

    // first check if edge already exists using overlaoded has_edge(const Node&, const Node&, const size_type&)
    if ( has_edge(a, b, foundId) ) {
      return Edge(this, foundId);
    }
    // else create a new edge and store into vectors

    // get current size but must be called before push_back, else will return off by one error
    size_type next_uid_ = getNextEdgeId();

    // if requiring push back
    if (edges_.size() == active_edge_uid_.size()) {

      // add node data to internal data struct
      edges_.push_back(edge_internal());
    }

    // save index within data struct
    edges_[next_uid_].index_ = next_uid_;

    // save node1 within data struct
    edges_[next_uid_].node1_ = a;

    // save node2 within data struct
    edges_[next_uid_].node2_ = b;

    // add to uid set
    active_edge_uid_.insert(next_uid_);

    // update adj list
    incident_list_add_edge(next_uid_);

    // assert invariant
    assert_edge_storage_invariant();

    // return newly added edge
    return Edge(this, next_uid_);

  }

/** gets next available edge id to help reuse IDs
  * @return returns first numeric free ID, else next one in line
  * @invariant free_edge_uid.size() +  active_edge_uid_.size() == edges_.size()
  * must be called before push_back, else will return off by one error
  **/
  size_type getNextEdgeId() {
    // generate next ID from size of none freed
    if (free_edge_uid_.empty()) {
      return edges_.size();
    }
    // use first freed ID if available
    else {
      size_type next_id = free_edge_uid_.front();
      free_edge_uid_.pop();
      return next_id;
    }
  }

  /** updates the newly added edge to incident_list_
  * @tparam the edge_uid_ representing the new edge being added
  * @post node1 associated set.size() increased by one
  * @post node2 associated set.size() increased by one
  **/
  void incident_list_add_edge(size_type edge_id) {
    // insert edge id into both sets mapped by id's of node 1 and node 2
    incident_list_[getNode1(edge_id).index()].insert(edge_id);
    incident_list_[getNode2(edge_id).index()].insert(edge_id);
  }

  /** Remove an edge, if any, returning the number of edges removed.
   * @param[in] a,b The nodes potentially defining an edge to be removed.
   * @return 1 if old has_edge(@a a, @a b), 0 otherwise
   * @pre @a a and @a b are valid nodes of this graph
   * @post !has_edge(@a a, @a b)
   * @post new num_edges() == old num_edges() - result
   */
  size_type remove_edge(const Node& a, const Node& b) {

    // validate parameter invariant for node a
    assert(a.index() == nodes_[a.index()].index_);

    // validate parameter invariant for node b
    assert(b.index() == nodes_[b.index()].index_);

    // assert invariant
    assert_edge_storage_invariant();

    // declare temp id space to hold id of already existing edge
    size_type foundId;

    // getDegree for assertion below
    size_type degreeN1 = a.degree();
    size_type degreeN2 = b.degree();

    // first check if edge already exists using overlaoded has_edge(const Node&, const Node&, const size_type&)
    if ( has_edge(a, b, foundId) ) {
      // erase edge index from active uid list
      size_type numErase = active_edge_uid_.erase(foundId);

      // add erased index to freed list for recycling
      if (numErase != 0) {
        free_edge_uid_.push(foundId);

        // update incident_list_ with removed edge
        incident_list_remove_edge(foundId);
      }

      assert(a.degree() == degreeN1 - 1 && b.degree() == degreeN2 - 1);

      // return number of elements erased just like by set::erase()
      return numErase;
    }

    // assert invariant
    assert_edge_storage_invariant();

    return 0;
  }

  /** Remove an edge, if any, returning the number of edges removed.
   * @param[in] e The edge to remove
   * @pre @a e is a valid edge of this graph
   * @pre has_edge(@a e.node1(), @a e.node2())
   * @post !has_edge(@a e.node1(), @a e.node2())
   * @post new num_edges() == old num_edges() - 1
   */
  size_type remove_edge(const Edge& e) {

    // validate parameter invariant for node a
    assert(e.index() == edges_[e.index()].index_);

    // assert invariant
    assert_edge_storage_invariant();

    // assuming edge already exists in graph, remove directly

    // erase edge index from active uid list
    size_type numErase = active_edge_uid_.erase(e.index());

    // add erased index to freed list for recycling
    if (numErase != 0)
    {
      free_edge_uid_.push(e.index());

      // update incident_list_ with removed edge
      incident_list_remove_edge(e.index());
    }

    // assert invariant
    assert_edge_storage_invariant();

    // will return as set::erase() returns, expecting one as edge is already validated by precondition
    return numErase;
  }

  /** Remove all incident edges to given node, returning number edges removed
   * @param[in] a,b The nodes potentially defining an edge to be removed.
   * @return result>0 if old has_edge(@a a, n) where n is any active node, 0 otherwise
   * @pre @a a is valid node of this graph
   * @post for all n in active nodes represented by uid, !has_edge(@a a, n)
   * @post new num_edges() == old num_edges() - result
   */
  size_type remove_all_incident(const Node& a) {

    // validate parameter invariant for node a
    assert(a.index() == nodes_[a.index()].index_);

    // assert invariant
    assert_edge_storage_invariant();

    // initialize remove counter
    size_type numErase = 0;

    // search for edges with give node within this graph element
    // TODO in the future this can be done via a backlink via the adjacency list instead of searching again
    for (std::set<size_type>::const_iterator it = active_edge_uid_.begin(); it != active_edge_uid_.end();) {

      if (edges_[*it].node1_ == a || edges_[*it].node2_ == a) {

        // erase edge index from active edge uid list, check return code

        size_type euid = *(it++);
        size_type checkErased = active_edge_uid_.erase(euid);

        // if indeed erased
        if (checkErased != 0) {
          // update total counter
          numErase += checkErased;

          // add erased index to freed list for recycling
          free_edge_uid_.push(euid);

          // update incident_list_ with removed edge
          incident_list_remove_edge(euid);
        }
      }
      else {
        ++it;
      }
    }
    // assert invariant
    assert_edge_storage_invariant();

    return numErase;
  }

  /** updates incident_list_ to reflect newly removed edge
  * @tparam the edge_uid_ representing the edge being removed
  * @post node1 associated set.size() decreased by one
  * @post node2 associated set.size() decreased by one
  **/
  void incident_list_remove_edge(size_type edge_id) {

    // get nodes and degeres
    Node a = getNode1(edge_id);
    Node b = getNode2(edge_id);
    size_type degreeN1 = a.degree();
    size_type degreeN2 = b.degree();

    // insert edge id into both sets mapped by id's of node 1 and node 2
    incident_list_[getNode1(edge_id).index()].erase(edge_id);
    incident_list_[getNode2(edge_id).index()].erase(edge_id);

    // assert degree invariant
    assert ((a.degree() == degreeN1 - 1) && (b.degree() == degreeN2 - 1));
  }

  // ITERATORS

  /** @class Graph::node_iterator
   * @brief Iterator class for nodes. A forward iterator. */
  class node_iterator {
   public:
    // These type definitions help us use STL's iterator_traits.
    /** Element type. */
    typedef Node value_type;
    /** Type of pointers to elements. */
    typedef Node* pointer;
    /** Type of references to elements. */
    typedef Node& reference;
    /** Iterator category. */
    typedef std::input_iterator_tag iterator_category;
    /** Difference between iterators */
    typedef std::ptrdiff_t difference_type;

    /** Construct an invalid node_iterator. */
    node_iterator()
      : graph_(0) {
      // invalid node_iterator assigned to 0 for graph pointer (good for assertions)
    }

    /** Create a node returned by the internal representation of the set iterator */
    Node operator*() const {
        //std::cout << "active node uid=" << *pos_ << std::endl;
        return Node(graph_, *pos_);
    }

    /** Increase iterator by increasing the set iterator*/
    node_iterator& operator++() {
      ++pos_;
      return *this;
    }

    /** equals operator, compare position from STL iterator */
    bool operator == (const node_iterator it) const {
      return (this->pos_ == it.pos_);
    }

    /** logical opposite of '==' operator */
    bool operator != (const node_iterator it) const {
      return !(*this == it);
    }

   private:
    // allow graph to access
    friend class Graph;
    friend class Node;

    // allow edge_iterator to access but not necessary in my implementation
    friend class edge_iterator;

    // handle back to graph
    graph_type * graph_;

    // iterator for the set data structure for active_node_uid
    std::set<size_type>::iterator pos_;

    // constructor
    node_iterator(graph_type* graph)
      : graph_(graph) {
    }
  };

  // get starting iterator point for node_iterators
  node_iterator node_begin() {
    node_iterator it(this);

    // same behavior as .begin() for STL iterators
    it.pos_ = active_node_uid_.begin();

    return it;

  }

  // get ending iterator point for node_iterators
  node_iterator node_end() {
    node_iterator it(this);

    // same behavior as .end() for STL iterators
    it.pos_ = active_node_uid_.end();

    return it;
  }


  /** @class Graph::edge_iterator
   * @brief Iterator class for edges. A forward iterator. */
  class edge_iterator {
   public:
    // These type definitions help us use STL's iterator_traits.
    /** Element type. */
    typedef Edge value_type;
    /** Type of pointers to elements. */
    typedef Edge* pointer;
    /** Type of references to elements. */
    typedef Edge& reference;
    /** Iterator category. */
    typedef std::input_iterator_tag iterator_category;
    /** Difference between iterators */
    typedef std::ptrdiff_t difference_type;

    /** Construct an invalid edge_iterator. */
    edge_iterator()
      : graph_(0) {
      // invalid edge_iterator assigned to 0 for graph pointer (good for assertions)
    }

    /** Create an edge returned by the internal representation of the set iterator */
    Edge operator*() const {
      return Edge(graph_, *pos_);
    }

    /** Increase iterator by increasing the set iterator*/
    edge_iterator& operator++() {
      ++pos_;
      return *this;
    }

    /** equals operator, compare position from STL iterator */
    bool operator == (const edge_iterator& it) const {
      return (this->pos_ == it.pos_);
    }

    /** logical opposite of '==' operator */
    bool operator != (const edge_iterator& it) const {
      return !(*this == it);
    }

   private:
    // allowing graph to access
    friend class Graph;

    // handle back to graph
    graph_type * graph_;

    // iterator for the set data structure for active_edge_uid
    std::set<size_type>::iterator pos_;

    // constructor
    edge_iterator(graph_type * graph)
      : graph_(graph) {
    }
  };

  // get beginning iterator point for edge_iterators
  edge_iterator edge_begin() {
    edge_iterator it(this);

    // same behavior as .begin() for STL iterators
    it.pos_ = active_edge_uid_.begin();

    return it;
  }

  // get ending iterator point for edge_iterators
  edge_iterator edge_end() {
    edge_iterator it(this);

    // same behavior as .end() for STL iterators
    it.pos_ = active_edge_uid_.end();

    return it;
  }


  /** @class Graph::incident_iterator
   * @brief Iterator class for edges incident to a given node. A forward
   * iterator. */
  class incident_iterator {
   public:
    // These type definitions help us use STL's iterator_traits.
    /** Element type. */
    typedef Edge value_type;
    /** Type of pointers to elements. */
    typedef Edge* pointer;
    /** Type of references to elements. */
    typedef Edge& reference;
    /** Iterator category. */
    typedef std::input_iterator_tag iterator_category;
    /** Difference between iterators */
    typedef std::ptrdiff_t difference_type;

    /** Construct an invalid incident_iterator. */
    incident_iterator()
      : graph_(0) {
        // invalid incident_iterator tied to no graph
    }

    /** Create an edge returned by the internal representation of the set iterator */
    Edge operator*() const {
      return Edge(graph_, *pos_);
    }

    /** Increase iterator by increasing the set iterator*/
    incident_iterator& operator++() {
      ++pos_;
      return *this;
    }

    /** equals operator, compare position from STL iterator as well as graph */
    bool operator == (const incident_iterator& it) const {
      return (this->pos_ == it.pos_ && this->graph_ == it.graph_);
    }

    /** logical opposite of '==' operator */
    bool operator != (const incident_iterator& it) const {
      return !(*this == it);
    }

   private:
    friend class Graph;

    // handle back to graph
    graph_type* graph_;

    // iterator for the set data structure for a given root node's adj nodes
    std::set<size_type>::iterator pos_;

    // constructor
    incident_iterator(graph_type* graph)
      : graph_(graph) {
    }
  };

  // Data structure for incident/edge use - map of nodeuid, then set of edge_uids_ incident to it
  std::map< size_type, std::set<size_type> > incident_list_;

 private:

    // assertion functions for various invariants
    void assert_node_index_invariant(Node const & n) const {
        assert( n.index() == nodes_[n.index()].index_);
    }

    void assert_node_storage_invariant() const {
        assert(active_node_uid_.size() + free_node_uid_.size() == nodes_.size());
    }

    void assert_edge_index_invariant(Edge const & e) const {
        assert( e.index() == edges_[e.index()].index_);
    }

    void assert_edge_storage_invariant() const {
        assert(active_edge_uid_.size() + free_edge_uid_.size() == edges_.size());
    }

  // declaration of structs to package all the data that a node/edge would need
  struct node_internal {
    Point position_;
    size_type index_;
    // store node value
    node_value_type value_;
  };

  struct edge_internal {
    Node node1_;
    Node node2_;
    size_type index_;
    // store edge value
    edge_value_type value_;
  };

  // Full data for nodes and edges indexed by respective uid
  std::vector<node_internal> nodes_;
  std::vector<edge_internal> edges_;

  /** A set containing active nodes/edges respectively (since they're all typedefed to unsigned which has < operator defined)
  * This will allow for faster lookup when we need to remove, rather than iterating through a vector
  */

  std::set<size_type> active_node_uid_;
  std::set<size_type> active_edge_uid_;

  // Queues containing list of removed nodes/edges uids to be recycled, FIFO
  std::queue<size_type> free_node_uid_;
  std::queue<size_type> free_edge_uid_;
};

// inline function to help debug/print nodes
inline std::ostream & operator << (std::ostream & os, const Graph<double,double>::Node & node) {
    node.print(os);
    return os;
}

// inline function to help debug/print edges
inline std::ostream & operator << (std::ostream & os, const Graph<double,double>::Edge & edge) {
    edge.print(os);
    return os;
}

#endif
