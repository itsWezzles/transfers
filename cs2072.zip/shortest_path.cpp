/**
 * @file shortest_path.cpp
 * Test script for using our templated Graph to determine shortest paths.
 *
 * @brief Reads in two files specified on the command line.
 * First file: 3D Points (one per line) defined by three doubles
 * Second file: Tetrahedra (one per line) defined by 4 indices into the point
 * list
 */

#include "CS207/SDLViewer.hpp"
#include "CS207/Util.hpp"
#include "CS207/Color.hpp"

#include "Graph.hpp"

#include <vector>
#include <fstream>

typedef Graph<int> GraphType;

int longest_path_length = 0;

/** Comparator that compares the distance from a given point p.
 */
struct MyComparator {
   Point p_;
   MyComparator(const Point& p) : p_(p) {
   };

   template <typename NODE>
   bool operator()(const NODE& node1, const NODE& node2) const {
    //std::cout << node1 << " " << node2 << std::endl;
    // use Point math to calculate L2 normSq of difference which is proportional to distance
    if (normSq(node1.position() - p_) < normSq(node2.position() - p_))
      return true;
    else
      return false;
  }
};

int BFS(const GraphType::Node& n, int depth);
void BFS_assign_shortest_path_length(const GraphType::Node& n, int depth);
int BFS_get_longest_path_length(const GraphType::Node& n);

/** Calculate shortest path lengths in @a g from the nearest node to @a point.
 * @param[in,out] g Input graph
 * @param[in] point Point to find the nearest node to.
 * @post Graph has modified node values indicating the minimum path length
 *           to the nearest node to @a point
 * @post Graph nodes that are unreachable to the nearest node to @a point have
 *           the value() -1.
 * @return The maximum path length found.
 *
 * Finds the nearest node to @a point and treats that as the root node for a
 * breadth first search.
 * This sets node's value() to the length of the shortest path to
 * the root node. The root's value() is 0. Nodes unreachable from
 * the root have value() -1.
 */
int shortest_path_lengths(GraphType& g, const Point& point) {

  // get node iterators front and back
  GraphType::node_iterator nodeIter = g.node_begin();
  GraphType::node_iterator nodeIterEnd = g.node_end();

  // use min::element to find root
  GraphType::node_iterator nodeRoot = std::min_element(nodeIter,nodeIterEnd,MyComparator(point));

  // set root node as depth zero, next level has depth 1, so on...
  (*nodeRoot).value() = 0;
  std::cout << "root node " << *nodeRoot << std::endl;

#if 0
  return BFS(*nodeRoot, 1);
#else
  BFS_assign_shortest_path_length(*nodeRoot, 1);
  return BFS_get_longest_path_length(*nodeRoot);
#endif
}

// BFS combines shortest path length assignment and longest path length search
// depth: current depth from top root node, to be assigned to child nodes
int BFS(const GraphType::Node& n, int depth)
{
  if (n.degree() == 0) return n.value(); // single root node

  std::vector<GraphType::Node> unvisited_list;
  std::vector<GraphType::Node> node2_list;
  GraphType::incident_iterator incidentIter;
  GraphType::incident_iterator incidentIterEnd = n.incident_end();
  for(incidentIter = n.incident_begin() ; incidentIter!=incidentIterEnd; ++incidentIter) {
    GraphType::Node  node2;
    if ( n == (*incidentIter).node1()) {
        node2 = (*incidentIter).node2();
    }
    else {
        node2 = (*incidentIter).node1();
    }
    node2_list.push_back(node2);

    if (node2.value() == -1) // this child node has not been visited
    {
        node2.value() = depth;
        unvisited_list.push_back(node2);
    }
    else if (node2.value() > depth) { // depth is a shorter path for this child node, "pull" it up
        node2.value() = depth;
    }
  }

  // visit the unvisited nodes first to assign node value
  for (std::size_t j = 0; j < unvisited_list.size(); ++j)
  {
    (void) BFS(unvisited_list[j], depth+1);
  }

  int max_subtree_depth = -1;
  int min_parent_depth = n.value() -1;
  bool hasNextLevelChild = false;
  for(std::size_t i = 0; i < node2_list.size(); ++i) {
      GraphType::Node node2 = node2_list[i];

      if (node2.value() < min_parent_depth) min_parent_depth = node2.value();

      if (node2.value() < depth) {
            continue;
      }

      assert (node2.value() == n.value()+1);
      assert (node2.value() == depth);
      hasNextLevelChild = true;
      int subtree_depth = BFS(node2, depth+1);
      //std::cout << node2 << "subtree depth " << subtree_depth << std::endl;
      if (subtree_depth > max_subtree_depth) max_subtree_depth = subtree_depth;
  }

  int max_path_len = hasNextLevelChild ? max_subtree_depth : (min_parent_depth + 1);
  //std::cout << n << "longest path " << max_path_len << std::endl;
  return max_path_len;
}

void BFS_assign_shortest_path_length(const GraphType::Node& n, int depth)
{
  if (n.degree() == 0) return; // single root node

  // assign depth to immediate child nodes from left to right
  std::vector<GraphType::Node> node2_list;
  GraphType::incident_iterator incidentIter;
  GraphType::incident_iterator incidentIterEnd = n.incident_end();
  for(incidentIter = n.incident_begin() ; incidentIter!=incidentIterEnd; ++incidentIter) {
    GraphType::Node  node2;
    if ( n == (*incidentIter).node1()) {
        node2 = (*incidentIter).node2();
    }
    else {
        node2 = (*incidentIter).node1();
    }
    node2_list.push_back(node2);

    if (node2.value() == -1        // this child node has not been visited
        || node2.value() > depth)  // depth is a shorter path for this child node, "pull" it up
    {
        node2.value() = depth;
    }
  }

  // assign value to each child subtree from left to right
  for(std::size_t i = 0; i < node2_list.size(); ++i) {
    GraphType::Node node2 = node2_list[i];
    if (node2.value() < depth) {
        continue;
    }

    assert (node2.value() == n.value()+1);
    assert (node2.value() == depth);
    BFS_assign_shortest_path_length(node2, depth+1);
  }

  return;
}

int BFS_get_longest_path_length(const GraphType::Node& n)
{
    int maxVal = n.value();

    GraphType::incident_iterator incidentIter;
    GraphType::incident_iterator incidentIterEnd = n.incident_end();
    for(incidentIter = n.incident_begin() ; incidentIter!=incidentIterEnd; ++incidentIter)
    {
        GraphType::Node  node2;
        if ( n == (*incidentIter).node1())
        {
            node2 = (*incidentIter).node2();
        }
        else
        {
            node2 = (*incidentIter).node1();
        }
        if (node2.value() != n.value()+1) continue;

        int maxChildVal = BFS_get_longest_path_length(node2);
        if (maxChildVal > maxVal) {
            maxVal = maxChildVal;
        }
    }
    return maxVal;
}

CS207::Color color_func(const GraphType::Node & n)
{
    assert(longest_path_length != 0);
    return CS207::Color::make_heat((float) n.value() / longest_path_length);
}

int main(int argc, char* argv[])
{
  // Check arguments
  if (argc < 2) {
    std::cerr << "Usage: " << argv[0] << " NODES_FILE TETS_FILE\n";
    exit(1);
  }

  // Construct a Graph
  //typedef Graph<int> GraphType;
  GraphType graph;
  std::vector<GraphType::node_type> nodes;

  // Create a nodes_file from the first input argument
  std::ifstream nodes_file(argv[1]);
  // Interpret each line of the nodes_file as a 3D Point and add to the Graph
  Point p;
  while (CS207::getline_parsed(nodes_file, p))
    nodes.push_back(graph.add_node(p, -1)); // initialize node value to -1 meaning the node has not been visited

  // Create a tets_file from the second input argument
  std::ifstream tets_file(argv[2]);
  // Interpret each line of the tets_file as four ints which refer to nodes
#if 1
  std::array<int,4> t;
  while (CS207::getline_parsed(tets_file, t))
    for (unsigned i = 1; i < t.size(); ++i)
      for (unsigned j = 0; j < i; ++j)
        graph.add_edge(nodes[t[i]], nodes[t[j]]);
#endif

  Point p1(0,0,-1);
  GraphType::Node n1 = graph.add_node(p1,-1);

#if 0
    //a single node
  graph.add_edge(n1, nodes[1]);
#endif

#if 0
    //an edge
  graph.add_edge(n1, nodes[1]);
#endif

#if 0
    //2 sided line
  graph.add_edge(nodes[1], nodes[2]);
  graph.add_edge(nodes[2], nodes[3]);
#endif

#if 0
    //3 sided loop
  graph.add_edge(nodes[1], nodes[2]);
  graph.add_edge(nodes[2], nodes[3]);
  graph.add_edge(nodes[3], nodes[1]);
#endif

#if 1
    //two tetrahedra connected back to back  (sharing triangular base)
    graph.add_edge(n1, nodes[0]);
    graph.add_edge(n1, nodes[2]);
    graph.add_edge(n1, nodes[3]);
#endif // 0

#if 0
    ////two tetrahedra connected back to back  (sharing triangular base), also connected their tip nodes
    graph.add_edge(n1, nodes[0]);
    graph.add_edge(n1, nodes[2]);
    graph.add_edge(n1, nodes[3]);
    graph.add_edge(n1, nodes[1]);
#endif // 0

#if 0
    //4 sided loop
    graph.add_edge(nodes[0], nodes[1]);
    graph.add_edge(nodes[1], nodes[2]);
    graph.add_edge(nodes[2], nodes[3]);
    graph.add_edge(nodes[3], nodes[0]);
#endif // 0


  // Print out the stats
  std::cout << graph.num_nodes() << " " << graph.num_edges() << std::endl;

  // Use shortest_path_lengths to set the node values to the path lengths
  // Construct a Color functor and view with the SDLViewer

  Point pt(-1,0,1);
  longest_path_length = shortest_path_lengths(graph, pt);

#if 0
  // show nodes: [uid:degree:value]
  std::cout << "show nodes: [uid:degree:value]" << std::endl;
  GraphType::node_iterator nodeIterTest1 = graph.node_begin();
  GraphType::node_iterator nodeIterEndTest1 = graph.node_end();
  while (nodeIterTest1 != nodeIterEndTest1)
  {
      GraphType::Node n = *nodeIterTest1;
      std::cout << n << std::endl;
      ++nodeIterTest1;
  }
#else
  // Launch the SDLViewer
  CS207::SDLViewer viewer;
  viewer.launch();
  std::map<GraphType::node_type, GraphType::size_type> node_map = viewer.empty_node_map(graph);
  GraphType::node_iterator nodeIter = graph.node_begin();
  GraphType::node_iterator nodeIterEnd = graph.node_end();
  viewer.add_nodes(nodeIter, nodeIterEnd, color_func, node_map);
#endif

  std::cout << "longest path=" << longest_path_length << std::endl;

  return 0;
}
