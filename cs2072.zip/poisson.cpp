/**
 * @file poisson.cpp
 * Test script for treating the Graph as a MTL Matrix
 * and solving a Poisson equation.
 *
 * @brief Reads in two files specified on the command line.
 * First file: 3D Points (one per line) defined by three doubles.
 * Second file: Edges (one per line) defined by 2 indices into the point list
 *              of the first file.
 *
 * Launches an SDLViewer to visualize the solution.
 */

#include "CS207/SDLViewer.hpp"

#include "CS207/Util.hpp"

#include "Graph.hpp"

#include <fstream>
#include <boost/numeric/mtl/mtl.hpp>
#include <boost/numeric/itl/itl.hpp>
#include <boost/numeric/itl/iteration/basic_iteration.hpp>
#include <cassert>
#include <iostream>
#include <cmath>

// declare namespace for typedefs
namespace {
// declare types
typedef Graph<double, double> GraphType;
typedef GraphType::Node Node;
typedef GraphType::Edge Edge;
}

// prototype for gx functions
double gx(Node n);

using namespace itl;
// create visual_iteration callback class
template <class Real, class OStream = std::ostream>
class visual_iteration : public basic_iteration<Real>
{
  typedef basic_iteration<Real> super;
  typedef visual_iteration self;

  void print_resid()
  {
  if (!this->my_quite && this->i % cycle == 0 )
  if (multi_print || this->i != last_print) { // Avoid multiple print-outs in same iteration
    out << "iteration " << this->i << ": resid " << this->resid()
        << std::endl;
    last_print = this->i;
  }
}
  public:
    template <class Vector>
    visual_iteration (const Vector& r0, int max_iter_, Real tol_, Real atol_ = Real(0), int cycle_ = 100, OStream& out = std::cout)
      : super(r0, max_iter_, tol_, atol_), cycle(cycle_), last_print(-1), multi_print(false), out(out) {}

    visual_iteration(Real r0, int max_iter_, Real tol_, Real atol_ = Real(0), int cycle_ = 100, OStream& out = std::cout)
      : super(r0, max_iter_, tol_, atol_), cycle(cycle_), last_print(-1), multi_print(false), out(out) {}

    bool finished() { return super::finsihed(); }

  template <typename T>
    bool finished(const T& r)
    {
      bool ret = super::finished(r);
      print_resid();
/* HERE IS CALLBACK JOB BUT HAVING DATA SCOPE ISSUES
      // store answer into node values while computing min and max
      for (auto it = graph.node_begin(); it != graph.node_end(); ++it)
      {
        //update value
        (*it).value() = x[(*it).index()];

        // update min
        if ((*it).value() < minValue)
        {
          minValue = (*it).value();
        }
        // update max
        if ((*it).value() > maxValue)
        {
          maxValue = (*it).value();
        }
      }
      viewer.add_nodes(nodeIter, nodeIterEnd, NodeColor, NodePosition(), node_map);
      viewer.add_edges(edgeIter, edgeIterEnd, node_map);
*/
      return ret;
    }

    inline self& operator++() { ++this->i; return *this; }
    inline self& operator+=(int n) { this->i+= n; return *this; }

    operator int() const { return error_code(); }

    bool is_multi_print() const { return multi_print; }

    void set_multi_print(bool m) { multi_print = m; }

    int error_code() const
    {
      if (!this->my_suppress)
        out << "finished! error code = " << this->error << '\n'
            << this->iterations() << " iterations\n"
            << this->resid() << " is actual final residual. \n"
            << this->relresid() << " is actual relative tolerance achieved. \n"
            << "Relative tol: " << this->rtol_ << " Absolute tol: " << this->atol_ << '\n'
            << "Convergence: " << pow(this->relresid(), 1.0 / double(this->iterations())) << std::endl;
      return this->error;
 
    }
  protected:
    int cycle, last_print;
    bool multi_print;
    OStream& out;
};

// MTL interfact struct
struct GraphSymmetricMatrix
{
    // struct construct with const Graph reference
    GraphSymmetricMatrix(GraphType& g) : g_(g) {}

    // member variable to work with
    GraphType& g_;

    // matrix free mult
    template <typename VectorIn, typename VectorOut, typename Assign>
    void mult(const VectorIn& v, VectorOut& w, Assign) const
    {
      // each node corresponds to 1 element in the result vector
      for (auto node1it = g_.node_begin(); node1it != g_.node_end(); ++node1it)
      {
        Node n = *node1it;
        double value = 0;
        int i = n.index();

        // only nodes that will affect the value of the multiplication will be the adjacent ones
        for( auto adjit = n.incident_begin(); adjit != n.incident_end(); ++adjit)
        {
          // get second node in adjacent edges
          Edge e = *adjit;
          Node node2;
          if ( n == e.node1())
          {
            node2 = e.node2();
          }
          else
          {
            node2 = e.node1();
          }
          int j = node2.index();
          // non-zero values are when both are interior
          if (gx(n) != -99 && gx(node2) != -99)
          {
            // L_ij is 1
            value += v[j];
          }
        }

        // deal with i = j case as not in adjacency list
        //  if itself is not on the boundary
        if (gx(n) != -99)
        {
          // use its own degree
          value += -double(n.degree())* v[i]; 
        }
        else 
        {
          // else boundary makes the multiplier 1
          value += v[i];
        }
        Assign::apply(w[i], value);
      }
    }

    template <typename VectorIn>
    mtl::vector::mat_cvec_multiplier<GraphSymmetricMatrix, VectorIn> operator*(const VectorIn& v) const
    {   return mtl::vector::mat_cvec_multiplier<GraphSymmetricMatrix, VectorIn>(*this, v);    }

};


// inline size functions from what the graph represents

inline std::size_t size(const GraphSymmetricMatrix& A) { return A.g_.num_nodes() * A.g_.num_nodes(); }
inline std::size_t num_rows(const GraphSymmetricMatrix& A) { return A.g_.num_nodes(); }
inline std::size_t num_cols(const GraphSymmetricMatrix& A) { return A.g_.num_nodes(); }

namespace mtl {

    template <>
    struct Collection<GraphSymmetricMatrix>
    {
        typedef double value_type;
        typedef int    size_type;
    };

    namespace ashape {
        template <> struct ashape_aux<GraphSymmetricMatrix>
        {       typedef nonscal type;    };
    }
}

const double INITIALMAX = -999999;
const double INITIALMIN = 999999;
double minValue = INITIALMIN;
double maxValue = INITIALMAX;

// create NodeColor functor from CS207::color
CS207::Color NodeColor(const GraphType::Node & n)
{
    // make sure not dividing by zero
    assert(maxValue != 0);

    // color based on scaling to range
    return CS207::Color::make_heat(std::abs(n.value() - minValue)/(maxValue - minValue));
}

// define new position functor for SDLViewer
struct NodePosition {
  template <typename NODE>
  Point operator()(const NODE& node) {
    Point plotPosition = node.position();
    // use the result as the z axis
    plotPosition.z = node.value();
    return plotPosition;
  }
};

int main(int argc, char** argv)
{
  // Check arguments
  if (argc != 3) {
    std::cerr << "Usage: " << argv[0] << " NODES_FILE EDGES_FILE\n";
    exit(1);
  }

  // Construct a Graph
  GraphType graph;
  std::vector<GraphType::node_type> nodes; // create an empty vector of Graph Nodes

  // Create a nodes_file from the first input argument
  std::ifstream nodes_file(argv[1]);
  // Interpret each line of the nodes_file as a 3D Point and add to the Graph
  Point p;
  while (CS207::getline_parsed(nodes_file, p))
    nodes.push_back(graph.add_node(p));

  // Create a edges_file from the second input argument
  std::ifstream edges_file(argv[2]);
  // Interpret each line of the edges file as 2 nodes for the edge
  std::array<int,2> t;
  while (CS207::getline_parsed(edges_file, t)) {
    graph.add_edge(nodes[t[0]], nodes[t[1]]);
  }

  // Print out the stats
  std::cout << graph.num_nodes() << " " << graph.num_edges() << std::endl;

  // create A from the GraphSymmetric Matrix
  GraphSymmetricMatrix A(graph);

  // define b first as array then construct into mtl
  size_t size = graph.num_nodes();

  mtl::dense_vector<double> b(size);
  for (size_t i = 0; i < size; ++i)  //because we did not delete any node during Graph construction, i is node's uid_
  {
    // returns node on the ith position of active_node_uid_ which is a std::set
    Node n = graph.node(i);
    assert (n.index() == i); // std::set seems to maintain the insertion order of its members
    // if node is on boundary
    if (gx(n) != -99)
    {
      b[i] = gx(n);
    }
    else
    {
      // else using forcing function with Laplace

      // any length for h as all edges same length (h=0.020202 now)
      const double h_sq = normSq(graph.getPosition(0) - graph.getPosition(1));

      // h^2f(xi) - sumg(xj) where j are adj nodes to xi on boundary
      double fx = 5*std::cos(norm_1(graph.getPosition(i)));
      double sumgx = 0;

      // iterate through adjacent
      auto incident_end = n.incident_end();
      for( auto incident_it = n.incident_begin(); incident_it != incident_end; ++incident_it) {
        // incident iterator goes through edge_uids so get the other node
        Edge e = *incident_it;
        Node node2;
        if ( n == e.node1())
        {
          node2 = e.node2();
        }
        else
        {
          node2 = e.node1();
        }

        // add to sumgx if on boundary
        if (gx(node2) != -99)
        {
          sumgx += gx(node2);
        }
      }

      b[i] = h_sq * fx - sumgx;
    }
  }

  // cyclic_iteration iterator
  //itl::cyclic_iteration<double> iter(b, 100, 1.e-11, 0.0, 1);
  
  // customized callback
  visual_iteration<double> iter(b, 100, 1.e-11, 0.0, 1);

  // create MTl x vector for answer
  mtl::dense_vector<double> x(size, 0.0);

  // Launch the SDLViewer
  CS207::SDLViewer viewer;
  viewer.launch();
  std::map<GraphType::node_type, GraphType::size_type> node_map = viewer.empty_node_map(graph);
  GraphType::node_iterator nodeIter = graph.node_begin();
  GraphType::node_iterator nodeIterEnd = graph.node_end();
  GraphType::edge_iterator edgeIter = graph.edge_begin();
  GraphType::edge_iterator edgeIterEnd = graph.edge_end();

  // run conjuage gradient
  cg(A, x, b, iter);

  // store answer into node values while computing min and max
  for (auto it = graph.node_begin(); it != graph.node_end(); ++it)
  {
    //update value
    (*it).value() = x[(*it).index()];
  
    // update min
    if ((*it).value() < minValue)
    {
      minValue = (*it).value();
    }
    // update max
    if ((*it).value() > maxValue)
    {
      maxValue = (*it).value();
    }
  }
  viewer.add_nodes(nodeIter, nodeIterEnd, NodeColor, NodePosition(), node_map);
  viewer.add_edges(edgeIter, edgeIterEnd, node_map);
  
  return 0;
}

double gx (Node n)
{
  // check various boundary conditions
  if (norm_inf(n.position()) == 1)
  {
    return 0;
  }
  else if (norm_inf(n.position() - Point(0.6,0.6,0)) < 0.2
        || norm_inf(n.position() - Point(-0.6,-0.6,0)) < 0.2
        || norm_inf(n.position() - Point(0.6,-0.6,0)) < 0.2
        || norm_inf(n.position() - Point(-0.6,0.6,0)) < 0.2)
  {
    return -0.2;
  }
  else if (n.position().x >= -0.6
        && n.position().x <= 0.6
        && n.position().y >= -0.2
        && n.position().y <= 0.2
        && n.position().z >= -1
        && n.position().z <= 1)
  {
    return 1;
  }
  else
  {
    // flag if normal
    return -99;
  }
}
