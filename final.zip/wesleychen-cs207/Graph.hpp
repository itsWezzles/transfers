#ifndef CS207_GRAPH_HPP
#define CS207_GRAPH_HPP

/** @file Graph.hpp
 * @brief An undirected graph type
 */

#include "CS207/Util.hpp"
#include "Point.hpp"

#include <algorithm>
#include <vector>
#include <cassert>
#include <string>
#include <sstream> 

using namespace std;

/** @class Graph
 * @brief A template for 3D undirected graphs.
 *
 * Users can add and retrieve nodes and edges. Edges are unique (there is at
 * most one edge between any pair of distinct nodes).
 */
template <typename V, typename E>
class Graph {
  public:

	// PUBLIC TYPE DEFINITIONS

	/** Type of this graph. */
	typedef Graph<V,E> graph_type;

	/** Predeclaration of Node type. */
	class Node;
	/** Synonym for Node (following STL conventions). */
	typedef Node node_type;

	/** Predeclaration of Edge type. */
	class Edge;
	/** Synonym for Edge (following STL conventions). */
	typedef Edge edge_type;

	typedef V node_value_type;

	typedef E edge_value_type;

	/** Type of indexes and sizes. Return type of Node::index() and
			Graph::num_nodes(), argument type of Graph::node. */
	typedef unsigned size_type;

	/** Type of node iterators, which iterate over all graph nodes. */
	class node_iterator;

	/** Type of edge iterators, which iterate over all graph edges. */
	class edge_iterator;

	/** Type of incident iterators, which iterate incident edges to a node. */
	class incident_iterator;

  private:

  	struct node_element{
		Point pt;  // position of the node
		node_value_type value;
	};

	struct edge_element{
		size_type uid1;
		size_type uid2;
		edge_value_type value;
	};

  	vector<node_element> node_elements_;
	vector<size_type> idx2uid_;  // map from a Node's index to its uid
	vector<size_type> uid2idx_;  // map from a Node's uid to its index
	vector<edge_element> edge_elements_;
	vector<size_type> edge_idx2uid_;  // map from an Edge's index to its uid
	vector<size_type> edge_uid2idx_;  // map from an Edge's uid to its index
	vector<vector<size_type>> uid2edge_uid_;  // a vector of vectors that maps each Node's uid to the edge_uid of the Edges it has
	vector<bool> uid_in_graph_;  // tells whether or not a Node is currently in graph
	size_type next_edge_uid_; 
	size_type next_uid_; 

  public:

	// CONSTRUCTOR AND DESTRUCTOR

	/** Construct an empty graph. */
	Graph() : node_elements_(), idx2uid_(), uid2idx_(), edge_elements_(), edge_idx2uid_(), edge_uid2idx_(), uid2edge_uid_(), uid_in_graph_(), next_edge_uid_(0), next_uid_(0){
	}
	/** Default destructor */
	~Graph() = default;

	// NODES

	/** @class Graph::Node
	 * @brief Class representing the graph's nodes.
	 *
	 * Node objects are used to access information about the Graph's nodes.
	 */
	class Node : private totally_ordered<Node> {
	  private:
		// Only Graph can access our private members
		friend class Graph;

		graph_type* g_;
		size_type uid_;  
		
		/** Private Constructor */
		Node(const graph_type* g, size_type uid)
				: g_(const_cast<graph_type*>(g)), uid_(uid) {
		}
	  public:
		/** Construct an invalid node.
		 *
		 * Valid nodes are obtained from the Graph class, but it
		 * is occasionally useful to declare an @i invalid node, and assign a
		 * valid node to it later. For example:
		 *
		 * @code
		 * Node x;
		 * if (...should pick the first node...)
		 *   x = graph.node(0);
		 * else
		 *   x = some other node using a complicated calculation
		 * do_something(x);
		 * @endcode
		 */
		Node() {
		}

		/** Return this node's position. */
		Point position() const {
			return g_->node_elements_[uid_].pt;
		}

		void set_position(const Point& p){
			(g_->node_elements_[uid_].pt) = p;
		}

		/** Return this node's index, a number in the range [0, graph_size). */
		size_type index() const {
			return g_->uid2idx_[uid_];
		}

		/** Return this node's value. */
		node_value_type& value(){
			return g_->node_elements_[uid_].value;
		}

		const node_value_type& value() const{
			return g_->node_elements_[uid_].value;
		}

		bool operator == (const Node& n) const {
			return (g_ == n.g_ && uid_ == n.uid_);
		}

		bool operator < (const Node& n) const {
			//assert(g_ == n.g_);
			if (uid_ == n.uid_){
				return g_ < n.g_;
			}
			else{
				return uid_ < n.uid_; 
			}
		}

		/* Return the degree of this node. */
		size_type degree() const{
			return (g_->uid2edge_uid_[uid_]).size();
		}

		/* Return an iterator pointing to this node's "first" edge. */
		incident_iterator edge_begin() const{
			return incident_iterator(g_, uid_, 0);
		}

		/* Return an iterator pointing one beyond this node's "last" edge 
		 * for which the comparison operator can be used to end iteration. */
		incident_iterator edge_end() const{
			return incident_iterator(g_, uid_, degree());
		}

	};

	/** Return the number of nodes in the graph.
	 *
	 * Complexity: O(1).
	 */
	size_type size() const {
		return idx2uid_.size();
	}


	/** Synonym for size(). */
	size_type num_nodes() const {
		return size();
	}

	/** Add a node to the graph, returning the added node.
	 * @param[in] position The new node's position
	 * @post new size() == old size() + 1
	 * @post result_node.index() == old size()
	 *
	 * Complexity: O(1) amortized operations.
	 */

	Node add_node(const Point& position, const node_value_type& val = node_value_type()) {
		node_element el;
		el.pt = position;
		el.value = val;
		node_elements_.push_back(el);
		uid2idx_.push_back(num_nodes());
		idx2uid_.push_back(next_uid_);
		uid2edge_uid_.push_back(vector<size_type>());
		uid_in_graph_.push_back(true);
		++next_uid_;
		return Node(this, next_uid_-1);
	}

	/** Determine if this Node belongs to this Graph
	 * @return True if @a n is currently a Node of this Graph
	 *
	 * Complexity: O(1).
	 */
	bool has_node(const Node& n) const {
		return (this == n.g_ && uid_in_graph_[n.uid_]);
	}

	/** Return the node with index @a i.
	 * @pre 0 <= @a i < size()
	 * @post result_node.index() == i
	 *
	 * Complexity: O(1).
	 */
	Node node(size_type i) const {
		return Node(this, idx2uid_[i]);
	}

	/** Remove a node from the graph.
	 * @param[in] n Node to be removed
	 * @pre @a n is a valid node of this graph.
	 * @post new size() == old size() - 1
	 *
	 * Can invalidate outstanding iterators. @a n becomes invalid, as do any
	 * other Node objects equal to @a n. All other Node objects remain valid.
	 *
	 * Complexity: Polynomial in size().
	 */
	void remove_node(const Node& n) {
		assert(has_node(n));
		size_type other_uid;

		//For all edges that this node is involved in:
		//1.  Remove this edge from edge_idx2uid_
		//2.  Remove this edge from uid2edge_uid_[adjacent node]
		//3.  Update edge_uid2idx_
		for (size_type j = 0; j != uid2edge_uid_[n.uid_].size(); ++j){
			if (edge_elements_[uid2edge_uid_[n.uid_][j]].uid1 == n.uid_){
				other_uid = edge_elements_[uid2edge_uid_[n.uid_][j]].uid2;
			}
			else{
				other_uid = edge_elements_[uid2edge_uid_[n.uid_][j]].uid1;
			}
			edge_idx2uid_.erase(edge_idx2uid_.begin() + edge_uid2idx_[uid2edge_uid_[n.uid_][j]]);
			uid2edge_uid_[other_uid].erase(std::find(uid2edge_uid_[other_uid].begin(), uid2edge_uid_[other_uid].end(), uid2edge_uid_[n.uid_][j]));
			for (size_type i = uid2edge_uid_[n.uid_][j] +1; i < edge_uid2idx_.size(); ++i){
				--edge_uid2idx_[i];
			}
		}
		uid2edge_uid_[n.uid_].clear();
		
		idx2uid_.erase(idx2uid_.begin() + n.index());
		uid_in_graph_[n.uid_] = false;
		for (size_type i = n.uid_ + 1; i < uid2idx_.size(); ++i){
			--uid2idx_[i];
		}
	}

	/** Remove all nodes and edges from this graph.
	 * @post num_nodes() == 0 && num_edges() == 0
	 *
	 * Invalidates all outstanding Node and Edge objects.
	 */
	void clear() {
		node_elements_.clear();
		edge_elements_.clear();
		next_uid_ = 0;
		idx2uid_.clear();
		uid2idx_.clear();
		uid2edge_uid_.clear();
		edge_idx2uid_.clear();
		edge_uid2idx_.clear();
		next_edge_uid_ = 0;
		uid_in_graph_.clear();
	}

	// EDGES

	/** @class Graph::Edge
	 * @brief Class representing the graph's edges.
	 *
	 * Edges are order-insensitive pairs of nodes. Two Edges with the same nodes
	 * are considered equal if they connect the same nodes, in either order.
	 */
	class Edge : private totally_ordered<Edge> {
	  private:
		friend class Graph;
		
		graph_type* g_;
		size_type edge_uid_;

		Edge(const graph_type* g, size_type edge_uid)
				: g_(const_cast<graph_type*>(g)), edge_uid_(edge_uid){
		}


	  public:
		/** Construct an invalid Edge. */
		Edge() {
		}

		/** Return a node of this Edge */
		Node node1() const {
			return Node(g_, g_->edge_elements_[edge_uid_].uid1);
		}

		/** Return the other node of this Edge */
		Node node2() const {
			return Node(g_, g_->edge_elements_[edge_uid_].uid2);
		}

		/* @post returns true if @e has the same nodes as this edge. */
		bool operator==(const Edge& e) const{
			return (g_ == e.g_ && edge_uid_ == e.edge_uid_);
		}

		bool operator<(const Edge& e) const{
			//assert(g_ == e.g_);
			if (edge_uid_ == e.edge_uid_) {
				return g_ < e.g_;
			}
			else{
				return edge_uid_ < e.edge_uid_;
			}
		}

		//returns the adjacent node to node n in this edge
		Node other_node(Node n) const {
			if (n == node1()){
				return node2();
			}
			else{
				return node1();
			}
		}

		double length() const{
			return norm(node1().position() - node2().position());
		}

		/** Return this edge's value. */
		edge_value_type& value(){
			return g_->edge_elements_[edge_uid_].value;
		}

		const edge_value_type& value() const{
			return g_->edge_elements_[edge_uid_].value;
		}

		/** Return this edge's index, a number in the range [0, num_edges()). */
		size_type index() const {
			return g_->edge_uid2idx_[edge_uid_];
		}

	};

	/** Return the total number of edges in the graph.
	 *
	 * Complexity: No more than O(num_nodes() + num_edges()), hopefully less
	 */
	size_type num_edges() const {
		return edge_idx2uid_.size();
	}

	/** Return the edge with index @a i.
	 * @pre 0 <= @a i < num_edges()
	 *
	 * Complexity: No more than O(num_nodes() + num_edges()), hopefully less
	 */
	Edge edge(size_type i) const {
		return Edge(this, edge_idx2uid_[i]);
	}

	/** Test whether two nodes are connected by an edge.
	 * @pre @a a and @a b are valid nodes of this graph
	 * @return true if, for some @a i, edge(@a i) connects @a a and @a b.
	 *
	 * Complexity: No more than O(num_nodes() + num_edges()), hopefully less
	 */
	bool has_edge(const Node& a, const Node& b) const {
		if (a == b){
			return false;
		}
		if (! (uid_in_graph_[a.uid_] && uid_in_graph_[b.uid_]) ){
			return false;
		}
		for (auto it = uid2edge_uid_[a.uid_].begin(); it != uid2edge_uid_[a.uid_].end(); ++it){
			if (edge_elements_[*it].uid1 == b.uid_){
				return true;
			}
			else if (edge_elements_[*it].uid2 == b.uid_){
				return true;
			}
		}
		return false;
	}

	/**Returns edge_uid of edge between @a and @b.
	 * @pre @a a and @a b are valid nodes of this graph
	 * @post 
	 * @return edge_uid where edge(edge_uid2idx_[edge_uid]) connects @a a and @a b if has_edge(a,b), else return==++idx2uid[num_edges()] 
	 */
	size_type get_edge_uid(const Node& a, const Node& b) const {
		if (a == b){
			return next_edge_uid_;
		}
		for (auto it = uid2edge_uid_[a.uid_].begin(); it != uid2edge_uid_[a.uid_].end(); ++it){
			if (edge_elements_[*it].uid1 == b.uid_){
				return *it;
			}
			else if (edge_elements_[*it].uid2 == b.uid_){
				return *it;
			}
		}
		return next_edge_uid_;
	}

	/** Add an edge to the graph, or return the current edge if it already exists.
	 * @pre @a a and @a b are distinct valid nodes of this graph
	 * @return an Edge object e with e.node1() == @a a and e.node2() == @a b
	 * @post has_edge(@a a, @a b) == true
	 * @post If old has_edge(@a a, @a b), new num_edges() == old num_edges().
	 *       Else,                        new num_edges() == old num_edges() + 1.
	 *
	 * Can invalidate edge indexes -- in other words, old edge(@a i) might not
	 * equal new edge(@a i). Must not invalidate outstanding Edge objects.
	 *
	 * Complexity: No more than O(num_nodes() + num_edges()), hopefully less
	 */
	Edge add_edge(const Node& a, const Node& b) {
		assert(has_node(a) && has_node(b));
		assert(a != b);
		if (has_edge(a, b) == false) {
			edge_element el;
			el.uid1 = a.uid_;
			el.uid2 = b.uid_;
			edge_uid2idx_.push_back(num_edges());
			edge_elements_.push_back(el);
			edge_idx2uid_.push_back(next_edge_uid_);
			uid2edge_uid_[a.uid_].push_back(next_edge_uid_);
			uid2edge_uid_[b.uid_].push_back(next_edge_uid_);
			++next_edge_uid_;
			return Edge(this, next_edge_uid_-1);
		}
		return Edge(this, get_edge_uid(a,b));
	}

	/** Remove an edge, if any, returning the number of edges removed.
	 * @param[in] a,b The nodes potentially defining an edge to be removed.
	 * @return 1 if old has_edge(@a a, @a b), 0 otherwise
	 * @pre @a a and @a b are valid nodes of this graph
	 * @post !has_edge(@a a, @a b)
	 * @post new num_edges() == old num_edges() - result
	 *
	 * Can invalidate edge indexes -- in other words, old edge(@a i) might not
	 * equal new edge(@a i). Can invalidate all edge and incident iterators.
	 * Invalidates any edges equal to Edge(@a a, @a b). Must not invalidate
	 * other outstanding Edge objects.
	 *
	 * Complexity: No more than O(num_nodes() + num_edges()), hopefully less
	 */
	size_type remove_edge(const Node& a, const Node& b) {
		assert(has_node(a) && has_node(b));
		if (has_edge(a,b)) {
			size_type euid = get_edge_uid(a,b);
			uid2edge_uid_[a.uid_].erase(std::find(uid2edge_uid_[a.uid_].begin(), uid2edge_uid_[a.uid_].end(), euid));
			uid2edge_uid_[b.uid_].erase(std::find(uid2edge_uid_[b.uid_].begin(), uid2edge_uid_[b.uid_].end(), euid));
			edge_idx2uid_.erase(edge_idx2uid_.begin() + edge_uid2idx_[euid]);
			for (size_type i = euid +1; i < edge_uid2idx_.size(); ++i){
				--edge_uid2idx_[i];
			}
			return 1;
		}
		else{
			return 0;	
		}		
	}

	/** Remove an edge, if any, returning the number of edges removed.
	 * @param[in] e The edge to remove
	 * @pre @a e is a valid edge of this graph
	 * @pre has_edge(@a e.node1(), @a e.node2())
	 * @post !has_edge(@a e.node1(), @a e.node2())
	 * @post new num_edges() == old num_edges() - 1
	 *
	 * This is a synonym for remove_edge(@a e.node1(), @a e.node2()), but its
	 * implementation can assume that @a e is definitely an edge of the graph.
	 * This might allow a faster implementation.
	 *
	 * Can invalidate edge indexes -- in other words, old edge(@a i) might not
	 * equal new edge(@a i). Can invalidate all edge and incident iterators.
	 * Invalidates any edges equal to Edge(@a a, @a b). Must not invalidate
	 * other outstanding Edge objects.
	 *
	 * Complexity: No more than O(num_nodes() + num_edges()), hopefully less
	 */
	size_type remove_edge(const Edge& e) {
		node_type a = e.node1();
		node_type b = e.node2();
		return remove_edge(a,b);
	}

	// ITERATORS

	/** @class Graph::node_iterator
	 * @brief Iterator class for nodes. A forward iterator. */
	class node_iterator : private totally_ordered<node_iterator> {
	  public:
		// These type definitions help us use STL's iterator_traits.
		/** Element type. */
		typedef Node value_type;
		/** Type of pointers to elements. */
		typedef Node* pointer;
		/** Type of references to elements. */
		typedef Node& reference;
		/** Iterator category. */
		typedef std::input_iterator_tag iterator_category;
		/** Difference between iterators */
		typedef std::ptrdiff_t difference_type;

		/** Construct an invalid node_iterator. */
		node_iterator() {
		}

		value_type operator*() const {
			return Node(g_,g_->idx2uid_[idx_]);
		}

		bool operator==(const node_iterator& it) const{
			return (g_ == it.g_ && idx_ == it.idx_);
		}

		node_iterator& operator++() {
			++idx_;
			return *this; 
		}

	  private:
		friend class Graph;
		friend class edge_iterator;
		
		graph_type* g_;
		size_type idx_;

		node_iterator(const graph_type* g, size_type idx)
				: g_(const_cast<graph_type*>(g)), idx_(idx) {}
	};

	/* Return an iterator pointing to this graphs's first node. */
	node_iterator node_begin() const {
		return node_iterator(this,0);
	}

	/* Return an iterator pointing one beyond this graphs's last Node 
	 * for which the comparison operator can be used to end iteration. */
	node_iterator node_end() const{
		return node_iterator(this,num_nodes());
	}


	/** @class Graph::edge_iterator
	 * @brief Iterator class for edges. A forward iterator. */
	class edge_iterator : private totally_ordered<edge_iterator> {
	  public:
		// These type definitions help us use STL's iterator_traits.
		/** Element type. */
		typedef Edge value_type;
		/** Type of pointers to elements. */
		typedef Edge* pointer;
		/** Type of references to elements. */
		typedef Edge& reference;
		/** Iterator category. */
		typedef std::input_iterator_tag iterator_category;
		/** Difference between iterators */
		typedef std::ptrdiff_t difference_type;

		/** Construct an invalid edge_iterator. */
		edge_iterator() {
		}

		value_type operator*() const {
			return Edge(g_,g_->edge_idx2uid_[idx_]);
		}

		bool operator==(const edge_iterator& it) const {
			return (g_ == it.g_ && idx_ == it.idx_);
		}

		edge_iterator& operator++(){
			++idx_; 
			return *this; 
		}

	  private:
		friend class Graph;

		graph_type* g_;
		size_type idx_;

		edge_iterator(const graph_type* g, size_type idx)
				: g_(const_cast<graph_type*>(g)), idx_(idx) {}
	};

	/* Return an iterator pointing to this graphs's "first" Edge. */
	edge_iterator edge_begin() const{
		return edge_iterator(this,0);
	}

	/* Return an iterator pointing one beyond this graphs's "last" Eode 
	 * for which the comparison operator can be used to end iteration. */
	edge_iterator edge_end() const{
		return edge_iterator(this,num_edges());
	}


	/** @class Graph::incident_iterator
	 * @brief Iterator class for edges incident to a given node. A forward
	 * iterator. */
	class incident_iterator : private totally_ordered<incident_iterator> {
	  public:
		// These type definitions help us use STL's iterator_traits.
		/** Element type. */
		typedef Edge value_type;
		/** Type of pointers to elements. */
		typedef Edge* pointer;
		/** Type of references to elements. */
		typedef Edge& reference;
		/** Iterator category. */
		typedef std::input_iterator_tag iterator_category;
		/** Difference between iterators */
		typedef std::ptrdiff_t difference_type;

		/** Construct an invalid incident_iterator. */
		incident_iterator() {
		}

		value_type operator*() const{
			return Edge(g_,g_->uid2edge_uid_[node_uid_][idx_]);
		}

		bool operator== (const incident_iterator& it) const{
			return (g_ == it.g_ && node_uid_ == it.node_uid_ && idx_ == it.idx_);
		}

		incident_iterator& operator++(){
			++idx_;
			return *this;
		}

	  private:
		friend class Graph;
		graph_type* g_;
		size_type node_uid_;
		size_type idx_;

		incident_iterator(const graph_type* g, size_type node_uid, size_type idx) : g_(const_cast<graph_type*>(g)), node_uid_(node_uid), idx_(idx) {}
	};
	
};

#endif
