struct dings
{
    dings(const dings&) = default;
};

int main()
{
    return 0;
}
