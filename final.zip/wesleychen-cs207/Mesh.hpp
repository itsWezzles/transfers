#pragma once
/**
 * @file Mesh.hpp
 */
#include <cmath>
#include <vector>
#include "Graph.hpp"
// #include <boost/iterator/transform_iterator.hpp>


/** @class Mesh
 *  @brief A template for 3D triangular meshes.
 *
 *  Users can add triangles and retrieve nodes, edges, and triangles.
 */
template <typename N, typename E, typename T>
class Mesh {
 private:
  struct triangle_value_elements;
  struct PhysicalNode2MeshNode;
  struct TriangleNode2MeshTriangle;

 public:
  /** Type of indexes and sizes. Return type of Mesh::num_nodes(). */
  typedef unsigned size_type;

  /** Wrapper classes that forward to Graph:: counterparts*/
  class Node;
  class Triangle;
  class Edge;

  /** Class that gets the mesh nodes and triangles */
  class node_iterator;
  class triangle_iterator;
  class edge_iterator;
  class adj_tri_iterator;

  /** Type synonyms for mesh */
  typedef Mesh<N,E,T> mesh_type;

  /** Type synonyms for our physical graph and related classes */
  typedef Graph<N,E> physical_graph_type;
  typedef typename Graph<N,E>::Node physical_node_type;
  typedef typename Graph<N,E>::Edge physical_edge_type;

  /** Type synonyms for the templated parameters */
  typedef N node_value_type;
  typedef E edge_value_type;
  typedef T triangle_value_type;

  /** type synonyms for our 3 index and 3 normal vector types */
  typedef std::tuple<size_type, size_type, size_type> index_tup_type;
  typedef std::tuple<Point,Point,Point> point_tup_type;
  
  /** Type synonyms for triangle graph and related classes */
  typedef Graph<triangle_value_elements,E> triangle_graph_type;
  typedef typename Graph<triangle_value_elements,size_type>::Node triangle_node_type;
  typedef typename Graph<triangle_value_elements,size_type>::Edge triangle_edge_type;

  /** Type synonyms for wrapper classes */
  typedef Node node_type;
  typedef Triangle mesh_triangle_type;
  typedef Edge edge_type;

  /* 
  // We had played with this but the functor requirements and their compile errors made this out of scope for now
  typedef boost::transform_iterator<PhysicalNode2MeshNode, typename physical_graph_type::node_iterator> mesh_node_iterator;
  typedef boost::transform_iterator<TriangleNode2MeshTriangle, typename triangle_graph_type::node_iterator> mesh_triangle_iterator;
  */

 private:
  /** contains 2 graphs which are our physical node=/edge graph and our triangle-as-node abstraction */
  triangle_graph_type triangle_graph_;
  physical_graph_type physical_graph_;

  /**
   * mesh-wide vectors that associates each node uid to the triangles the node is adjacent to - allowing this mapping to be made when we add each triangle
   * the node uid is used as vector index allowing O(1) access
   */
  std::vector<std::vector<size_type>>  n2t_;
  std::vector<std::vector<size_type>> e2t_;

  /** the private data type for our triangle_node_values - which is built from what we need and the one template that the user provides */
  struct triangle_value_elements{

    // tval_ is the templated user-provided
    T tval_;

    // our private values that we want in the triangle_node_type
    index_tup_type node_idxs_;
    index_tup_type edge_idxs_;
    point_tup_type normals_;
    double area_;

    // default struct constructor
    triangle_value_elements() : area_(0) {
    };

    triangle_value_elements(triangle_value_type tval, index_tup_type nodes, index_tup_type edges, point_tup_type normals, double area )
      : tval_(tval), node_idxs_(nodes), edge_idxs_(edges), normals_(normals), area_(area) {};

    /*
    // More remnants of our boost attempt - it was these functors that did not meet the requirements of the iterator adaptor
    struct PhysicalNode2MeshNode {
      mesh_type* m_;
      PhysicalNode2MeshNode(mesh_type* m) : m_(m){};
      node_type operator() (physical_node_type n){
        return Node(m_,n);
      };
    };

    struct TriangleNode2MeshNode {
      mesh_type* m_;
      TriangleNode2MeshNode(mesh_type* m) : m_(m){};
      mesh_triangle_type operator() (triangle_node_type n){
        return Triangle(m_,n);
      };
    };
    */
  };

public:

  // default public constructor
  Mesh() = default;

  // default destructor
  ~Mesh() = default;

  /** @class Mesh::Node
   *  @brief A wrapper class which forwards to Graph::Node functions of physical_graph_
   *
   *  Users can access node values, indexes, positions and other publically available info of a node in a graph
   */
  class Node : private totally_ordered<Node> {
   private:
    friend class Mesh;
    mesh_type* m_;
    physical_node_type n_;
    
    // Private constructor
    Node(const mesh_type* m, physical_node_type n)
        : m_(const_cast<mesh_type*>(m)), n_(n) {}

   public:

    // invalid default constructor
    Node() {}

    /** Return this node's position. O(1)*/
    Point position() const {
      return n_.position();
    }

    /** Return this node's index, a number in the range [0, graph_size). O(1) */
    size_type index() const {
      return n_.index();
    }

    /** Return this node's value. O(1)*/
    node_value_type& value(){
      return n_.value();
    }

    /** Const version of value return. O(1) */
    const node_value_type& value() const{
      return n_.value();
    }

    bool operator == (const Node& n) const {
      return (m_==n.m_ && n_.operator==(n.n_));
    }

    bool operator < (const Node& n) const {
      return n_.operator<(n.n_);
    }

    /** Return the degree of this node. O(1)*/
    size_type degree() const{
      return n_.degree();
    }

    /** Return number of adjacent triangles. O(1)*/
    size_type num_adj_triangles() const{
      return (*m_).n2t_[n_.index()].size();
    };

    /** Return an iterator pointing to this node's "first" edge. */
    typename physical_graph_type::incident_iterator edge_begin() const{
      return n_.edge_begin();
    }

    /* Return an iterator pointing one beyond this node's "last" edge 
     * for which the comparison operator can be used to end iteration. */
    typename physical_graph_type::incident_iterator edge_end() const{
      return n_.edge_end();
    }

    /* Return an iterator pointing to this node's "first" edge. */
    adj_tri_iterator adj_triangle_begin() const{
      return adj_tri_iterator(m_, n_.index(), 0);
    }

    /* Return an iterator pointing one beyond this node's "last" edge 
     * for which the comparison operator can be used to end iteration. */
    adj_tri_iterator adj_triangle_end() const{
      return adj_tri_iterator(m_, n_.index(), num_adj_triangles());
    }
  };

  /** @class Mesh::Triangle
   *  @brief A wrapper class which forwards to Graph::Node functions of triangle_graph_
   *
   *  Users can access node values, indexes, positions and other publically available info of a node in a graph
   *  Triangle-is-a-node of triangle_graph_
   */
  class Triangle : private totally_ordered<Triangle> {
   private:
    friend class Mesh;
    mesh_type* m_;
    triangle_node_type n_;
    
    /** Private Constructor */
    Triangle(const mesh_type* m, triangle_node_type n)
        : m_(const_cast<mesh_type*>(m)), n_(n) {}

    /** Access private_value stored O(1) */
    triangle_value_elements& private_value(){
      return n_.value();
    }

    /** Const private value access O(1) */
    const triangle_value_elements& private_value() const{
      return n_.value();
    }

   public:

    /** Default constructor */
    Triangle() {}

    /** Return this node's position O(1) */
    Point position() const {
      return n_.position();
    }

    /** Return this node's index, a number in the range [0, graph_size). O(1) */
    size_type index() const {
      return n_.index();
    }

    /** Return this node's value as expected by user (not private value). O(1) */
    triangle_value_type& value(){
      return n_.value().tval_;
    }

    /** Const access for this node's value as expected by user (not private value). O(1) */
    const triangle_value_type& value() const{
      return n_.value().tval_;
    }

    bool operator == (const Triangle& n) const {
      return (m_==n.m_ && n_.operator==(n.n_));
    }

    bool operator < (const Triangle& n) const {
      return n_.operator<(n.n_);
    }

    /** Return the number of adjacent triangles (number of adjacent edges to this node). O(1) */
    size_type num_adj_triangles() const{
      return n_.degree();
    };

    /** Return an iterator pointing to this node's "first" edge. */
    typename triangle_graph_type::incident_iterator edge_begin() const{
      return n_.edge_begin();
    }

    /** Return an iterator pointing one beyond this node's "last" edge 
     *  for which the comparison operator can be used to end iteration. */
    typename triangle_graph_type::incident_iterator edge_end() const{
      return n_.edge_end();
    }

    /** Return an iterator to the given node's edge which represents the first adjacent triangle to the given triangle */
    adj_tri_iterator adj_tri_begin() const{
      return n_.edge_begin();
    }

    /** Return an iterator to one past the given node's "last" adjacent edge which represents the final adjacent triangle to the given triangle */
    adj_tri_iterator adj_tri_end() const{
      return n_.edge_end();
    }

    /** Return the area component privately stored in the private value of this node */
    double area() const{
      return private_value().area_;
    }

    /**
     *  Return a Mesh::Node that is the @i-th node of a triangle O(1)
     *  Mesh::Node is friended via friending with class Mesh
     *  @pre the input parameter must be between 0 and 2 inclusive, as each triangle has 3 nodes
     */ 
    node_type node(size_type i) const{
      size_type j;
      switch (i) {
        case 0:
            j = std::get<0>(private_value().node_idxs_);
            break;
        case 1:
            j = std::get<1>(private_value().node_idxs_);
            break;
        case 2:
            j = std::get<2>(private_value().node_idxs_);
            break;
      }
      return Node(m_, (*m_).physical_graph_.node(j));
    }

    /**
     *  Return a Mesh::Edge that is the @i-th edge of a triangle O(1)
     *  Mesh::Edge is friended via friending with class Mesh
     *  @pre the input parameter must be between 0 and 2 inclusive, as each triangle has 3 edges
     */ 
    edge_type edge(size_type i) const{
      size_type j;
      switch (i) {
        case 0:
            j = std::get<0>(private_value().edge_idxs_);
            break;
        case 1:
            j = std::get<1>(private_value().edge_idxs_);
            break;
        case 2:
            j = std::get<2>(private_value().edge_idxs_);
            break;
      }
      return Edge(m_, (*m_).physical_graph_.edge(j));
    }

    /**
     *  Return a Point that represents the scaled normal to the @i-th edge of a triangle O(1)
     *  @pre the input parameter must be between 0 and 2 inclusive, as each triangle has 3 edges
     *  @post the each edge normal is scaled to the length of the edge itself
     */ 
    Point edge_normal(size_type i) const{
      Point p;
      switch (i) {
        case 0:
            p = std::get<0>(private_value().normals_);
            break;
        case 1:
            p = std::get<1>(private_value().normals_);
            break;
        case 2:
            p = std::get<2>(private_value().normals_);
            break;
      }
      return p;
    }
  };

  /** @class Mesh::Edge
   *  @brief A wrapper class which forwards to Graph::Edge functions of physical_graph_
   *
   *  Users can access 2 node objects and other publically available info of an edge in a graph
   */
  class Edge : private totally_ordered<Edge> {
   private:
    friend class Mesh;
    mesh_type* m_;
    physical_edge_type e_;

    /** Private Constructor */
    Edge(const mesh_type* m, physical_edge_type e)
        : m_(const_cast<mesh_type*>(m)), e_(e){
    }

   public:
    /** Construct an invalid edge. */
    Edge() {
    }

    /** Return a Mesh::Node of this Edge. This is why we needed the wrapper O(1)*/
    Node node1() const {
      return Node(m_, e_.node1());
    }

    /** Return the other node of this Edge.  Also why we needed a wrapper O(1) */
    Node node2() const {
      return Node(m_, e_.node2());
    }

    /** @post returns true if @e has the same nodes as this edge. */
    bool operator==(const Edge& e) const{
      return (m_ == e.m_ && e_ == e.e_);
    }

    bool operator<(const Edge& e) const{
      return e_.operator<(e);
    }

    /** return the length of the edge calucalted from the positions of the nodes of the edge. O(1) */
    double length() const{
      return e_.length();
    }

    /** Return this edge's value - though shallow_water has no use for this value O(1) */
    edge_value_type& value(){
      return e_.value();
    }

    /** Const access to this edge's value - though shallow_water has no use for this value O(1) */
    const edge_value_type& value() const{
      return e_.value();
    }

    /** Return this edge's index, a number in the range [0, num_edges()). This was added to our Graph.hpp. O(1) */
    size_type index() const {
      return e_.index();
    }
  };

  /** 
   *  @pre no nodes have ever been removed since creating and popuating the graph
   *  @pre all node uids returned by Graph::add_node will be continuous starting from 0
   *  O(1) as the node.index() directly indexes the vector
   */
  node_type add_node(const Point& position, const node_value_type& val = node_value_type()) {
    // add node via physical graph add node
    node_type n = Node(this, physical_graph_.add_node(position, val));

    // create an empty vector as place-holder for the adjacent triangle information of newly added node
    n2t_.push_back(std::vector<size_type>());
    //assert( n.index()+1 == n2t_.size());
    return n;
  }

  /**
   *  @pre nodes are part of triangle
   *  @pre triangle of the same nodes has not previously been added
   *  abstraction - adjacent triangles are defined as triangles that share an edge, and do not just share one node
   */
  mesh_triangle_type add_triangle(const node_type n1, const node_type n2, const node_type n3, const triangle_value_type& val = triangle_value_type()) {

    // get center of triangle from average of the 3 nodes
    Point center = (n1.position() + n2.position() + n3.position())/3.0;

    // add each pair of nodes as edges to physical graph
    if (!physical_graph_.has_edge(n1.n_, n2.n_)) {
      e2t_.push_back(std::vector<size_type>());
    };
    physical_edge_type e1 = physical_graph_.add_edge(n1.n_, n2.n_);
    if (!physical_graph_.has_edge(n1.n_, n3.n_)) {
      e2t_.push_back(std::vector<size_type>());
    };
    physical_edge_type e2 = physical_graph_.add_edge(n1.n_, n3.n_);
    if (!physical_graph_.has_edge(n2.n_, n3.n_)) {
      e2t_.push_back(std::vector<size_type>());
    };
    physical_edge_type e3 = physical_graph_.add_edge(n2.n_, n3.n_);

    // create tuples to store the nodes and edges into the triangle graph's node value struct
    index_tup_type nodes (n1.index(), n2.index(), n3.index());
    index_tup_type edges (e1.index(), e2.index(), e3.index());

    // computer the area using Heron's formula
    double a = e1.length();
    double b = e2.length();
    double c = e3.length();
    double s = (a+b+c)/2.0;
    double area = std::sqrt(s*(s-a)*(s-b)*(s-c));

    // get the difference vectors which represent the vectors of the edges
    Point v1 = n2.position()-n1.position();
    Point v2 = n3.position()-n1.position();
    Point v3 = n3.position()-n2.position();

    // store outward pointing normals into the tuple via nested cross products
    point_tup_type normals;
    std::get<0>(normals) = cross(v1, cross(v1, v2));
    std::get<1>(normals) = cross(-v2, cross(-v2, -v3));
    std::get<2>(normals) = cross(v3, cross(v3, -v1));

    // normalize and scale by edge length
    std::get<0>(normals) = std::get<0>(normals) / norm(std::get<0>(normals)) * e1.length();
    std::get<1>(normals) = std::get<1>(normals) / norm(std::get<1>(normals)) * e2.length();
    std::get<2>(normals) = std::get<2>(normals) / norm(std::get<2>(normals)) * e3.length();

    // add the triangle with all the node-values to the triangle graph node
    mesh_triangle_type tri = Triangle(this,triangle_graph_.add_node(center, triangle_value_elements(val, nodes, edges, normals, area)));

    // store the created triangle to the vector for each node
    n2t_[n1.index()].push_back(tri.index());
    n2t_[n2.index()].push_back(tri.index());
    n2t_[n3.index()].push_back(tri.index());

    // store the created triangle to the vector for each edge
    e2t_[e1.index()].push_back(tri.index());
    e2t_[e2.index()].push_back(tri.index());
    e2t_[e3.index()].push_back(tri.index());

    // iterate through all existing triangles and look for shared edges to denoted adjacent triangles to each triangle
    triangle_edge_type tri_e;
    size_type ei, ej;
    for (auto it = (*this).triangle_begin(); it != (*this).triangle_end(); ++it) {
      // if not itself
      if ( (*it) != tri) {
        // iterate through edges to find shared edge
        for (size_type i = 0; i !=3; ++i) {
          for (size_type j = 0; j !=3; ++j) {

            // must use cases as get<X> is a compile-time constant experssion - but compile time is okay!
            switch (i) {
              case 0:
                  ei = std::get<0>((*it).private_value().edge_idxs_);
                  break;
              case 1:
                  ei = std::get<1>((*it).private_value().edge_idxs_);
                  break;
              case 2:
                  ei = std::get<2>((*it).private_value().edge_idxs_);
                  break;
            }
            switch (j) {
              case 0:
                  ej = std::get<0>(tri.private_value().edge_idxs_);
                  break;
              case 1:
                  ej = std::get<1>(tri.private_value().edge_idxs_);
                  break;
              case 2:
                  ej = std::get<2>(tri.private_value().edge_idxs_);
                  break;
            }

            // if an edge is shared
            if (ei == ej) {
              // add adjacent triangle via edge in the triangle graph
              tri_e = triangle_graph_.add_edge(tri.n_, (*it).n_);
              tri_e.value() = ei;
              e2t_[ei].push_back(tri_e.index());

              // early break
              break;
            }
          }
        }
      }
    }

    /*
    // debugging to print out intrinsic properties of an added triangle
    std::cout << "Triangle number " << triangle_graph_.num_nodes()
              << " Area: " << tri.area()
              << " Node 1: " << n1.position()
              << " Node 2: " << n2.position()
              << " Node 3: " << n3.position()
              << " Edge 1 length: " << e1.length()
              << " Edge 2 length: " << e2.length()
              << " Edge 3 length: " << e3.length()
              << " Norm 1:" << std::get<0>(normals)
              << " Norm 2: " << std::get<1>(normals)
              << " Norm 3: " << std::get<2>(normals) << std::endl;
    */
  //             std::cout<<"here"<<std::endl;
  //             int j;
  //   for (auto it = triangle_begin(); it != triangle_end(); ++it)  {

  //     for (int i = 0; i < 3; ++i) {       
  //   switch (i) {
  //       case 0:
  //           j = std::get<0>((*it).private_value().edge_idxs_);
  //           break;
  //       case 1:
  //           j = std::get<1>((*it).private_value().edge_idxs_);
  //           break;
  //       case 2:
  //           j = std::get<2>((*it).private_value().edge_idxs_);
  //           break;
  //     }
  //     std::cout<<j<<std::endl;
  //   }
    
  // }

    return tri;
  }

  /** Return the number of nodes in the mesh. O(1) */
  size_type num_nodes() const {
    return physical_graph_.num_nodes();
  }

  /** Return the number of edges in the mesh. O(1) */
  size_type num_edges() const {
    return physical_graph_.num_edges();
  }

  /** Return the number of triangles in the mesh. O(1) */
  size_type num_triangles() const {
    return triangle_graph_.num_nodes();
  }

  // clear graph using clear commands from the graph class
  void clear(){
    triangle_graph_.clear();
    physical_graph_.clear();
    n2t_.clear();
    e2t_.clear();
  }

  /*
  // using boost iterator transforms

   mesh_triangle_iterator triangle_begin() const {
     return mesh_triangle_iterator(this, triangle_graph_.node_begin());
   };

  mesh_triangle_iterator triangle_end() const {
     return mesh_triangle_iterator(this, triangle_graph_.node_end());
   };

   mesh_node_iterator node_begin() const {
     return mesh_node_iterator(this, physical_graph_.node_begin());
   };

   mesh_node_iterator node_end() const {
     return mesh_node_iterator(this, physical_graph_.node_end());
   };
   */

  /** Return iterator the first triangle in Mesh */
  triangle_iterator triangle_begin() const {
    return triangle_iterator(this, 0);
  };

  /** Return iterator to one past the last triangle in Mesh */
  triangle_iterator triangle_end() const {
    return triangle_iterator(this, triangle_graph_.size());
  };

  /** Return iterator to the first node of the Mesh */
  node_iterator node_begin() const {
    return node_iterator(this, 0);
  };

  /** Return iterator to one past the last node of the Mesh*/
  node_iterator node_end() const {
    return node_iterator(this, physical_graph_.size());
  }; 

  /** Return iterator to the first edge of the Mesh*/
  edge_iterator edge_begin() const{
    return edge_iterator(this, 0);
  }

  /** Return iterator to one past the first edge of the Mesh*/
  edge_iterator edge_end() const{
    return edge_iterator(this, physical_graph_.num_edges());
  }

  /** 
   * Return True if given edge is shared between 2 triangles, else False
   * @pre:  i < size && i >= 0 
   */
  bool is_shared_edge(edge_type e) const{
    if (e2t_[e.index()].size() < 2)
      return false;
    else
      return true;
  }

  /** 
   * Return a Mesh::Triangle which is adjacent to a given triangle on an edge 
   *  @pre is_shared_edge(e) == true
   *  O(1)
   */
  mesh_triangle_type adj_triangle(mesh_triangle_type t, edge_type e) const{
    size_type i;
    if (e2t_[e.index()][0] == t.index()){
      i = e2t_[e.index()][1];
    }
    else{
      i = e2t_[e.index()][0];
    }
    return Triangle(this, triangle_graph_.node(i));
  }

  /** @class Mesh::adj_tri_iterator
   *  @brief An iterator class that returns iterators to nodes in the triangle_graph representing adjacent triangles
   *
   *  Users can perform standard iterator functions, *, ++, = and ==
   */
  class adj_tri_iterator : private totally_ordered<adj_tri_iterator> {
    public:
    // These type definitions help us use STL's iterator_traits.
    /** Element type. */
    typedef mesh_triangle_type value_type;
    /** Type of pointers to elements. */
    typedef mesh_triangle_type* pointer;
    /** Type of references to elements. */
    typedef mesh_triangle_type& reference;
    /** Iterator category. */
    typedef std::input_iterator_tag iterator_category;
    /** Difference between iterators */
    typedef std::ptrdiff_t difference_type;

    /** Construct an invalid adj_tri_iterator. */
    adj_tri_iterator() {
    }

    value_type operator*() const{
      return Triangle(m_, (*m_).triangle_graph_.node((*m_).n2t_[node_idx_][i_]));
    }

    bool operator== (const adj_tri_iterator& it) const{
      return (m_ == it.m_ && node_idx_ == it.node_idx_ && i_ == it.i_);
    }

    adj_tri_iterator& operator++(){
      ++i_;
      return *this;
    }

    private:
    friend class Mesh;
    mesh_type* m_;
    // stores node index values for the triangle from which this is called
    size_type node_idx_;
    size_type i_;

    // Private constructor
    adj_tri_iterator(const mesh_type* m, size_type node_idx, size_type i) : m_(const_cast<mesh_type*>(m)), node_idx_(node_idx), i_(i) {}
  };

  /** @class Mesh::node_iterator
   *  @brief An iterator class that returns iterators to nodes in the physical_graph representing all nodes
   *
   *  Users can perform standard iterator functions, *, ++, = and ==
   */
  class node_iterator : private totally_ordered<node_iterator> {
    public:
    // These type definitions help us use STL's iterator_traits.
    /** Element type. */
    typedef Node value_type;
    /** Type of pointers to elements. */
    typedef Node* pointer;
    /** Type of references to elements. */
    typedef Node& reference;
    /** Iterator category. */
    typedef std::input_iterator_tag iterator_category;
    /** Difference between iterators */
    typedef std::ptrdiff_t difference_type;

    /** Construct an invalid node_iterator. */
    node_iterator() {
    }

    value_type operator*() const {
      return Node(m_, (*m_).physical_graph_.node(idx_));
    }

    bool operator==(const node_iterator& it) const{
      return (m_ == it.m_ && idx_ == it.idx_);
    }

    node_iterator& operator++() {
      ++idx_;
      return *this; 
    }

    private:
    friend class Mesh;   
    mesh_type* m_;
    size_type idx_;

    // Private constructor
    node_iterator(const mesh_type* m, size_type idx)
        : m_(const_cast<mesh_type*>(m)), idx_(idx) {}
  };

  /** @class Mesh::triangle_iterator
   *  @brief An iterator class that returns iterators to nodes in the triangle_graph of the Mesh
   *
   *  Users can perform standard iterator functions, *, ++, = and ==
   */
  class triangle_iterator : private totally_ordered<triangle_iterator> {
    public:
    // These type definitions help us use STL's iterator_traits.
    /** Element type. */
    typedef Triangle value_type;
    /** Type of pointers to elements. */
    typedef Triangle* pointer;
    /** Type of references to elements. */
    typedef Triangle& reference;
    /** Iterator category. */
    typedef std::input_iterator_tag iterator_category;
    /** Difference between iterators */
    typedef std::ptrdiff_t difference_type;

    /** Construct an invalid triangle_iterator. */
    triangle_iterator() {
    }

    value_type operator*() const {
      return Triangle(m_, (*m_).triangle_graph_.node(idx_));
    }

    bool operator==(const triangle_iterator& it) const{
      return (m_ == it.m_ && idx_ == it.idx_);
    }

    triangle_iterator& operator++() {
      ++idx_;
      return *this; 
    }

    private:
    friend class Mesh;
    mesh_type* m_;
    size_type idx_;

    // Private constructor
    triangle_iterator(const mesh_type* m, size_type idx)
        : m_(const_cast<mesh_type*>(m)), idx_(idx) {}
  };

  /** @class Mesh::edge_iterator
   *  @brief An iterator class that returns iterators to edges in the physical_graph representing all real edges
   *
   *  Users can perform standard iterator functions, *, ++, = and ==
   */
  class edge_iterator : private totally_ordered<edge_iterator> {
    public:
    // These type definitions help us use STL's iterator_traits.
    /** Element type. */
    typedef Edge value_type;
    /** Type of pointers to elements. */
    typedef Edge* pointer;
    /** Type of references to elements. */
    typedef Edge& reference;
    /** Iterator category. */
    typedef std::input_iterator_tag iterator_category;
    /** Difference between iterators */
    typedef std::ptrdiff_t difference_type;

    /** Construct an invalid edge_iterator. */
    edge_iterator() {
    }

    value_type operator*() const {
      return Edge(m_, (*m_).physical_graph_.edge(idx_));
    }

    bool operator==(const edge_iterator& it) const{
      return (m_ == it.m_ && idx_ == it.idx_);
    }

    edge_iterator& operator++() {
      ++idx_;
      return *this; 
    }

    private:
    friend class Mesh;
    mesh_type* m_;
    size_type idx_;

    // Private constructor
    edge_iterator(const mesh_type* m, size_type idx)
        : m_(const_cast<mesh_type*>(m)), idx_(idx) {}
  };
};
