#ifndef QVAR_HPP
#define QVAR_HPP

/** Water column characteristics */
struct QVar {
  double h;	  // Height of fluid
  double hu;	// Height times average x velocity of column
  double hv;	// Height times average y velocity of column

  /** Default constructor.
   *
   * A default water column is 1 unit high with no velocity. */
  QVar()
    : h(1), hu(0), hv(0) {
  }
  /** Construct the given water column. */
  QVar(double h_, double hu_, double hv_)
    : h(h_), hu(hu_), hv(hv_) {
  }

  // define += as updating corresponding parts
  QVar& operator+= (const QVar & q){
    h += q.h;
    hu += q.hu;
    hv += q.hv;
    return *this;
  }
};

// define + operator for 2 QVars
QVar operator+ (const QVar & q1, const QVar & q2){
  return QVar(q1.h+q2.h, q1.hu+q2.hu, q1.hv+q2.hv);
}

// define * operator for 2 QVars
QVar operator* (double c, const QVar & q){
  return QVar(q.h*c, q.hu*c, q.hv*c);
}

#endif